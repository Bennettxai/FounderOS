PRAGMA foreign_keys=OFF;
BEGIN TRANSACTION;
CREATE TABLE vsl_snapshots (
  video_id TEXT NOT NULL, date_from TEXT NOT NULL, date_to TEXT NOT NULL,
  captured_at TEXT NOT NULL, payload TEXT NOT NULL,
  PRIMARY KEY (video_id, date_from, date_to)
);
CREATE TABLE client_work (
  id TEXT PRIMARY KEY,
  clientId TEXT NOT NULL,
  brief TEXT NOT NULL,
  status TEXT NOT NULL,
  createdAt TEXT NOT NULL,
  workspaceId TEXT,
  detail TEXT
);
CREATE TABLE seed_meta (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL
);
INSERT INTO seed_meta VALUES('seed_version','2026-09-23-retire-attio-ghl');
CREATE TABLE departments (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  slug TEXT NOT NULL UNIQUE,
  tagline TEXT NOT NULL DEFAULT '',
  color TEXT NOT NULL,
  "order" INTEGER NOT NULL
);
INSERT INTO departments VALUES('dept-sales','Sales','sales','Pipeline and deals.','#fafafa',1);
INSERT INTO departments VALUES('dept-marketing-growth','Marketing/Growth','marketing-growth','Publishing, content, attention.','#d4d4d4',2);
INSERT INTO departments VALUES('dept-tech','TECH','tech','AI & automations · G-Brain.','#a3a3a3',3);
INSERT INTO departments VALUES('dept-finance','Finances','finances','Every processor, one view.','#737373',4);
INSERT INTO departments VALUES('dept-comms','Communications','communications','Gmail, WhatsApp, Slack → one feed.','#525252',5);
INSERT INTO departments VALUES('dept-clients','Clients','clients','Every client, onboarded and served.','#d4d4d4',6);
CREATE TABLE agents (
  id TEXT PRIMARY KEY,
  department_id TEXT NOT NULL REFERENCES departments(id),
  name TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT '',
  status TEXT NOT NULL,
  tier TEXT NOT NULL,
  description TEXT NOT NULL DEFAULT '',
  model TEXT NOT NULL DEFAULT '',
  tools TEXT NOT NULL DEFAULT '[]'
, parent_id TEXT, instance TEXT NOT NULL DEFAULT 'builtin');
INSERT INTO agents VALUES('conductor','dept-tech','Conductor','Broadcast & Orchestration','active','lead','Fans your message out to every agent at once and checks which instance hosts (OpenClaw, Ollama, tmux) are available for future bindings.','fan-out runtime','["broadcast","openclaw","tmux"]',NULL,'builtin');
INSERT INTO agents VALUES('comms-digest','dept-comms','Comms Digest','Morning Report · 09:00 daily','active','lead','Scrapes the last 24h across all four inboxes, WhatsApp and Slack and ranks who needs a reply: calls first, then clients, students and family, brand deals, group chats, companies last. Also lists what to unsubscribe from.','rules + connectors','["comms-feed","calendar","stripe"]',NULL,'builtin');
INSERT INTO agents VALUES('comms-agent','dept-comms','Comms Agent','Unified Communications Instance','active','lead','Owns the unified /comms feed. Aggregates its three channel workers and reports which are live.','aggregate of workers','["comms-feed"]',NULL,'builtin');
INSERT INTO agents VALUES('gmail-worker','dept-comms','Gmail Worker','IMAP Inboxes ×4','planned','worker','Pulls unread counts and recent mail from up to four IMAP inboxes into /comms. Activates when INBOX_* creds land.','imapflow','["imap"]','comms-agent','builtin');
INSERT INTO agents VALUES('whatsapp-worker','dept-comms','WhatsApp Worker','Chat Monitor','active','worker','Reads the local WhatsApp ChatStorage (600+ chats incl. LC + Vantage teams) into /comms. Works today.','local sqlite (read-only)','["whatsapp"]','comms-agent','builtin');
INSERT INTO agents VALUES('slack-worker','dept-comms','Slack Worker','Channel Digest','planned','worker','Latest messages across joined channels into /comms. Needs SLACK_BOT_TOKEN.','@slack/web-api','["slack"]','comms-agent','builtin');
INSERT INTO agents VALUES('social-agent','dept-marketing-growth','Social Agent','Social Media & Content Creation Instance','active','lead','Owns publishing and content production. Aggregates the Zernio and Arcads workers.','aggregate of workers','["zernio","arcads","remotion","higgsfield","manychat"]',NULL,'builtin');
INSERT INTO agents VALUES('brand-deal-agent','dept-sales','Brand Deal Agent','Victor · brand deal manager','active','worker','Negotiates as Victor, Alex’s brand deal manager: qualifies inbound, anchors and counters, chases unpaid invoices, and bumps stalled threads. A tested contact governor decides whether a thread may be touched at all (five bumps maximum, one revival per brand per six months). Drafts only, never sends.','rules + gateway','["imap"]','sales-agent','builtin');
INSERT INTO agents VALUES('newsletter-agent','dept-marketing-growth','Newsletter Agent','Issue drafting','active','worker','Reads Beehiiv send performance, builds a brief that is honest about how thin the history is, and drafts the next issue against the skill file. Drafts only, never schedules or sends.','rules + gateway','["beehiiv"]','social-agent','builtin');
INSERT INTO agents VALUES('postly-publisher','dept-marketing-growth','Zernio Publisher','Six-Platform Publishing','active','worker','Publishes and monitors six platforms under @founderos.ai via Zernio. Key already on this machine — works today.','zernio api','["zernio"]','social-agent','builtin');
INSERT INTO agents VALUES('adsmith-creative','dept-marketing-growth','Arcads Creative','UGC Ad Generation','active','worker','Generates UGC ads for Vantage (Veo/Sora/Kling) via the Arcads API. Auth on this machine — works today.','arcads api','["arcads"]','social-agent','builtin');
INSERT INTO agents VALUES('reelkit-editor','dept-marketing-growth','Remotion Editor','Social Editing Pipeline','active','worker','Editing and rendering pipeline for social media clips, captions, and promotional cuts.','remotion pipeline','["remotion","whisper"]','social-agent','builtin');
INSERT INTO agents VALUES('renderly-creative','dept-marketing-growth','Higgsfield Creative','AI Creative Studio','active','worker','Higgsfield creative generation for social assets, product shots, and campaign visuals.','higgsfield cli','["higgsfield"]','social-agent','builtin');
INSERT INTO agents VALUES('dmflow-mcp','dept-marketing-growth','ManyChat MCP','DM Automation','active','worker','ManyChat MCP/API lane for social DM automations, keyword flows, and lead capture.','manychat api','["manychat"]','social-agent','builtin');
INSERT INTO agents VALUES('sales-agent','dept-sales','Sales Agent','Deals & Pipeline Instance','active','lead','Owns the sales pillar. Aggregates Lead Pulse and reports the live pipeline: Typeform leads, Fathom calls, payments.','aggregate of workers','["typeform","paykit","stripe","flexpay","fathom","plaud"]',NULL,'builtin');
INSERT INTO agents VALUES('launchpad-cohort-sales','dept-sales','Launchpad Cohort','Sales Account Lane','planned','worker','Launchpad Cohort sales lane: offers, calls, payment confirmation, and CRM context.','account lane','["typeform","stripe","paykit"]','sales-agent','builtin');
INSERT INTO agents VALUES('vantage-sales','dept-sales','Vantage','Sales Account Lane','planned','worker','Vantage sales lane: account pipeline, PayKit context, payment confirmation, and call data.','account lane','["typeform","stripe","paykit"]','sales-agent','builtin');
INSERT INTO agents VALUES('paykit-sales','dept-finance','PayKit','Offer & Payment Platform','planned','worker','PayKit sales platform connection for offers and customer/payment context.','paykit api','["paykit"]','payments-pulse','builtin');
INSERT INTO agents VALUES('vantage-paykit','dept-sales','Vantage PayKit','Vantage PayKit Lane','planned','worker','PayKit lane specifically under Vantage for offer, payment, and customer context.','paykit api','["paykit"]','vantage-sales','builtin');
INSERT INTO agents VALUES('stripe-sales','dept-finance','Stripe','Sales Payment Processor','planned','worker','Stripe payment confirmation lane for sales workflows and account-level revenue checks.','stripe sdk','["stripe"]','payments-pulse','builtin');
INSERT INTO agents VALUES('processor-confirmation','dept-finance','Processor Confirm','Payment API Confirmation','planned','worker','APIs to payment processors for confirming paid, failed, disputed, and pending states.','processor registry','["stripe","paypal","square","whop","paykit"]','payments-pulse','builtin');
INSERT INTO agents VALUES('flexpay-financing','dept-finance','FlexPay Financing','Financing Options','planned','worker','FlexPay financing options lane for sales offers and payment-plan context.','flexpay api','["flexpay"]','payments-pulse','builtin');
INSERT INTO agents VALUES('sales-calls-data','dept-sales','Sales Calls Data','Call Intelligence','planned','worker','Sales calls data lane for recordings, notes, outcomes, and follow-up context: Fathom on the calls, Plaud in the room.','fathom + plaud','["fathom","plaud"]','sales-agent','builtin');
INSERT INTO agents VALUES('data-agent','dept-tech','Data Agent','G-Brain Analyst','active','lead','Bound to the G-Brain instance: analyzes markdown + vector storage health and surfaces ideas. Answers broadcasts by querying the brain.','gbrain CLI','["gbrain","brain-store","ollama","supabase"]',NULL,'builtin');
INSERT INTO agents VALUES('markdown-auditor','dept-tech','Markdown Auditor','brain-store Health','active','worker','Audits the knowledge base: broken wikilinks, orphan pages, duplicate titles, and whether the index search reads still matches the store on disk.','link audit','["brain-store"]','data-agent','builtin');
INSERT INTO agents VALUES('vector-auditor','dept-tech','Vector Auditor','pgvector / Supabase Health','active','worker','Runs gbrain doctor: connection to Supabase pgvector, embedding checks, health score. Works today.','gbrain doctor','["supabase","ollama"]','data-agent','builtin');
INSERT INTO agents VALUES('payments-pulse','dept-finance','Payments Pulse','Processor Monitor','planned','lead','Stripe balance + recent charges; PayPal/Square/Whop registered and awaiting keys.','stripe sdk','["stripe","paypal","square","whop"]',NULL,'builtin');
INSERT INTO agents VALUES('crm-pulse','dept-sales','Lead Pulse','Lead Lane Health','active','worker','Checks the lead lane end to end: Typeform leads in, calls booked on the calendar, calls held on Fathom.','typeform + calendar + fathom','["typeform","calendar","fathom"]','sales-agent','builtin');
INSERT INTO agents VALUES('stack-monitor','dept-tech','Stack Monitor','Local Stack Health','active','lead','Remotion, Ollama, command-center, OpenClaw, tmux, whisper, ffmpeg, higgsfield, gh + Wispr Flow stats.','local checks','["remotion","ollama","tmux","wispr"]',NULL,'builtin');
INSERT INTO agents VALUES('client-roster','dept-clients','Client Roster','Live Client List','active','lead','The single source of truth for who is a client: the people who paid (Stripe), reconciled with PayKit and the funnel, kept current.','stripe + funnel','["stripe","paykit"]',NULL,'builtin');
INSERT INTO agents VALUES('client-onboarding','dept-clients','Onboarding Agent','Closed-Won to Kickoff','planned','worker','Runs the onboarding SOP end to end when a deal closes: welcome pack, workspace setup, kickoff booked, handoff notes.','stripe + slack','["stripe","slack"]','client-roster','builtin');
INSERT INTO agents VALUES('client-success','dept-clients','Client Success','Service & Renewals','planned','worker','Keeps active clients served: check-in cadence, deliverable tracking from call notes (Fathom) and in-person meeting recordings (Plaud), renewal and upsell flags.','fathom + plaud + slack','["fathom","plaud","slack"]','client-roster','builtin');
CREATE TABLE tools (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  category TEXT NOT NULL,
  status TEXT NOT NULL,
  color TEXT NOT NULL,
  description TEXT NOT NULL DEFAULT ''
);
INSERT INTO tools VALUES('tool-gbrain','G-Brain (gbrain CLI)','Knowledge','connected','#fafafa','v0.47 · brain-store markdown + Supabase + local Ollama bge-m3 embeddings. Live, health 90/100.');
INSERT INTO tools VALUES('tool-brain-store','brain-store/','Knowledge','connected','#d4d4d4','Local markdown knowledge base at clue-agent/brain-store.');
INSERT INTO tools VALUES('tool-supabase','Supabase (Second Brain)','Knowledge','available','#a3a3a3','918 pages / 11k chunks. Free tier pauses on idle — unpause from dashboard when queries fail.');
INSERT INTO tools VALUES('tool-obsidian','Obsidian Vault','Knowledge','connected','#d4d4d4','~/Documents/Obsidian Vault incl. 652-conversation Claude Archive. Direct filesystem access.');
INSERT INTO tools VALUES('tool-zernio','Zernio','Social','connected','#fafafa','6 platforms under @founderos.ai (IG 40k, TikTok 10k, X 4k…). Key at ~/.social-media/.env — live.');
INSERT INTO tools VALUES('tool-manychat','ManyChat','Social','connected','#fafafa','IG DM automation, live via the standalone ManyChat MCP (13 tools). Keyword flows still authored in the ManyChat UI: the public API has no flow authoring.');
INSERT INTO tools VALUES('tool-skool','Skool (via Playwright)','Social','connected','#a3a3a3','launchpad-cohort-6209 community, driven by the documented Playwright workflow.');
INSERT INTO tools VALUES('tool-paykit','PayKit','CRM & Revenue','planned','#d4d4d4','Offer/payment/customer context for Sales, including the Vantage PayKit lane.');
INSERT INTO tools VALUES('tool-flexpay','FlexPay','CRM & Revenue','planned','#a3a3a3','Financing options for sales offers and payment-plan context.');
INSERT INTO tools VALUES('tool-stripe','Stripe','CRM & Revenue','available','#d4d4d4','Full client implemented — balance + charges live once STRIPE_SECRET_KEY is set.');
INSERT INTO tools VALUES('tool-fathom','Fathom','CRM & Revenue','connected','#a3a3a3','AI meeting notetaker on every sales call. FATHOM_API_KEY is planted on the mini — live: meetings feed the Recordings tab, the call archive and the funnel''s calls-held touches.');
INSERT INTO tools VALUES('tool-typeform','Typeform','CRM & Revenue','available','#d4d4d4','Where leads come from: completed lead-form submissions open funnel journeys. Client built; live once TYPEFORM_API_KEY is planted.');
INSERT INTO tools VALUES('tool-plaud','Plaud','CRM & Revenue','connected','#d4d4d4','AI voice recorder for the room: in-person client meetings, site walks, memos. Transcripts + AI notes over the Plaud API (PLAUD_REFRESH_TOKEN); pairs with Fathom on the Recordings tab.');
INSERT INTO tools VALUES('tool-trakyo','Trakyo','CRM & Revenue','planned','#737373','Revenue attribution for Launchpad Cohort: content → booked calls → payments. Status-only until Trakyo ships a public API (TRAKYO_API_KEY).');
INSERT INTO tools VALUES('tool-remotion','Remotion Pipeline','Creative','connected','#fafafa','~/Projects/remotion-pipeline · studio :3789 · LC + Vantage themes · 7 skills. Active Jun 10.');
INSERT INTO tools VALUES('tool-higgsfield','Higgsfield CLI','Creative','connected','#d4d4d4','v0.1.40, auth in keychain. generate / product-photoshoot / marketing-studio / soul-id.');
INSERT INTO tools VALUES('tool-arcads','Arcads','Creative','connected','#a3a3a3','UGC ads for Vantage (Veo/Sora/Kling). Basic auth at ~/Projects/arcads-agent-skills/.env.');
INSERT INTO tools VALUES('tool-loom','Loom','Creative','connected','#d4d4d4','Screen recordings. Loom publishes no account API, so the lane is link-level: the public oEmbed endpoint resolves any share link to title, thumbnail and duration, no key needed — live.');
INSERT INTO tools VALUES('tool-vidalytics','Vidalytics','Creative','available','#737373','VSL video host. Public API client built (library via GET /video; stats are quota-metered, never polled). Live once VIDALYTICS_API_KEY is planted (Premium plan+).');
INSERT INTO tools VALUES('tool-whisper','Whisper (local)','Creative','connected','#737373','whisper-cli + ffmpeg via brew. Local transcription, nothing leaves the machine.');
INSERT INTO tools VALUES('tool-miro','Miro','Creative','connected','#a3a3a3','REST API with token from clue-agent/.env.agents. GBrain architecture board exists.');
INSERT INTO tools VALUES('tool-canva-figma','Canva + Figma','Creative','available','#525252','Connected as Claude MCPs (session-scoped). Standalone API needs separate keys.');
INSERT INTO tools VALUES('tool-imap','Email (4 IMAP slots)','Comms','available','#d4d4d4','Client implemented for 4 inboxes — set INBOX_1..4_HOST/_USER/_PASS.');
INSERT INTO tools VALUES('tool-slack','Slack','Comms','available','#a3a3a3','Client implemented. Needs a bot token with channels:read/history scopes.');
INSERT INTO tools VALUES('tool-wispr','Wispr Flow','Comms','connected','#fafafa','Voice dictation — heaviest daily-use tool found. Local flow.sqlite read live.');
INSERT INTO tools VALUES('tool-whatsapp','WhatsApp','Comms','connected','#fafafa','Desktop app local ChatStorage.sqlite, read-only: 600+ chats incl. LC + Vantage teams.');
INSERT INTO tools VALUES('tool-command-center','Command Center (:4000)','Orchestration','available','#d4d4d4','clawdbot-command-center: kanban, brand deals, sales calls, SOPs, dispatch. Start with npm run dev.');
INSERT INTO tools VALUES('tool-openclaw','OpenClaw Gateway','Orchestration','available','#737373','Dormant — gateway :18789 down, token exists at ~/.openclaw/openclaw.json. Needs repair/reinstall.');
INSERT INTO tools VALUES('tool-tmux','tmux','Orchestration','connected','#a3a3a3','Multi-Claude session orchestration. Dashboard reads live session list.');
INSERT INTO tools VALUES('tool-ollama','Ollama','Orchestration','available','#a3a3a3','Local LLM server :11434. Stopped 2026-08-20 to free the machine; the stack check no longer probes it. Start it to enable free local inference.');
INSERT INTO tools VALUES('tool-vercel','Vercel CLI','Orchestration','connected','#a3a3a3','v50, authenticated. Deploy target when ALEX OS goes public.');
INSERT INTO tools VALUES('tool-gh','GitHub CLI','Orchestration','connected','#737373','gh 2.89, authenticated.');
INSERT INTO tools VALUES('tool-paypal','PayPal','Payments','planned','#a3a3a3','Registered in the processor registry; client lands when keys do.');
INSERT INTO tools VALUES('tool-square','Square','Payments','planned','#737373','Registered in the processor registry; client lands when keys do.');
INSERT INTO tools VALUES('tool-whop','Whop','Payments','planned','#525252','Registered in the processor registry; client lands when keys do.');
CREATE TABLE roadmap_items (
  id TEXT PRIMARY KEY,
  title TEXT NOT NULL,
  quarter TEXT NOT NULL,
  status TEXT NOT NULL,
  department_id TEXT,
  description TEXT NOT NULL DEFAULT '',
  phase_id TEXT
);
CREATE TABLE metrics (
  id TEXT PRIMARY KEY,
  key TEXT NOT NULL UNIQUE,
  label TEXT NOT NULL,
  value REAL NOT NULL,
  unit TEXT NOT NULL DEFAULT '',
  delta REAL NOT NULL DEFAULT 0,
  period TEXT NOT NULL DEFAULT ''
);
INSERT INTO metrics VALUES('metric-unread','unread_total','Unread (all inboxes)',0.0,'emails',0.0,'pending creds');
INSERT INTO metrics VALUES('metric-brain','brain_pages','Brain-store Pages',0.0,'pages',0.0,'run Data Agent');
INSERT INTO metrics VALUES('metric-balance','stripe_available','Stripe Available',0.0,'usd',0.0,'pending creds');
INSERT INTO metrics VALUES('metric-runs','agent_runs','Agent Runs Logged',0.0,'runs',0.0,'all time');
CREATE TABLE domains (
  id TEXT PRIMARY KEY,
  number INTEGER NOT NULL,
  title TEXT NOT NULL,
  color TEXT NOT NULL,
  items TEXT NOT NULL DEFAULT '[]'
);
CREATE TABLE personas (
  id TEXT PRIMARY KEY,
  ord INTEGER NOT NULL,
  name TEXT NOT NULL,
  archetype TEXT NOT NULL,
  tagline TEXT NOT NULL,
  summary TEXT NOT NULL,
  accent TEXT NOT NULL,
  north_star TEXT NOT NULL,
  pillars TEXT NOT NULL DEFAULT '[]',
  connectors TEXT NOT NULL DEFAULT '[]',
  metrics TEXT NOT NULL DEFAULT '[]',
  brain_use TEXT NOT NULL,
  signature_play TEXT NOT NULL
);
INSERT INTO personas VALUES('persona-marketing-agency',1,'Agency Owner','Agency Operator','Runs 14 client retainers on a 4-person team without dropping a ball','A marketing/creative agency owner who lives in client delivery, new-business pipeline, and reporting. This OS variant turns a small team''s chaos into a watched factory line: every retainer''s scope, deadlines, deliverables, and monthly report run on rails so nothing slips and no client churns silently.','#3df08c','Net retainer MRR retained (revenue kept, not just won)','[{"name":"New Business","focus":"Lead-to-signed-retainer pipeline and proposals","agents":["Pipeline Bot","Proposal Drafter","Discovery Scheduler","Win-Loss Logger"]},{"name":"Client Delivery","focus":"Retainer scope, deadlines, and deliverables across every account","agents":["Account Pilot","Deadline Sentinel","Scope Guard","QA Reviewer"]},{"name":"Creative Studio","focus":"Asset production, brand consistency, and approvals","agents":["Brief Builder","Asset Wrangler","Brand Cop","Approval Chaser"]},{"name":"Reporting & Retention","focus":"Monthly client reports, health scores, and churn defense","agents":["Report Compiler","Health Scorer","Churn Sentinel","QBR Prep"]},{"name":"Agency Ops","focus":"Team utilization, billing, and margin per account","agents":["Capacity Planner","Invoice Runner","Margin Watch","Time Auditor"]}]','["HubSpot CRM","Asana","Slack","Google Analytics 4","Meta Ads Manager","Google Ads","Harvest","QuickBooks Online"]','["Net retainer MRR","Client health score","On-time delivery rate","Team utilization %","Gross margin per account"]','Every agent reads the shared G-Brain for each client''s brand guidelines, scope-of-work, past approvals, and account history, so proposals, creative, and reports all speak in the right voice without re-briefing.','On the 1st of each month, Report Compiler pulls GA4, Meta, and Google Ads numbers for all active retainers, drafts a branded report per client in their voice, and Health Scorer flags any account trending toward churn so the owner walks into every QBR already knowing who''s at risk and who to upsell.');
INSERT INTO personas VALUES('persona-brick-and-mortar',2,'Multi-Location Operator','Brick-and-Mortar Founder','6 locations, one floor view — labor, inventory, reviews, traffic.','A multi-unit restaurant + retail founder running six rooftops from one console. The OS turns POS, labor, inventory, and local-reputation feeds into a single floor view so every store runs to target whether or not the owner is on-site.','#5ec9f8','Same-store sales per labor hour, blended across all locations','[{"name":"Floor Ops","focus":"Staffing, shifts, and labor cost per location","agents":["Dispatch Bot","Shift Filler","Labor Cop"]},{"name":"Inventory & Cost","focus":"Stock, COGS, vendor invoices, waste","agents":["Count Keeper","Invoice Reconciler","Waste Watcher","Reorder Bot"]},{"name":"Local Reputation","focus":"Reviews, local search, and listings across units","agents":["Review Harvester","Reply Bot","Listing Sentry"]},{"name":"Foot Traffic & Sales","focus":"Door count, throughput, daypart sales, loyalty","agents":["Traffic Counter","Daypart Analyst","Loyalty Driver"]},{"name":"Back Office","focus":"Payments, payroll, cash, multi-entity P&L","agents":["Settlement Bot","Payroll Runner","P&L Closer"]}]','["Toast POS","7shifts","Square","MarginEdge","Google Business Profile","Gusto","QuickBooks Online","G-Brain"]','["Same-store sales (YoY)","Labor cost % of sales","Food cost % (COGS)","Avg Google rating + review velocity","Door count vs conversion to ticket"]','Every agent reads the shared G-Brain — par levels, vendor terms, recipe costs, opening checklists, and per-store playbooks — so a fix at one location becomes the standard at all six.','Before open, the OS pulls last night''s Toast sales and today''s 7shifts roster, forecasts each store''s covers by daypart, flags any location running over labor target, auto-pings Shift Filler to cover call-outs, and drops a one-line per-store readiness brief — staffed, stocked, and reviews replied — on the owner''s phone by 7am.');
INSERT INTO personas VALUES('persona-ecommerce-dtc',3,'DTC Brand Operator','DTC Operator','One operator running a Shopify brand on margin, not vibes.','A solo ecommerce/DTC brand owner running a Shopify storefront, paid acquisition, 3PL fulfillment, and email/SMS retention from one deck. This OS variant watches contribution margin per order in real time and lets agents kill losing ad sets, chase abandoned carts, and flag stockouts before they cost a launch.','#e1306c','Contribution margin after ad spend (per order, blended)','[{"name":"Acquisition","focus":"Paid ads + traffic — spend that buys profitable orders","agents":["Spend Sentinel","Creative Tester","Attribution Bot"]},{"name":"Storefront & CRO","focus":"Shopify catalog, PDP, checkout, conversion rate","agents":["Catalog Bot","CRO Tester","Cart Recovery Bot"]},{"name":"Retention","focus":"Email/SMS flows, LTV, repeat-purchase engine","agents":["Flow Builder","Winback Bot","Review Harvester"]},{"name":"Fulfillment & Ops","focus":"Inventory, 3PL, shipping SLAs, stockout defense","agents":["Stockout Sentinel","Dispatch Bot","Returns Triage"]},{"name":"Margin & Finance","focus":"Unit economics, COGS, blended CAC, cash","agents":["Margin Watch","CAC Auditor","Reconcile Bot"]}]','["Shopify","Meta Ads Manager","Google Ads","TikTok Ads","Klaviyo","Postscript","ShipBob (3PL)","Stripe"]','["Contribution margin / order","Blended ROAS","CAC vs 60-day LTV","Repeat-purchase rate","Days of inventory on hand"]','Every agent reads from one shared G-Brain holding SKU economics, brand voice, hero-creative learnings, and customer segments — so a winning ad angle instantly informs Klaviyo flows and PDP copy.','Spend Sentinel cross-checks each ad set''s spend against real contribution margin from Shopify+COGS overnight, auto-pauses anything underwater, reallocates budget to the profitable hero creative, and fires a Klaviyo/Postscript winback to yesterday''s abandoned carts — so the operator wakes up to a brand that already cut its losers and chased its money.');
INSERT INTO personas VALUES('persona-online-coach',4,'Personal Online Coach','Transformation Coach','Clients win, stay, and refer — the practice runs itself.','A 1:1 and group transformation coach (fitness/health/mindset) running a hybrid book of premium private clients plus cohort programs. This OS variant turns coaching into an operating system: every lead nurtured, every client onboarded, every check-in answered, every at-risk client caught, and every win turned into a referral or testimonial.','#ffc53d','Active retained clients × 90-day transformation rate','[{"name":"Acquisition","focus":"Turn leads and discovery calls into signed clients","agents":["Lead Catcher","Booking Bot","Close Tracker"]},{"name":"Onboarding & Delivery","focus":"Intake, program build, and getting clients moving day one","agents":["Intake Bot","Program Builder","Loom Recap Bot"]},{"name":"Accountability & Results","focus":"Check-ins, habit streaks, and tracking transformation data","agents":["Check-in Bot","Streak Sentinel","Results Logger"]},{"name":"Retention & Renewals","focus":"Catch churn risk, drive renewals, harvest wins","agents":["Churn Sentinel","Renewal Closer","Win Harvester"]},{"name":"Brand & Lead-Gen","focus":"Content, community, and referral engine that fills the pipeline","agents":["Content Bot","Community Bot","Referral Bot"]}]','["Trainerize","Calendly","Stripe","Kajabi","Typeform","WhatsApp","Loom","Circle"]','["Active retained clients","90-day transformation rate","Check-in response rate","Renewal rate","Referral / testimonial count"]','Every agent reads one shared client brain — goals, injuries, macros, milestones, and last-conversation context — so check-ins, recaps, and renewals all sound like the coach who actually knows them.','Every client check-in is auto-pulled, scored against their goals, and either gets a personalized voice/text reply drafted or fires a churn flag — so nobody goes silent, no win goes uncaptured, and every transformation becomes a testimonial and a referral ask.');
INSERT INTO personas VALUES('persona-saas-founder',5,'SaaS Founder OS','SaaS Founder','Solo indie SaaS founder running product, growth, and MRR on autopilot','A bootstrapped indie software founder running a self-serve SaaS solo. This OS variant turns the whole funnel — signup to expansion to churn-save — into a closed loop of named agents so one person operates like a Series A growth team.','#a855f7','Net MRR growth (new + expansion − churn)','[{"name":"Acquisition","focus":"Top-of-funnel growth loops, SEO, and trial signups","agents":["Loop Engine","SEO Crawler","Trial Capture"]},{"name":"Activation","focus":"Onboarding new signups to first value (aha moment)","agents":["Onboarding Bot","Aha Tracker","Setup Nudger"]},{"name":"Retention","focus":"Churn prediction and win-back before cancellation","agents":["Churn Sentinel","Win-Back Agent","Expansion Hunter"]},{"name":"Support","focus":"Inbox triage, ticket deflection, and docs from real tickets","agents":["Ticket Triage","Deflection Bot","Docs Synth"]},{"name":"Revenue Ops","focus":"MRR, dunning, and every billing event in one view","agents":["MRR Pulse","Dunning Agent","Churn Accountant"]}]','["Stripe Billing","Intercom","PostHog","Customer.io","Linear","Ahrefs","Slack","G-Brain"]','["Net MRR","Trial-to-paid conversion %","Net revenue retention","Logo + revenue churn %","Activation rate (time-to-aha)"]','Every agent reads and writes the same G-Brain core — feature decisions, churn reasons, support answers, and onboarding playbooks — so a support reply, a docs page, and a win-back email all speak with one product memory.','Churn Sentinel watches PostHog usage decay + Stripe billing signals, scores at-risk accounts nightly, then fires Win-Back Agent to send a personalized Customer.io save offer and opens a Linear issue on the feature gap that caused the churn — a full detect-save-fix loop with no founder in the seat.');
INSERT INTO personas VALUES('persona-real-estate',6,'Real Estate Team Lead','Broker-Operator','Runs a producing team: leads in, listings up, deals closed.','A team lead / managing broker running a high-volume residential team. This OS variant turns a leaky lead-to-close pipeline into a machine: leads get worked in 60 seconds, listings get launched and syndicated, showings stay booked, and every transaction crosses the finish line with nothing falling through.','#22c55e','Net closed GCI per quarter (commission off closed-and-funded deals)','[{"name":"Lead Gen & Conversion","focus":"Inbound buyer/seller leads to booked appointments","agents":["Speed-to-Lead Bot","Drip Nurturer","ISA Caller"]},{"name":"Listings & Marketing","focus":"List, price, launch, and syndicate every property","agents":["Listing Launcher","CMA Pricer","Syndication Bot","Open House Bot"]},{"name":"Showings & Transactions","focus":"Showings booked and deals driven to close","agents":["Showing Scheduler","Deal Driver","Compliance Hawk"]},{"name":"Team & Accountability","focus":"Agent production, splits, and pipeline coverage","agents":["Roster Tracker","Lead Router","Split Calculator"]},{"name":"Client Care & Database","focus":"Past clients, reviews, and repeat/referral business","agents":["Review Harvester","SOI Reactivator","Closing Concierge"]}]','["MLS / RESO Web API","Follow Up Boss","dotloop","ShowingTime","Zillow Premier Agent","BombBomb"]','["Speed-to-lead (avg first-touch time)","Lead-to-appointment conversion %","Active listings + days on market","Pending-to-close ratio","GCI pipeline (pending + closed)"]','One shared G-Brain holds every lead''s history, property notes, pricing comps, and past-client relationships so any agent answering a call or text already knows the full context.','A Zillow lead hits the system at 11pm: Speed-to-Lead Bot texts within 60 seconds, qualifies budget and timeline against G-Brain, routes the hot one to the on-duty agent and books the showing in ShowingTime before the lead ever calls a competitor.');
INSERT INTO personas VALUES('persona-course-creator',7,'Course Creator / Info-Product Operator','Course Creator','Cohorts, evergreen funnels, and student wins on autopilot.','An info-product seller running paid cohorts and an always-on evergreen funnel. This OS variant orchestrates launches, keeps students completing the material, and harvests testimonials and affiliate revenue — so enrollments compound without the founder living in the dashboard.','#f59e0b','Enrollment revenue x student completion rate (revenue that actually finishes the course)','[{"name":"Funnel & Launch","focus":"Evergreen funnel + live launch carts, urgency, and cart-open ops","agents":["Cart Sentinel","Launch Conductor","Webinar Bot","Deadline Driver"]},{"name":"Audience & Content","focus":"Top-of-funnel content, lead magnets, and list growth that feeds the funnel","agents":["Lead-Magnet Bot","Content Repurposer","List Builder"]},{"name":"Student Success","focus":"Onboarding, completion nudges, community engagement, testimonial harvest","agents":["Onboarding Bot","Completion Sentinel","Win Harvester","Community Pulse"]},{"name":"Money & Recovery","focus":"Checkout revenue, payment plans, failed-payment dunning, refund/chargeback watch","agents":["Checkout Pulse","Dunning Bot","Refund Watch"]},{"name":"Affiliates & Partners","focus":"Affiliate recruiting, swipe copy, commission tracking, JV launch ops","agents":["Affiliate Recruiter","Commission Bot","Swipe Smith"]}]','["Kajabi","ThriveCart","ConvertKit","Circle","Deadline Funnel","Stripe","Zoom","PartnerStack"]','["Cart conversion rate","Course completion rate","Email list growth + EPC","Refund / chargeback rate","Affiliate-driven revenue %"]','Every agent reads from one shared G-Brain holding the course curriculum, swipe copy, student FAQs, objection-handling scripts, and past launch numbers — so onboarding nudges, sales replies, and affiliate swipe all speak in one consistent voice.','An evergreen launch loop: Deadline Driver opens a personal-deadline cart the moment a lead finishes the webinar, Cart Sentinel fires ConvertKit sequences and Dunning Bot rescues failed payment-plan charges, while Completion Sentinel pushes the new student to module 3 and Win Harvester captures the testimonial the instant they post a win in Circle — turning one enrollment into the proof that sells the next.');
INSERT INTO personas VALUES('persona-local-service',8,'Field Service OS','Home-Services Operator','Owner of the truck-and-tools shop. Every job booked, dispatched, paid.','A local HVAC/plumbing/contractor owner running a fleet of trucks. This OS variant turns the phone-and-whiteboard chaos of a service business into a closed loop: a missed call becomes a booked job, a booked job becomes a routed tech, a finished job becomes a paid invoice and a 5-star review, and every customer rolls into a recurring maintenance plan.','#0a85c2','Booked revenue per truck-day (jobs completed × average ticket, against capacity).','[{"name":"Intake & Booking","focus":"Turn every inbound call, form, and missed call into a booked job slot","agents":["Intake Bot","Missed-Call Catcher","Slot Booker"]},{"name":"Dispatch & Field Ops","focus":"Route the right tech to the right job and keep the board full","agents":["Dispatch Bot","Route Optimizer","Tech Tracker","On-My-Way Texter"]},{"name":"Quotes & Close","focus":"Build estimates fast, chase pending quotes, win the job","agents":["Estimate Builder","Quote Chaser","Upsell Prompter"]},{"name":"Money & Plans","focus":"Invoice on completion, collect payment, enroll recurring maintenance","agents":["Invoice Closer","Collections Bot","Maintenance Enroller","AR Sentinel"]},{"name":"Reputation & Repeat","focus":"Harvest reviews, win back lapsed customers, defend the local rank","agents":["Review Harvester","Reputation Guard","Win-Back Bot"]}]','["Housecall Pro","Jobber","ServiceTitan","CallRail","Stripe","QuickBooks Online","Google Business Profile","Twilio"]','["Booked revenue per truck-day","Call-to-booked conversion %","Average ticket","Quote win rate","Maintenance plan active members"]','Every agent reads one shared G-Brain core holding the price book, service-area map, tech skills/certs, warranty terms, and per-customer equipment history, so quotes, dispatch, and follow-ups all speak with the same numbers and the same memory of every property.','The missed-call-to-paid loop: a call that rings out at 7pm gets an instant text-back, books a next-day slot, auto-routes the nearest qualified tech, fires the "on my way" SMS at dawn, drops the invoice the second the job is marked complete, takes the card, and ten minutes later sends the review request — owner never touches the phone.');
INSERT INTO personas VALUES('persona-fractional-exec',9,'Fractional Exec OS','Fractional Operator','One part-time exec, six client orgs, run like one shop.','A fractional CFO/COO running advisory retainers across a portfolio of 6-8 client companies — selling frameworks and judgment, not hours. This OS variant keeps every retainer fed, every deliverable shipped on cadence, and every relationship warm enough to renew or refer, so utilization stays high without the operator living in their inbox.','#ff6259','Monthly recurring retainer revenue (MRR) at >85% portfolio utilization','[{"name":"Pipeline & Retainers","focus":"Inbound leads, scoping calls, proposals, and retainer renewals","agents":["Scope Bot","Proposal Drafter","Renewal Watchdog","Referral Tracer"]},{"name":"Client Delivery","focus":"Per-client workrooms, deliverables, and cadence on every active retainer","agents":["Engagement Lead","Deliverable Forge","Cadence Keeper","Status Reporter"]},{"name":"Thought Leadership","focus":"LinkedIn essays, newsletter, talks — the demand engine that feeds pipeline","agents":["Essay Drafter","Hook Miner","Repurpose Bot"]},{"name":"Practice Finance","focus":"Retainer invoicing, AR aging, utilization, and effective hourly across the book","agents":["Invoice Runner","AR Chaser","Utilization Auditor"]},{"name":"Relationship Ops","focus":"Every client/prospect inbox and DM into one triaged queue with context","agents":["Inbox Triage","Meeting Prep Bot","Follow-up Sentinel"]}]','["Attio (CRM)","Gmail","Calendly","Notion (client workrooms)","Stripe (retainer billing)","QuickBooks","LinkedIn","Fathom (call notes)"]','["Retainer MRR","Portfolio utilization %","Net revenue retention","Pipeline coverage (3x rule)","Effective hourly rate"]','Every client''s frameworks, decisions, board context, and prior deliverables live in one G-Brain so any agent drafts in that client''s voice and never re-asks what was already decided.','After each client call, the Fathom transcript hits G-Brain, Deliverable Forge drafts the next memo/model in that client''s house style, Status Reporter posts the workroom update, and Cadence Keeper books the follow-up — the engagement advances before the operator''s next call ends.');
INSERT INTO personas VALUES('persona-community-operator',10,'Membership Community Operator','Community Operator','Creator running a paid membership — keep them in, keep them showing up.','A creator who turned an audience into a paid membership/community — recurring members, weekly live calls, a structured curriculum, and an always-on community feed. This OS variant runs the whole retention machine: it watches who''s drifting, fills every event seat, keeps the content cadence on schedule, and saves at-risk subscriptions before the card declines.','#8b7cff','Net MRR retention — members kept and expanded month over month','[{"name":"Membership Growth","focus":"Trials, waitlist, and free-to-paid conversion into the community","agents":["Waitlist Warden","Trial Closer","Referral Engine"]},{"name":"Retention & Churn","focus":"At-risk detection, dunning recovery, and cancel saves","agents":["Churn Sentinel","Dunning Recovery Bot","Win-Back Agent"]},{"name":"Community & Engagement","focus":"Daily feed health, member onboarding, and active-member streaks","agents":["Onboarding Concierge","Engagement Pulse","Ghost Hunter"]},{"name":"Events & Live","focus":"Weekly calls, RSVPs, attendance, and replay distribution","agents":["RSVP Wrangler","Live Producer","Replay Cutter"]},{"name":"Content & Curriculum","focus":"Drip schedule, lesson cadence, and member-only content pipeline","agents":["Drip Scheduler","Curriculum Keeper","Digest Writer"]}]','["Circle","Stripe Billing","ConvertKit","Discord","Zoom Webinars","Memberful","Calendly","G-Brain"]','["Net MRR retention","Monthly churn rate","Active-member rate (WAU/MAU)","Live-call attendance rate","Trial-to-paid conversion"]','Every agent reads one shared member memory — each person''s join date, tier, engagement history, last login, and save/win-back attempts — so saves, onboarding, and event nudges are personal instead of generic blasts.','Churn Sentinel flags a member who hasn''t logged in for 14 days and skipped two live calls, pulls their history from G-Brain, then fires a personalized win-back from Win-Back Agent and re-invites them to the next event via RSVP Wrangler — catching the lapse weeks before the renewal date instead of eating the cancel.');
INSERT INTO personas VALUES('persona-law-firm',11,'Boutique Law Firm OS','Managing Attorney','Every matter moved, every hour captured, every deadline safe.','A solo or small-firm managing attorney running a full caseload across intake, matter management, billing, and compliance. This OS variant turns a stack of open files into a watched docket: every deadline calculated, every billable minute captured, every trust dollar accounted for, and every client kept in the loop so nothing slips and no matter goes stale.','#b8860b','Collected realization rate (billed hours that actually get paid) at zero missed deadlines','[{"name":"Intake & Conflicts","focus":"Screen inquiries, clear conflicts, and sign engagements","agents":["Intake Screener","Conflict Checker","Engagement Drafter","Retainer Collector"]},{"name":"Matter Management","focus":"Every open matter''s tasks, deadlines, and court dates on rails","agents":["Matter Pilot","Docket Sentinel","Task Router","Limitations Watch"]},{"name":"Documents & Drafting","focus":"Draft, assemble, and review documents from templates and precedent","agents":["Draft Assembler","Clause Librarian","Redline Reviewer","e-Filing Bot"]},{"name":"Billing & Trust","focus":"Capture time, bill on cadence, and keep trust accounting clean","agents":["Time Capturer","Invoice Runner","Trust Ledger Guard","Collections Chaser"]},{"name":"Compliance & Client Care","focus":"Statutory deadlines, ethics compliance, and client communication","agents":["Deadline Guardian","CLE Tracker","Client Update Bot","Review Harvester"]}]','["Clio (practice management)","LawPay","NetDocuments","Lexis+ / Westlaw","Microsoft 365 (Outlook)","DocuSign","Court e-Filing (PACER / state)","QuickBooks Online"]','["Realization rate (billed vs collected)","Billable hours captured per attorney","Matters opened vs closed","Days to invoice (WIP aging)","Deadline / limitations compliance (missed = 0)"]','One shared G-Brain holds every matter''s facts, precedent, prior filings, client history, and firm playbooks, so any agent drafts from the firm''s own work product and never re-researches settled ground.','A new inquiry hits the system: Conflict Checker clears it against the client and matter graph in G-Brain, Engagement Drafter generates the retainer and fee agreement in the firm''s language, Retainer Collector takes the deposit through LawPay into the trust account, and Docket Sentinel opens the matter with every statutory deadline pre-calculated from the jurisdiction''s rules, so the attorney reviews and signs instead of building the file from scratch.');
CREATE TABLE phases (
  id TEXT PRIMARY KEY,
  number INTEGER NOT NULL,
  title TEXT NOT NULL,
  items TEXT NOT NULL DEFAULT '[]'
);
CREATE TABLE agent_runs (
  id TEXT PRIMARY KEY,
  agent_id TEXT NOT NULL,
  started_at TEXT NOT NULL,
  finished_at TEXT NOT NULL,
  ok INTEGER NOT NULL,
  summary TEXT NOT NULL DEFAULT ''
, model TEXT, tokens_in INTEGER, tokens_out INTEGER, cost_usd REAL);
INSERT INTO agent_runs VALUES('seed-run-conductor-0','conductor','2026-09-23T07:24:19.160Z','2026-09-23T07:24:25.790Z',1,'Conductor completed a run.','claude-sonnet-5',12108,980,0.05102399999999999992);
INSERT INTO agent_runs VALUES('seed-run-conductor-1','conductor','2026-09-22T09:03:49.902Z','2026-09-22T09:03:53.039Z',0,'Conductor run failed and was retried.','claude-sonnet-5',3296,2092,0.04126799999999999913);
INSERT INTO agent_runs VALUES('seed-run-conductor-2','conductor','2026-09-18T15:52:18.066Z','2026-09-18T15:52:24.490Z',1,'Conductor completed a run.','claude-sonnet-5',9280,1331,0.04780500000000000027);
INSERT INTO agent_runs VALUES('seed-run-conductor-3','conductor','2026-09-22T06:40:57.531Z','2026-09-22T06:40:59.829Z',1,'Conductor completed a run.','claude-sonnet-5',9673,2225,0.06239399999999999808);
INSERT INTO agent_runs VALUES('seed-run-conductor-4','conductor','2026-09-13T10:54:28.713Z','2026-09-13T10:54:31.426Z',1,'Conductor completed a run.','claude-sonnet-5',4905,3760,0.07111499999999999766);
INSERT INTO agent_runs VALUES('seed-run-conductor-5','conductor','2026-09-17T12:02:41.324Z','2026-09-17T12:02:44.095Z',1,'Conductor completed a run.','claude-sonnet-5',1512,3551,0.05780099999999999822);
INSERT INTO agent_runs VALUES('seed-run-conductor-6','conductor','2026-09-26T08:40:22.198Z','2026-09-26T08:40:25.562Z',1,'Conductor completed a run.','claude-sonnet-5',12836,1116,0.0552479999999999985);
INSERT INTO agent_runs VALUES('seed-run-conductor-7','conductor','2026-09-21T20:00:48.142Z','2026-09-21T20:00:49.895Z',1,'Conductor completed a run.','claude-sonnet-5',6640,2640,0.05952000000000000345);
INSERT INTO agent_runs VALUES('seed-run-conductor-8','conductor','2026-09-13T04:52:49.367Z','2026-09-13T04:52:50.741Z',0,'Conductor run failed and was retried.','claude-sonnet-5',1927,391,0.0116460000000000001);
INSERT INTO agent_runs VALUES('seed-run-conductor-9','conductor','2026-09-14T02:26:39.067Z','2026-09-14T02:26:41.402Z',1,'Conductor completed a run.','claude-sonnet-5',2041,413,0.01231800000000000082);
INSERT INTO agent_runs VALUES('seed-run-conductor-10','conductor','2026-09-28T14:47:48.004Z','2026-09-28T14:47:53.367Z',1,'Conductor completed a run.','claude-sonnet-5',7352,1889,0.0503909999999999983);
INSERT INTO agent_runs VALUES('seed-run-conductor-11','conductor','2026-09-15T01:47:00.562Z','2026-09-15T01:47:02.204Z',1,'Conductor completed a run.','claude-sonnet-5',14350,4075,0.1041750000000000037);
INSERT INTO agent_runs VALUES('seed-run-conductor-12','conductor','2026-09-20T09:56:20.983Z','2026-09-20T09:56:26.686Z',1,'Conductor completed a run.','claude-sonnet-5',7835,3905,0.08208000000000000018);
INSERT INTO agent_runs VALUES('seed-run-comms-digest-0','comms-digest','2026-09-23T11:25:14.967Z','2026-09-23T11:25:20.213Z',1,'Comms Digest completed a run.','claude-sonnet-5',7715,2778,0.06481499999999999762);
INSERT INTO agent_runs VALUES('seed-run-comms-digest-1','comms-digest','2026-09-27T16:51:09.858Z','2026-09-27T16:51:16.507Z',1,'Comms Digest completed a run.','claude-sonnet-5',13995,2504,0.07954500000000000459);
INSERT INTO agent_runs VALUES('seed-run-comms-digest-2','comms-digest','2026-09-16T05:33:32.739Z','2026-09-16T05:33:38.051Z',1,'Comms Digest completed a run.','claude-sonnet-5',12884,981,0.05336699999999999778);
INSERT INTO agent_runs VALUES('seed-run-comms-digest-3','comms-digest','2026-09-17T04:52:53.938Z','2026-09-17T04:53:01.077Z',1,'Comms Digest completed a run.','claude-sonnet-5',3681,4043,0.07168800000000000172);
INSERT INTO agent_runs VALUES('seed-run-comms-digest-4','comms-digest','2026-09-12T21:17:06.754Z','2026-09-12T21:17:12.196Z',1,'Comms Digest completed a run.','claude-sonnet-5',11662,3951,0.0942510000000000014);
INSERT INTO agent_runs VALUES('seed-run-comms-digest-5','comms-digest','2026-09-20T08:45:07.930Z','2026-09-20T08:45:10.647Z',1,'Comms Digest completed a run.','claude-sonnet-5',11614,649,0.04457699999999999857);
INSERT INTO agent_runs VALUES('seed-run-comms-digest-6','comms-digest','2026-09-29T11:27:41.739Z','2026-09-29T11:27:44.881Z',0,'Comms Digest run failed and was retried.','claude-sonnet-5',6294,2026,0.04927200000000000329);
INSERT INTO agent_runs VALUES('seed-run-comms-digest-7','comms-digest','2026-09-13T07:30:48.599Z','2026-09-13T07:30:50.692Z',1,'Comms Digest completed a run.','claude-sonnet-5',4243,1212,0.03090899999999999898);
INSERT INTO agent_runs VALUES('seed-run-comms-digest-8','comms-digest','2026-09-13T15:52:21.138Z','2026-09-13T15:52:21.588Z',1,'Comms Digest completed a run.','claude-sonnet-5',11957,1117,0.05262599999999999917);
INSERT INTO agent_runs VALUES('seed-run-comms-digest-9','comms-digest','2026-09-25T20:01:43.860Z','2026-09-25T20:01:49.844Z',1,'Comms Digest completed a run.','claude-sonnet-5',5388,2540,0.05426399999999999974);
INSERT INTO agent_runs VALUES('seed-run-comms-digest-10','comms-digest','2026-09-17T03:43:19.613Z','2026-09-17T03:43:20.661Z',1,'Comms Digest completed a run.','claude-sonnet-5',11243,1208,0.05184899999999999926);
INSERT INTO agent_runs VALUES('seed-run-comms-digest-11','comms-digest','2026-09-26T21:48:37.515Z','2026-09-26T21:48:44.755Z',1,'Comms Digest completed a run.','claude-sonnet-5',3745,1422,0.03256499999999999672);
INSERT INTO agent_runs VALUES('seed-run-comms-digest-12','comms-digest','2026-09-22T16:57:35.896Z','2026-09-22T16:57:38.109Z',1,'Comms Digest completed a run.','claude-sonnet-5',12303,3423,0.08825399999999999912);
INSERT INTO agent_runs VALUES('seed-run-comms-digest-13','comms-digest','2026-09-24T01:22:02.852Z','2026-09-24T01:22:06.171Z',1,'Comms Digest completed a run.','claude-sonnet-5',4935,4166,0.07729500000000000259);
INSERT INTO agent_runs VALUES('seed-run-comms-agent-0','comms-agent','2026-09-26T05:58:26.704Z','2026-09-26T05:58:29.976Z',1,'Comms Agent completed a run.','claude-sonnet-5',3043,2072,0.04020900000000000168);
INSERT INTO agent_runs VALUES('seed-run-comms-agent-1','comms-agent','2026-09-19T01:45:17.644Z','2026-09-19T01:45:19.577Z',1,'Comms Agent completed a run.','claude-sonnet-5',1958,2424,0.0422340000000000007);
INSERT INTO agent_runs VALUES('seed-run-comms-agent-2','comms-agent','2026-09-17T14:10:37.949Z','2026-09-17T14:10:38.805Z',1,'Comms Agent completed a run.','claude-sonnet-5',5709,3640,0.0717269999999999991);
INSERT INTO agent_runs VALUES('seed-run-comms-agent-3','comms-agent','2026-09-14T17:23:46.459Z','2026-09-14T17:23:48.055Z',1,'Comms Agent completed a run.','claude-sonnet-5',9817,1180,0.04715099999999999847);
INSERT INTO agent_runs VALUES('seed-run-comms-agent-4','comms-agent','2026-09-22T21:30:56.688Z','2026-09-22T21:30:59.669Z',1,'Comms Agent completed a run.','claude-sonnet-5',10454,229,0.03479700000000000154);
INSERT INTO agent_runs VALUES('seed-run-gmail-worker-0','gmail-worker','2026-09-26T18:48:28.635Z','2026-09-26T18:48:32.758Z',1,'Gmail Worker completed a run.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-gmail-worker-1','gmail-worker','2026-09-13T15:43:26.253Z','2026-09-13T15:43:31.392Z',0,'Gmail Worker run failed and was retried.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-gmail-worker-2','gmail-worker','2026-09-14T07:43:12.458Z','2026-09-14T07:43:18.017Z',1,'Gmail Worker completed a run.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-gmail-worker-3','gmail-worker','2026-09-25T14:01:41.383Z','2026-09-25T14:01:47.766Z',1,'Gmail Worker completed a run.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-gmail-worker-4','gmail-worker','2026-09-11T09:42:44.265Z','2026-09-11T09:42:49.450Z',1,'Gmail Worker completed a run.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-gmail-worker-5','gmail-worker','2026-09-17T05:51:35.567Z','2026-09-17T05:51:37.447Z',1,'Gmail Worker completed a run.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-gmail-worker-6','gmail-worker','2026-09-20T04:59:45.851Z','2026-09-20T04:59:50.105Z',1,'Gmail Worker completed a run.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-gmail-worker-7','gmail-worker','2026-09-21T12:59:33.246Z','2026-09-21T12:59:36.623Z',1,'Gmail Worker completed a run.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-gmail-worker-8','gmail-worker','2026-09-26T07:44:03.716Z','2026-09-26T07:44:04.549Z',0,'Gmail Worker run failed and was retried.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-whatsapp-worker-0','whatsapp-worker','2026-09-29T13:04:11.215Z','2026-09-29T13:04:12.698Z',1,'WhatsApp Worker completed a run.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-whatsapp-worker-1','whatsapp-worker','2026-09-13T06:18:42.519Z','2026-09-13T06:18:43.763Z',1,'WhatsApp Worker completed a run.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-whatsapp-worker-2','whatsapp-worker','2026-09-25T18:37:12.722Z','2026-09-25T18:37:14.090Z',1,'WhatsApp Worker completed a run.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-whatsapp-worker-3','whatsapp-worker','2026-09-19T20:13:42.288Z','2026-09-19T20:13:46.757Z',1,'WhatsApp Worker completed a run.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-whatsapp-worker-4','whatsapp-worker','2026-09-11T08:33:26.866Z','2026-09-11T08:33:31.325Z',1,'WhatsApp Worker completed a run.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-whatsapp-worker-5','whatsapp-worker','2026-09-11T08:23:11.925Z','2026-09-11T08:23:13.872Z',1,'WhatsApp Worker completed a run.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-whatsapp-worker-6','whatsapp-worker','2026-09-24T13:09:59.272Z','2026-09-24T13:10:01.551Z',1,'WhatsApp Worker completed a run.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-whatsapp-worker-7','whatsapp-worker','2026-09-12T03:50:30.719Z','2026-09-12T03:50:34.821Z',1,'WhatsApp Worker completed a run.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-whatsapp-worker-8','whatsapp-worker','2026-09-28T01:35:20.145Z','2026-09-28T01:35:22.844Z',1,'WhatsApp Worker completed a run.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-whatsapp-worker-9','whatsapp-worker','2026-09-22T11:39:04.685Z','2026-09-22T11:39:06.939Z',1,'WhatsApp Worker completed a run.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-slack-worker-0','slack-worker','2026-09-12T14:09:47.029Z','2026-09-12T14:09:49.856Z',1,'Slack Worker completed a run.','claude-haiku-4.5',13248,2022,0.01868600000000000121);
INSERT INTO agent_runs VALUES('seed-run-slack-worker-1','slack-worker','2026-09-22T06:28:20.484Z','2026-09-22T06:28:27.265Z',1,'Slack Worker completed a run.','claude-haiku-4.5',2047,1956,0.00946199999999999993);
INSERT INTO agent_runs VALUES('seed-run-slack-worker-2','slack-worker','2026-09-19T20:16:42.479Z','2026-09-19T20:16:43.484Z',1,'Slack Worker completed a run.','claude-haiku-4.5',10470,2010,0.01641600000000000003);
INSERT INTO agent_runs VALUES('seed-run-slack-worker-3','slack-worker','2026-09-25T12:02:53.726Z','2026-09-25T12:02:59.545Z',0,'Slack Worker run failed and was retried.','claude-haiku-4.5',7417,1842,0.01330199999999999959);
INSERT INTO agent_runs VALUES('seed-run-slack-worker-4','slack-worker','2026-09-14T00:53:54.372Z','2026-09-14T00:54:00.401Z',1,'Slack Worker completed a run.','claude-haiku-4.5',8674,1442,0.01270699999999999955);
INSERT INTO agent_runs VALUES('seed-run-social-agent-0','social-agent','2026-09-29T09:01:15.342Z','2026-09-29T09:01:16.424Z',1,'Social Agent completed a run.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-social-agent-1','social-agent','2026-09-21T01:44:55.623Z','2026-09-21T01:45:00.785Z',1,'Social Agent completed a run.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-social-agent-2','social-agent','2026-09-13T06:57:34.942Z','2026-09-13T06:57:36.700Z',0,'Social Agent run failed and was retried.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-social-agent-3','social-agent','2026-09-14T03:59:52.894Z','2026-09-14T03:59:57.872Z',1,'Social Agent completed a run.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-social-agent-4','social-agent','2026-09-17T11:18:57.903Z','2026-09-17T11:19:03.736Z',1,'Social Agent completed a run.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-social-agent-5','social-agent','2026-09-26T23:24:03.887Z','2026-09-26T23:24:08.002Z',1,'Social Agent completed a run.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-social-agent-6','social-agent','2026-09-26T23:38:18.649Z','2026-09-26T23:38:23.836Z',1,'Social Agent completed a run.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-brand-deal-agent-0','brand-deal-agent','2026-09-12T06:52:49.857Z','2026-09-12T06:52:52.482Z',1,'Brand Deal Agent completed a run.','claude-haiku-4.5',2299,4094,0.01821499999999999855);
INSERT INTO agent_runs VALUES('seed-run-brand-deal-agent-1','brand-deal-agent','2026-09-22T02:51:28.827Z','2026-09-22T02:51:33.267Z',1,'Brand Deal Agent completed a run.','claude-haiku-4.5',3689,591,0.005315000000000000279);
INSERT INTO agent_runs VALUES('seed-run-brand-deal-agent-2','brand-deal-agent','2026-09-14T22:11:08.113Z','2026-09-14T22:11:13.347Z',1,'Brand Deal Agent completed a run.','claude-haiku-4.5',12840,1879,0.01778800000000000173);
INSERT INTO agent_runs VALUES('seed-run-brand-deal-agent-3','brand-deal-agent','2026-09-22T20:53:50.031Z','2026-09-22T20:53:55.350Z',1,'Brand Deal Agent completed a run.','claude-haiku-4.5',4618,1026,0.007798000000000000243);
INSERT INTO agent_runs VALUES('seed-run-brand-deal-agent-4','brand-deal-agent','2026-09-10T08:24:46.268Z','2026-09-10T08:24:52.595Z',1,'Brand Deal Agent completed a run.','claude-haiku-4.5',13902,1622,0.01761000000000000065);
INSERT INTO agent_runs VALUES('seed-run-brand-deal-agent-5','brand-deal-agent','2026-09-17T10:21:47.202Z','2026-09-17T10:21:54.173Z',1,'Brand Deal Agent completed a run.','claude-haiku-4.5',5419,577,0.0066429999999999996);
INSERT INTO agent_runs VALUES('seed-run-brand-deal-agent-6','brand-deal-agent','2026-09-14T17:42:51.103Z','2026-09-14T17:42:53.395Z',1,'Brand Deal Agent completed a run.','claude-haiku-4.5',11709,1716,0.01623099999999999891);
INSERT INTO agent_runs VALUES('seed-run-brand-deal-agent-7','brand-deal-agent','2026-09-12T09:58:18.725Z','2026-09-12T09:58:20.731Z',1,'Brand Deal Agent completed a run.','claude-haiku-4.5',8191,3199,0.01934900000000000162);
INSERT INTO agent_runs VALUES('seed-run-brand-deal-agent-8','brand-deal-agent','2026-09-17T05:25:29.995Z','2026-09-17T05:25:33.780Z',1,'Brand Deal Agent completed a run.','claude-haiku-4.5',9209,814,0.01062300000000000049);
INSERT INTO agent_runs VALUES('seed-run-brand-deal-agent-9','brand-deal-agent','2026-09-25T17:23:33.281Z','2026-09-25T17:23:39.571Z',1,'Brand Deal Agent completed a run.','claude-haiku-4.5',5734,3022,0.01667499999999999886);
INSERT INTO agent_runs VALUES('seed-run-newsletter-agent-0','newsletter-agent','2026-09-17T06:35:03.320Z','2026-09-17T06:35:10.217Z',1,'Newsletter Agent completed a run.','claude-haiku-4.5',7909,3443,0.02009899999999999882);
INSERT INTO agent_runs VALUES('seed-run-newsletter-agent-1','newsletter-agent','2026-09-11T00:36:21.139Z','2026-09-11T00:36:22.966Z',1,'Newsletter Agent completed a run.','claude-haiku-4.5',1416,1491,0.007097000000000000009);
INSERT INTO agent_runs VALUES('seed-run-newsletter-agent-2','newsletter-agent','2026-09-19T21:18:29.714Z','2026-09-19T21:18:34.744Z',1,'Newsletter Agent completed a run.','claude-haiku-4.5',8774,547,0.009206999999999999907);
INSERT INTO agent_runs VALUES('seed-run-newsletter-agent-3','newsletter-agent','2026-09-11T12:55:07.836Z','2026-09-11T12:55:11.245Z',1,'Newsletter Agent completed a run.','claude-haiku-4.5',11406,1147,0.0137129999999999995);
INSERT INTO agent_runs VALUES('seed-run-newsletter-agent-4','newsletter-agent','2026-09-17T10:03:42.378Z','2026-09-17T10:03:46.953Z',1,'Newsletter Agent completed a run.','claude-haiku-4.5',6034,585,0.00716699999999999976);
INSERT INTO agent_runs VALUES('seed-run-newsletter-agent-5','newsletter-agent','2026-09-22T03:13:30.317Z','2026-09-22T03:13:36.532Z',0,'Newsletter Agent run failed and was retried.','claude-haiku-4.5',3064,2016,0.01051500000000000004);
INSERT INTO agent_runs VALUES('seed-run-newsletter-agent-6','newsletter-agent','2026-09-25T09:58:25.555Z','2026-09-25T09:58:26.009Z',1,'Newsletter Agent completed a run.','claude-haiku-4.5',9141,3405,0.02093300000000000021);
INSERT INTO agent_runs VALUES('seed-run-newsletter-agent-7','newsletter-agent','2026-09-10T15:49:59.602Z','2026-09-10T15:50:03.174Z',1,'Newsletter Agent completed a run.','claude-haiku-4.5',6689,895,0.008930999999999999703);
INSERT INTO agent_runs VALUES('seed-run-newsletter-agent-8','newsletter-agent','2026-09-10T10:05:40.256Z','2026-09-10T10:05:45.825Z',1,'Newsletter Agent completed a run.','claude-haiku-4.5',5929,1421,0.0104270000000000005);
INSERT INTO agent_runs VALUES('seed-run-newsletter-agent-9','newsletter-agent','2026-09-23T11:18:49.756Z','2026-09-23T11:18:50.600Z',1,'Newsletter Agent completed a run.','claude-haiku-4.5',4202,2631,0.01388600000000000077);
INSERT INTO agent_runs VALUES('seed-run-postly-publisher-0','postly-publisher','2026-09-26T12:07:49.950Z','2026-09-26T12:07:52.177Z',1,'Zernio Publisher completed a run.','claude-haiku-4.5',2713,3863,0.01762199999999999878);
INSERT INTO agent_runs VALUES('seed-run-postly-publisher-1','postly-publisher','2026-09-22T13:41:12.311Z','2026-09-22T13:41:13.102Z',1,'Zernio Publisher completed a run.','claude-haiku-4.5',9255,3992,0.02337200000000000041);
INSERT INTO agent_runs VALUES('seed-run-postly-publisher-2','postly-publisher','2026-09-15T10:08:55.569Z','2026-09-15T10:08:57.067Z',1,'Zernio Publisher completed a run.','claude-haiku-4.5',7121,3173,0.0183889999999999991);
INSERT INTO agent_runs VALUES('seed-run-postly-publisher-3','postly-publisher','2026-09-14T16:57:19.901Z','2026-09-14T16:57:23.739Z',1,'Zernio Publisher completed a run.','claude-haiku-4.5',4316,3545,0.01763299999999999937);
INSERT INTO agent_runs VALUES('seed-run-postly-publisher-4','postly-publisher','2026-09-23T00:54:14.246Z','2026-09-23T00:54:20.900Z',1,'Zernio Publisher completed a run.','claude-haiku-4.5',12627,3251,0.02310600000000000153);
INSERT INTO agent_runs VALUES('seed-run-postly-publisher-5','postly-publisher','2026-09-16T22:48:24.368Z','2026-09-16T22:48:29.262Z',1,'Zernio Publisher completed a run.','claude-haiku-4.5',11414,411,0.01077499999999999986);
INSERT INTO agent_runs VALUES('seed-run-postly-publisher-6','postly-publisher','2026-09-20T14:57:55.807Z','2026-09-20T14:58:00.458Z',0,'Zernio Publisher run failed and was retried.','claude-haiku-4.5',13769,2524,0.0211110000000000013);
INSERT INTO agent_runs VALUES('seed-run-postly-publisher-7','postly-publisher','2026-09-10T17:34:39.174Z','2026-09-10T17:34:41.206Z',1,'Zernio Publisher completed a run.','claude-haiku-4.5',12695,300,0.01135599999999999978);
INSERT INTO agent_runs VALUES('seed-run-postly-publisher-8','postly-publisher','2026-09-18T22:11:09.671Z','2026-09-18T22:11:11.648Z',1,'Zernio Publisher completed a run.','claude-haiku-4.5',1955,3406,0.01518800000000000011);
INSERT INTO agent_runs VALUES('seed-run-postly-publisher-9','postly-publisher','2026-09-20T23:28:03.191Z','2026-09-20T23:28:04.493Z',1,'Zernio Publisher completed a run.','claude-haiku-4.5',7846,994,0.01025299999999999997);
INSERT INTO agent_runs VALUES('seed-run-adsmith-creative-0','adsmith-creative','2026-09-17T14:42:25.987Z','2026-09-17T14:42:30.711Z',1,'Arcads Creative completed a run.','claude-haiku-4.5',7297,1412,0.01148599999999999969);
INSERT INTO agent_runs VALUES('seed-run-adsmith-creative-1','adsmith-creative','2026-09-16T08:41:54.436Z','2026-09-16T08:41:58.158Z',0,'Arcads Creative run failed and was retried.','claude-haiku-4.5',12522,2250,0.01901800000000000018);
INSERT INTO agent_runs VALUES('seed-run-adsmith-creative-2','adsmith-creative','2026-09-25T19:34:45.911Z','2026-09-25T19:34:53.167Z',1,'Arcads Creative completed a run.','claude-haiku-4.5',5036,2113,0.01248100000000000077);
INSERT INTO agent_runs VALUES('seed-run-adsmith-creative-3','adsmith-creative','2026-09-17T11:26:59.852Z','2026-09-17T11:27:01.242Z',1,'Arcads Creative completed a run.','claude-haiku-4.5',7817,984,0.01018999999999999941);
INSERT INTO agent_runs VALUES('seed-run-adsmith-creative-4','adsmith-creative','2026-09-19T11:15:15.949Z','2026-09-19T11:15:21.511Z',1,'Arcads Creative completed a run.','claude-haiku-4.5',5612,2056,0.01271399999999999961);
INSERT INTO agent_runs VALUES('seed-run-adsmith-creative-5','adsmith-creative','2026-09-28T16:47:46.673Z','2026-09-28T16:47:50.864Z',1,'Arcads Creative completed a run.','claude-haiku-4.5',12048,1611,0.01608199999999999908);
INSERT INTO agent_runs VALUES('seed-run-adsmith-creative-6','adsmith-creative','2026-09-20T11:05:32.915Z','2026-09-20T11:05:35.137Z',1,'Arcads Creative completed a run.','claude-haiku-4.5',6754,2999,0.01739900000000000127);
INSERT INTO agent_runs VALUES('seed-run-adsmith-creative-7','adsmith-creative','2026-09-12T08:33:26.936Z','2026-09-12T08:33:32.978Z',1,'Arcads Creative completed a run.','claude-haiku-4.5',3235,717,0.005455999999999999913);
INSERT INTO agent_runs VALUES('seed-run-adsmith-creative-8','adsmith-creative','2026-09-21T12:10:46.766Z','2026-09-21T12:10:52.273Z',1,'Arcads Creative completed a run.','claude-haiku-4.5',13930,1271,0.01622799999999999937);
INSERT INTO agent_runs VALUES('seed-run-adsmith-creative-9','adsmith-creative','2026-09-18T19:35:28.600Z','2026-09-18T19:35:30.623Z',1,'Arcads Creative completed a run.','claude-haiku-4.5',14161,682,0.01405700000000000005);
INSERT INTO agent_runs VALUES('seed-run-adsmith-creative-10','adsmith-creative','2026-09-15T12:43:58.558Z','2026-09-15T12:44:04.400Z',1,'Arcads Creative completed a run.','claude-haiku-4.5',14773,1146,0.01640199999999999992);
INSERT INTO agent_runs VALUES('seed-run-adsmith-creative-11','adsmith-creative','2026-09-16T15:56:03.260Z','2026-09-16T15:56:09.559Z',1,'Arcads Creative completed a run.','claude-haiku-4.5',10667,3476,0.02243799999999999962);
INSERT INTO agent_runs VALUES('seed-run-adsmith-creative-12','adsmith-creative','2026-09-22T13:54:45.901Z','2026-09-22T13:54:53.147Z',1,'Arcads Creative completed a run.','claude-haiku-4.5',11682,4177,0.02605400000000000076);
INSERT INTO agent_runs VALUES('seed-run-reelkit-editor-0','reelkit-editor','2026-09-16T11:14:50.501Z','2026-09-16T11:14:55.593Z',1,'Remotion Editor completed a run.','claude-haiku-4.5',13950,2481,0.02108399999999999857);
INSERT INTO agent_runs VALUES('seed-run-reelkit-editor-1','reelkit-editor','2026-09-21T04:53:16.565Z','2026-09-21T04:53:20.584Z',1,'Remotion Editor completed a run.','claude-haiku-4.5',13503,2921,0.02248599999999999905);
INSERT INTO agent_runs VALUES('seed-run-reelkit-editor-2','reelkit-editor','2026-09-17T03:26:22.248Z','2026-09-17T03:26:29.085Z',1,'Remotion Editor completed a run.','claude-haiku-4.5',5264,1780,0.0113310000000000008);
INSERT INTO agent_runs VALUES('seed-run-reelkit-editor-3','reelkit-editor','2026-09-11T23:57:04.654Z','2026-09-11T23:57:05.579Z',1,'Remotion Editor completed a run.','claude-haiku-4.5',6291,3977,0.02094100000000000127);
INSERT INTO agent_runs VALUES('seed-run-reelkit-editor-4','reelkit-editor','2026-09-29T02:35:39.860Z','2026-09-29T02:35:40.378Z',1,'Remotion Editor completed a run.','claude-haiku-4.5',8322,1315,0.01191799999999999978);
INSERT INTO agent_runs VALUES('seed-run-renderly-creative-0','renderly-creative','2026-09-27T08:41:30.307Z','2026-09-27T08:41:30.959Z',1,'Higgsfield Creative completed a run.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-renderly-creative-1','renderly-creative','2026-09-27T02:28:48.309Z','2026-09-27T02:28:49.175Z',1,'Higgsfield Creative completed a run.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-renderly-creative-2','renderly-creative','2026-09-18T13:34:37.164Z','2026-09-18T13:34:41.666Z',1,'Higgsfield Creative completed a run.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-renderly-creative-3','renderly-creative','2026-09-16T07:53:36.386Z','2026-09-16T07:53:39.929Z',1,'Higgsfield Creative completed a run.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-renderly-creative-4','renderly-creative','2026-09-19T01:36:30.540Z','2026-09-19T01:36:35.638Z',1,'Higgsfield Creative completed a run.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-renderly-creative-5','renderly-creative','2026-09-12T01:33:26.204Z','2026-09-12T01:33:31.160Z',1,'Higgsfield Creative completed a run.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-renderly-creative-6','renderly-creative','2026-09-22T17:05:05.769Z','2026-09-22T17:05:09.003Z',1,'Higgsfield Creative completed a run.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-renderly-creative-7','renderly-creative','2026-09-21T15:25:32.143Z','2026-09-21T15:25:32.819Z',1,'Higgsfield Creative completed a run.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-renderly-creative-8','renderly-creative','2026-09-18T19:16:42.132Z','2026-09-18T19:16:49.299Z',1,'Higgsfield Creative completed a run.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-renderly-creative-9','renderly-creative','2026-09-15T23:46:42.646Z','2026-09-15T23:46:47.874Z',1,'Higgsfield Creative completed a run.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-renderly-creative-10','renderly-creative','2026-09-21T03:16:07.505Z','2026-09-21T03:16:12.066Z',1,'Higgsfield Creative completed a run.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-dmflow-mcp-0','dmflow-mcp','2026-09-12T22:10:24.386Z','2026-09-12T22:10:27.403Z',1,'ManyChat MCP completed a run.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-dmflow-mcp-1','dmflow-mcp','2026-09-11T20:10:55.168Z','2026-09-11T20:10:59.599Z',1,'ManyChat MCP completed a run.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-dmflow-mcp-2','dmflow-mcp','2026-09-21T06:16:33.202Z','2026-09-21T06:16:39.420Z',1,'ManyChat MCP completed a run.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-dmflow-mcp-3','dmflow-mcp','2026-09-15T21:38:28.453Z','2026-09-15T21:38:29.824Z',1,'ManyChat MCP completed a run.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-dmflow-mcp-4','dmflow-mcp','2026-09-21T10:50:50.655Z','2026-09-21T10:50:57.835Z',1,'ManyChat MCP completed a run.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-dmflow-mcp-5','dmflow-mcp','2026-09-15T11:04:38.689Z','2026-09-15T11:04:42.991Z',1,'ManyChat MCP completed a run.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-dmflow-mcp-6','dmflow-mcp','2026-09-15T22:33:12.572Z','2026-09-15T22:33:17.709Z',1,'ManyChat MCP completed a run.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-sales-agent-0','sales-agent','2026-09-19T18:17:31.779Z','2026-09-19T18:17:34.332Z',1,'Sales Agent completed a run.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-sales-agent-1','sales-agent','2026-09-19T22:25:37.479Z','2026-09-19T22:25:44.224Z',0,'Sales Agent run failed and was retried.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-sales-agent-2','sales-agent','2026-09-11T08:02:21.944Z','2026-09-11T08:02:28.697Z',1,'Sales Agent completed a run.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-sales-agent-3','sales-agent','2026-09-23T09:28:54.682Z','2026-09-23T09:28:55.283Z',1,'Sales Agent completed a run.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-sales-agent-4','sales-agent','2026-09-29T11:06:50.304Z','2026-09-29T11:06:51.417Z',1,'Sales Agent completed a run.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-sales-agent-5','sales-agent','2026-09-15T09:12:30.067Z','2026-09-15T09:12:34.126Z',1,'Sales Agent completed a run.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-sales-agent-6','sales-agent','2026-09-26T17:10:43.796Z','2026-09-26T17:10:49.195Z',1,'Sales Agent completed a run.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-sales-agent-7','sales-agent','2026-09-15T07:57:00.459Z','2026-09-15T07:57:03.303Z',1,'Sales Agent completed a run.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-sales-agent-8','sales-agent','2026-09-27T07:42:47.134Z','2026-09-27T07:42:53.484Z',1,'Sales Agent completed a run.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-sales-agent-9','sales-agent','2026-09-12T00:39:30.178Z','2026-09-12T00:39:33.645Z',1,'Sales Agent completed a run.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-sales-agent-10','sales-agent','2026-09-19T17:29:13.442Z','2026-09-19T17:29:16.900Z',1,'Sales Agent completed a run.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-sales-agent-11','sales-agent','2026-09-28T22:00:02.466Z','2026-09-28T22:00:08.450Z',1,'Sales Agent completed a run.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-sales-agent-12','sales-agent','2026-09-13T09:46:57.867Z','2026-09-13T09:47:05.199Z',1,'Sales Agent completed a run.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-sales-agent-13','sales-agent','2026-09-27T09:48:52.583Z','2026-09-27T09:48:54.990Z',1,'Sales Agent completed a run.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-launchpad-cohort-sales-0','launchpad-cohort-sales','2026-09-13T09:42:25.394Z','2026-09-13T09:42:31.991Z',1,'Launchpad Cohort completed a run.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-launchpad-cohort-sales-1','launchpad-cohort-sales','2026-09-29T20:25:01.985Z','2026-09-29T20:25:05.376Z',1,'Launchpad Cohort completed a run.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-launchpad-cohort-sales-2','launchpad-cohort-sales','2026-09-17T02:54:48.752Z','2026-09-17T02:54:50.363Z',0,'Launchpad Cohort run failed and was retried.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-launchpad-cohort-sales-3','launchpad-cohort-sales','2026-09-23T19:25:52.272Z','2026-09-23T19:25:52.984Z',1,'Launchpad Cohort completed a run.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-launchpad-cohort-sales-4','launchpad-cohort-sales','2026-09-11T07:13:16.334Z','2026-09-11T07:13:22.192Z',1,'Launchpad Cohort completed a run.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-launchpad-cohort-sales-5','launchpad-cohort-sales','2026-09-20T01:53:21.003Z','2026-09-20T01:53:24.213Z',1,'Launchpad Cohort completed a run.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-launchpad-cohort-sales-6','launchpad-cohort-sales','2026-09-14T20:01:45.439Z','2026-09-14T20:01:46.089Z',1,'Launchpad Cohort completed a run.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-launchpad-cohort-sales-7','launchpad-cohort-sales','2026-09-17T00:01:45.372Z','2026-09-17T00:01:46.029Z',1,'Launchpad Cohort completed a run.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-launchpad-cohort-sales-8','launchpad-cohort-sales','2026-09-22T19:44:04.637Z','2026-09-22T19:44:09.451Z',1,'Launchpad Cohort completed a run.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-launchpad-cohort-sales-9','launchpad-cohort-sales','2026-09-26T18:26:50.766Z','2026-09-26T18:26:51.983Z',1,'Launchpad Cohort completed a run.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-launchpad-cohort-sales-10','launchpad-cohort-sales','2026-09-24T16:06:53.990Z','2026-09-24T16:06:56.868Z',1,'Launchpad Cohort completed a run.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-vantage-sales-0','vantage-sales','2026-09-12T03:12:03.453Z','2026-09-12T03:12:06.787Z',1,'Vantage completed a run.','claude-haiku-4.5',14743,3145,0.02437399999999999984);
INSERT INTO agent_runs VALUES('seed-run-vantage-sales-1','vantage-sales','2026-09-21T14:39:10.809Z','2026-09-21T14:39:13.974Z',1,'Vantage completed a run.','claude-haiku-4.5',11387,3933,0.0248419999999999995);
INSERT INTO agent_runs VALUES('seed-run-vantage-sales-2','vantage-sales','2026-09-19T10:11:10.850Z','2026-09-19T10:11:13.845Z',1,'Vantage completed a run.','claude-haiku-4.5',12943,1528,0.01646600000000000147);
INSERT INTO agent_runs VALUES('seed-run-vantage-sales-3','vantage-sales','2026-09-28T14:26:39.463Z','2026-09-28T14:26:40.682Z',1,'Vantage completed a run.','claude-haiku-4.5',9214,1602,0.01377899999999999959);
INSERT INTO agent_runs VALUES('seed-run-vantage-sales-4','vantage-sales','2026-09-24T12:40:01.909Z','2026-09-24T12:40:05.645Z',1,'Vantage completed a run.','claude-haiku-4.5',6866,4113,0.02194499999999999923);
INSERT INTO agent_runs VALUES('seed-run-vantage-sales-5','vantage-sales','2026-09-28T17:27:58.618Z','2026-09-28T17:28:05.026Z',1,'Vantage completed a run.','claude-haiku-4.5',4517,1953,0.01142600000000000039);
INSERT INTO agent_runs VALUES('seed-run-vantage-sales-6','vantage-sales','2026-09-14T14:16:56.333Z','2026-09-14T14:16:59.261Z',1,'Vantage completed a run.','claude-haiku-4.5',869,3010,0.0127349999999999998);
INSERT INTO agent_runs VALUES('seed-run-vantage-sales-7','vantage-sales','2026-09-25T07:22:42.984Z','2026-09-25T07:22:47.943Z',1,'Vantage completed a run.','claude-haiku-4.5',14532,1372,0.01711400000000000073);
INSERT INTO agent_runs VALUES('seed-run-vantage-sales-8','vantage-sales','2026-09-17T03:15:41.273Z','2026-09-17T03:15:42.150Z',1,'Vantage completed a run.','claude-haiku-4.5',11182,2425,0.01864599999999999939);
INSERT INTO agent_runs VALUES('seed-run-vantage-sales-9','vantage-sales','2026-09-18T07:55:51.515Z','2026-09-18T07:55:54.720Z',0,'Vantage run failed and was retried.','claude-haiku-4.5',10880,1690,0.01546400000000000031);
INSERT INTO agent_runs VALUES('seed-run-vantage-sales-10','vantage-sales','2026-09-19T18:41:52.379Z','2026-09-19T18:41:59.132Z',1,'Vantage completed a run.','claude-haiku-4.5',7675,297,0.007328000000000000312);
INSERT INTO agent_runs VALUES('seed-run-vantage-sales-11','vantage-sales','2026-09-29T16:36:44.970Z','2026-09-29T16:36:46.301Z',1,'Vantage completed a run.','claude-haiku-4.5',10464,3219,0.02124699999999999852);
INSERT INTO agent_runs VALUES('seed-run-vantage-sales-12','vantage-sales','2026-09-26T18:46:09.348Z','2026-09-26T18:46:15.806Z',1,'Vantage completed a run.','claude-haiku-4.5',7041,964,0.00948899999999999917);
INSERT INTO agent_runs VALUES('seed-run-paykit-sales-0','paykit-sales','2026-09-19T20:10:12.295Z','2026-09-19T20:10:17.516Z',1,'PayKit completed a run.','claude-haiku-4.5',7027,1821,0.0129060000000000008);
INSERT INTO agent_runs VALUES('seed-run-paykit-sales-1','paykit-sales','2026-09-20T08:42:36.289Z','2026-09-20T08:42:41.402Z',1,'PayKit completed a run.','claude-haiku-4.5',7337,513,0.007922000000000000222);
INSERT INTO agent_runs VALUES('seed-run-paykit-sales-2','paykit-sales','2026-09-17T19:21:10.957Z','2026-09-17T19:21:15.635Z',1,'PayKit completed a run.','claude-haiku-4.5',882,1319,0.005982000000000000337);
INSERT INTO agent_runs VALUES('seed-run-paykit-sales-3','paykit-sales','2026-09-19T20:18:43.767Z','2026-09-19T20:18:47.880Z',1,'PayKit completed a run.','claude-haiku-4.5',11439,777,0.01225900000000000079);
INSERT INTO agent_runs VALUES('seed-run-paykit-sales-4','paykit-sales','2026-09-28T20:58:43.262Z','2026-09-28T20:58:46.878Z',1,'PayKit completed a run.','claude-haiku-4.5',2897,1936,0.01006199999999999977);
INSERT INTO agent_runs VALUES('seed-run-paykit-sales-5','paykit-sales','2026-09-24T23:43:49.225Z','2026-09-24T23:43:55.497Z',1,'PayKit completed a run.','claude-haiku-4.5',5536,3681,0.01915299999999999989);
INSERT INTO agent_runs VALUES('seed-run-paykit-sales-6','paykit-sales','2026-09-20T19:16:35.086Z','2026-09-20T19:16:41.632Z',1,'PayKit completed a run.','claude-haiku-4.5',1245,309,0.002232000000000000042);
INSERT INTO agent_runs VALUES('seed-run-paykit-sales-7','paykit-sales','2026-09-24T16:33:51.469Z','2026-09-24T16:33:53.902Z',1,'PayKit completed a run.','claude-haiku-4.5',2169,3230,0.01465499999999999963);
INSERT INTO agent_runs VALUES('seed-run-paykit-sales-8','paykit-sales','2026-09-12T06:47:31.046Z','2026-09-12T06:47:36.353Z',1,'PayKit completed a run.','claude-haiku-4.5',4797,2277,0.01294599999999999918);
INSERT INTO agent_runs VALUES('seed-run-paykit-sales-9','paykit-sales','2026-09-18T21:57:32.957Z','2026-09-18T21:57:34.501Z',0,'PayKit run failed and was retried.','claude-haiku-4.5',4141,629,0.00582899999999999998);
INSERT INTO agent_runs VALUES('seed-run-paykit-sales-10','paykit-sales','2026-09-26T17:45:24.615Z','2026-09-26T17:45:30.121Z',1,'PayKit completed a run.','claude-haiku-4.5',9154,2519,0.01739900000000000127);
INSERT INTO agent_runs VALUES('seed-run-paykit-sales-11','paykit-sales','2026-09-22T22:41:09.781Z','2026-09-22T22:41:13.438Z',1,'PayKit completed a run.','claude-haiku-4.5',4201,1437,0.009109000000000000777);
INSERT INTO agent_runs VALUES('seed-run-paykit-sales-12','paykit-sales','2026-09-25T02:52:59.606Z','2026-09-25T02:53:02.558Z',0,'PayKit run failed and was retried.','claude-haiku-4.5',11954,3458,0.02339499999999999913);
INSERT INTO agent_runs VALUES('seed-run-paykit-sales-13','paykit-sales','2026-09-26T23:23:49.511Z','2026-09-26T23:23:52.803Z',1,'PayKit completed a run.','claude-haiku-4.5',11937,3935,0.02528999999999999999);
INSERT INTO agent_runs VALUES('seed-run-vantage-paykit-0','vantage-paykit','2026-09-24T15:39:05.001Z','2026-09-24T15:39:09.396Z',1,'Vantage PayKit completed a run.','claude-haiku-4.5',9088,621,0.00975400000000000051);
INSERT INTO agent_runs VALUES('seed-run-vantage-paykit-1','vantage-paykit','2026-09-17T11:27:21.202Z','2026-09-17T11:27:27.109Z',1,'Vantage PayKit completed a run.','claude-haiku-4.5',5990,3798,0.01998399999999999829);
INSERT INTO agent_runs VALUES('seed-run-vantage-paykit-2','vantage-paykit','2026-09-20T17:01:49.530Z','2026-09-20T17:01:51.662Z',1,'Vantage PayKit completed a run.','claude-haiku-4.5',1039,577,0.003138999999999999864);
INSERT INTO agent_runs VALUES('seed-run-vantage-paykit-3','vantage-paykit','2026-09-12T12:32:44.790Z','2026-09-12T12:32:45.872Z',1,'Vantage PayKit completed a run.','claude-haiku-4.5',12279,1676,0.01652700000000000002);
INSERT INTO agent_runs VALUES('seed-run-vantage-paykit-4','vantage-paykit','2026-09-24T04:48:13.610Z','2026-09-24T04:48:17.934Z',1,'Vantage PayKit completed a run.','claude-haiku-4.5',7041,2216,0.01449699999999999947);
INSERT INTO agent_runs VALUES('seed-run-vantage-paykit-5','vantage-paykit','2026-09-13T11:48:43.719Z','2026-09-13T11:48:44.285Z',1,'Vantage PayKit completed a run.','claude-haiku-4.5',11655,1293,0.0144960000000000002);
INSERT INTO agent_runs VALUES('seed-run-vantage-paykit-6','vantage-paykit','2026-09-29T09:15:39.948Z','2026-09-29T09:15:43.444Z',1,'Vantage PayKit completed a run.','claude-haiku-4.5',1556,3748,0.01623700000000000144);
INSERT INTO agent_runs VALUES('seed-run-vantage-paykit-7','vantage-paykit','2026-09-20T13:34:25.854Z','2026-09-20T13:34:31.502Z',1,'Vantage PayKit completed a run.','claude-haiku-4.5',3427,616,0.005205999999999999691);
INSERT INTO agent_runs VALUES('seed-run-vantage-paykit-8','vantage-paykit','2026-09-22T13:48:22.066Z','2026-09-22T13:48:28.154Z',1,'Vantage PayKit completed a run.','claude-haiku-4.5',3301,3675,0.01734099999999999878);
INSERT INTO agent_runs VALUES('seed-run-stripe-sales-0','stripe-sales','2026-09-12T02:30:45.049Z','2026-09-12T02:30:50.475Z',1,'Stripe completed a run.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-stripe-sales-1','stripe-sales','2026-09-18T05:33:30.560Z','2026-09-18T05:33:33.784Z',1,'Stripe completed a run.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-stripe-sales-2','stripe-sales','2026-09-14T18:46:05.576Z','2026-09-14T18:46:07.451Z',1,'Stripe completed a run.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-stripe-sales-3','stripe-sales','2026-09-25T23:21:08.644Z','2026-09-25T23:21:09.416Z',1,'Stripe completed a run.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-stripe-sales-4','stripe-sales','2026-09-10T20:47:02.230Z','2026-09-10T20:47:08.753Z',1,'Stripe completed a run.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-stripe-sales-5','stripe-sales','2026-09-22T22:27:06.393Z','2026-09-22T22:27:09.461Z',1,'Stripe completed a run.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-stripe-sales-6','stripe-sales','2026-09-17T23:15:52.193Z','2026-09-17T23:15:57.133Z',1,'Stripe completed a run.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-stripe-sales-7','stripe-sales','2026-09-11T13:09:36.697Z','2026-09-11T13:09:37.564Z',1,'Stripe completed a run.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-stripe-sales-8','stripe-sales','2026-09-27T22:08:37.983Z','2026-09-27T22:08:41.493Z',1,'Stripe completed a run.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-stripe-sales-9','stripe-sales','2026-09-22T04:58:59.247Z','2026-09-22T04:59:00.223Z',1,'Stripe completed a run.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-stripe-sales-10','stripe-sales','2026-09-11T08:08:22.123Z','2026-09-11T08:08:22.610Z',1,'Stripe completed a run.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-stripe-sales-11','stripe-sales','2026-09-23T20:55:40.675Z','2026-09-23T20:55:42.628Z',1,'Stripe completed a run.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-stripe-sales-12','stripe-sales','2026-09-22T01:33:16.467Z','2026-09-22T01:33:22.128Z',1,'Stripe completed a run.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-processor-confirmation-0','processor-confirmation','2026-09-23T16:40:34.735Z','2026-09-23T16:40:37.746Z',1,'Processor Confirm completed a run.','claude-haiku-4.5',10052,820,0.01132200000000000046);
INSERT INTO agent_runs VALUES('seed-run-processor-confirmation-1','processor-confirmation','2026-09-23T00:08:27.272Z','2026-09-23T00:08:31.776Z',0,'Processor Confirm run failed and was retried.','claude-haiku-4.5',3401,1055,0.006941000000000000121);
INSERT INTO agent_runs VALUES('seed-run-processor-confirmation-2','processor-confirmation','2026-09-26T22:16:28.191Z','2026-09-26T22:16:29.051Z',1,'Processor Confirm completed a run.','claude-haiku-4.5',12165,3304,0.02294799999999999965);
INSERT INTO agent_runs VALUES('seed-run-processor-confirmation-3','processor-confirmation','2026-09-29T17:47:37.264Z','2026-09-29T17:47:41.946Z',1,'Processor Confirm completed a run.','claude-haiku-4.5',6768,3614,0.01986999999999999878);
INSERT INTO agent_runs VALUES('seed-run-processor-confirmation-4','processor-confirmation','2026-09-27T22:09:32.554Z','2026-09-27T22:09:36.327Z',1,'Processor Confirm completed a run.','claude-haiku-4.5',12616,625,0.01259300000000000002);
INSERT INTO agent_runs VALUES('seed-run-processor-confirmation-5','processor-confirmation','2026-09-28T01:33:16.397Z','2026-09-28T01:33:21.193Z',1,'Processor Confirm completed a run.','claude-haiku-4.5',3405,3114,0.01518000000000000078);
INSERT INTO agent_runs VALUES('seed-run-processor-confirmation-6','processor-confirmation','2026-09-15T14:11:48.120Z','2026-09-15T14:11:52.771Z',1,'Processor Confirm completed a run.','claude-haiku-4.5',2161,1727,0.00863700000000000058);
INSERT INTO agent_runs VALUES('seed-run-processor-confirmation-7','processor-confirmation','2026-09-19T10:01:14.318Z','2026-09-19T10:01:19.732Z',1,'Processor Confirm completed a run.','claude-haiku-4.5',12022,982,0.01354600000000000074);
INSERT INTO agent_runs VALUES('seed-run-processor-confirmation-8','processor-confirmation','2026-09-15T12:27:23.096Z','2026-09-15T12:27:24.342Z',1,'Processor Confirm completed a run.','claude-haiku-4.5',1989,3425,0.01529100000000000077);
INSERT INTO agent_runs VALUES('seed-run-processor-confirmation-9','processor-confirmation','2026-09-24T22:52:43.962Z','2026-09-24T22:52:48.572Z',1,'Processor Confirm completed a run.','claude-haiku-4.5',7805,2280,0.01536399999999999919);
INSERT INTO agent_runs VALUES('seed-run-processor-confirmation-10','processor-confirmation','2026-09-28T22:32:13.432Z','2026-09-28T22:32:20.724Z',1,'Processor Confirm completed a run.','claude-haiku-4.5',11327,4128,0.02557399999999999952);
INSERT INTO agent_runs VALUES('seed-run-processor-confirmation-11','processor-confirmation','2026-09-27T04:08:51.910Z','2026-09-27T04:08:54.331Z',1,'Processor Confirm completed a run.','claude-haiku-4.5',2566,3760,0.01709300000000000055);
INSERT INTO agent_runs VALUES('seed-run-flexpay-financing-0','flexpay-financing','2026-09-19T01:07:41.114Z','2026-09-19T01:07:44.938Z',0,'FlexPay Financing run failed and was retried.','claude-haiku-4.5',11745,2539,0.01955199999999999994);
INSERT INTO agent_runs VALUES('seed-run-flexpay-financing-1','flexpay-financing','2026-09-19T13:09:25.240Z','2026-09-19T13:09:27.600Z',1,'FlexPay Financing completed a run.','claude-haiku-4.5',2763,1223,0.007101999999999999807);
INSERT INTO agent_runs VALUES('seed-run-flexpay-financing-2','flexpay-financing','2026-09-20T00:09:38.977Z','2026-09-20T00:09:46.032Z',1,'FlexPay Financing completed a run.','claude-haiku-4.5',13990,509,0.01322800000000000017);
INSERT INTO agent_runs VALUES('seed-run-flexpay-financing-3','flexpay-financing','2026-09-25T06:45:42.211Z','2026-09-25T06:45:44.334Z',1,'FlexPay Financing completed a run.','claude-haiku-4.5',8416,667,0.00940099999999999964);
INSERT INTO agent_runs VALUES('seed-run-flexpay-financing-4','flexpay-financing','2026-09-28T15:04:24.033Z','2026-09-28T15:04:29.953Z',1,'FlexPay Financing completed a run.','claude-haiku-4.5',12742,2530,0.02031399999999999873);
INSERT INTO agent_runs VALUES('seed-run-flexpay-financing-5','flexpay-financing','2026-09-13T18:39:38.055Z','2026-09-13T18:39:41.913Z',1,'FlexPay Financing completed a run.','claude-haiku-4.5',14434,2056,0.01977100000000000037);
INSERT INTO agent_runs VALUES('seed-run-sales-calls-data-0','sales-calls-data','2026-09-11T19:10:07.885Z','2026-09-11T19:10:08.377Z',1,'Sales Calls Data completed a run.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-sales-calls-data-1','sales-calls-data','2026-09-14T14:17:59.574Z','2026-09-14T14:18:03.937Z',1,'Sales Calls Data completed a run.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-sales-calls-data-2','sales-calls-data','2026-09-22T06:59:47.541Z','2026-09-22T06:59:48.127Z',0,'Sales Calls Data run failed and was retried.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-sales-calls-data-3','sales-calls-data','2026-09-22T16:50:24.267Z','2026-09-22T16:50:30.106Z',1,'Sales Calls Data completed a run.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-sales-calls-data-4','sales-calls-data','2026-09-29T10:27:39.662Z','2026-09-29T10:27:40.292Z',1,'Sales Calls Data completed a run.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-sales-calls-data-5','sales-calls-data','2026-09-12T16:52:53.777Z','2026-09-12T16:52:57.646Z',1,'Sales Calls Data completed a run.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-sales-calls-data-6','sales-calls-data','2026-09-25T00:11:12.123Z','2026-09-25T00:11:17.775Z',1,'Sales Calls Data completed a run.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-sales-calls-data-7','sales-calls-data','2026-09-22T06:27:52.035Z','2026-09-22T06:27:56.491Z',1,'Sales Calls Data completed a run.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-sales-calls-data-8','sales-calls-data','2026-09-29T10:03:58.810Z','2026-09-29T10:04:01.339Z',1,'Sales Calls Data completed a run.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-sales-calls-data-9','sales-calls-data','2026-09-10T15:05:57.816Z','2026-09-10T15:05:59.483Z',1,'Sales Calls Data completed a run.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-sales-calls-data-10','sales-calls-data','2026-09-12T14:14:11.532Z','2026-09-12T14:14:17.180Z',1,'Sales Calls Data completed a run.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-sales-calls-data-11','sales-calls-data','2026-09-13T06:04:27.089Z','2026-09-13T06:04:28.624Z',1,'Sales Calls Data completed a run.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-sales-calls-data-12','sales-calls-data','2026-09-19T21:45:29.764Z','2026-09-19T21:45:31.163Z',1,'Sales Calls Data completed a run.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-data-agent-0','data-agent','2026-09-21T08:42:38.063Z','2026-09-21T08:42:40.709Z',1,'Data Agent completed a run.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-data-agent-1','data-agent','2026-09-13T22:06:08.623Z','2026-09-13T22:06:14.104Z',0,'Data Agent run failed and was retried.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-data-agent-2','data-agent','2026-09-16T00:07:23.398Z','2026-09-16T00:07:27.921Z',1,'Data Agent completed a run.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-data-agent-3','data-agent','2026-09-28T08:15:35.584Z','2026-09-28T08:15:40.519Z',1,'Data Agent completed a run.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-data-agent-4','data-agent','2026-09-25T06:51:07.742Z','2026-09-25T06:51:13.830Z',1,'Data Agent completed a run.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-data-agent-5','data-agent','2026-09-11T18:45:00.401Z','2026-09-11T18:45:07.009Z',1,'Data Agent completed a run.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-data-agent-6','data-agent','2026-09-15T05:27:04.159Z','2026-09-15T05:27:04.812Z',0,'Data Agent run failed and was retried.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-data-agent-7','data-agent','2026-09-27T16:10:17.756Z','2026-09-27T16:10:19.665Z',0,'Data Agent run failed and was retried.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-data-agent-8','data-agent','2026-09-12T08:28:12.727Z','2026-09-12T08:28:16.755Z',1,'Data Agent completed a run.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-data-agent-9','data-agent','2026-09-11T16:59:21.878Z','2026-09-11T16:59:26.984Z',1,'Data Agent completed a run.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-data-agent-10','data-agent','2026-09-15T09:33:40.308Z','2026-09-15T09:33:41.760Z',1,'Data Agent completed a run.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-markdown-auditor-0','markdown-auditor','2026-09-24T06:42:24.919Z','2026-09-24T06:42:28.582Z',1,'Markdown Auditor completed a run.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-markdown-auditor-1','markdown-auditor','2026-09-25T02:52:52.637Z','2026-09-25T02:52:56.274Z',1,'Markdown Auditor completed a run.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-markdown-auditor-2','markdown-auditor','2026-09-18T04:59:02.976Z','2026-09-18T04:59:06.746Z',1,'Markdown Auditor completed a run.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-markdown-auditor-3','markdown-auditor','2026-09-16T17:42:03.868Z','2026-09-16T17:42:08.314Z',1,'Markdown Auditor completed a run.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-markdown-auditor-4','markdown-auditor','2026-09-23T00:48:45.378Z','2026-09-23T00:48:48.059Z',1,'Markdown Auditor completed a run.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-markdown-auditor-5','markdown-auditor','2026-09-27T17:52:48.930Z','2026-09-27T17:52:51.103Z',1,'Markdown Auditor completed a run.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-markdown-auditor-6','markdown-auditor','2026-09-28T10:12:05.639Z','2026-09-28T10:12:11.913Z',1,'Markdown Auditor completed a run.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-markdown-auditor-7','markdown-auditor','2026-09-15T07:49:17.968Z','2026-09-15T07:49:20.559Z',0,'Markdown Auditor run failed and was retried.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-markdown-auditor-8','markdown-auditor','2026-09-29T05:22:52.882Z','2026-09-29T05:22:53.911Z',1,'Markdown Auditor completed a run.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-vector-auditor-0','vector-auditor','2026-09-13T06:35:03.806Z','2026-09-13T06:35:08.486Z',1,'Vector Auditor completed a run.','claude-haiku-4.5',5974,2347,0.01416700000000000077);
INSERT INTO agent_runs VALUES('seed-run-vector-auditor-1','vector-auditor','2026-09-21T07:42:03.249Z','2026-09-21T07:42:07.912Z',1,'Vector Auditor completed a run.','claude-haiku-4.5',8521,369,0.008293000000000000024);
INSERT INTO agent_runs VALUES('seed-run-vector-auditor-2','vector-auditor','2026-09-18T15:08:08.427Z','2026-09-18T15:08:11.104Z',1,'Vector Auditor completed a run.','claude-haiku-4.5',10545,823,0.01172800000000000057);
INSERT INTO agent_runs VALUES('seed-run-vector-auditor-3','vector-auditor','2026-09-28T08:04:11.239Z','2026-09-28T08:04:12.181Z',1,'Vector Auditor completed a run.','claude-haiku-4.5',10916,2974,0.02062900000000000151);
INSERT INTO agent_runs VALUES('seed-run-vector-auditor-4','vector-auditor','2026-09-26T05:29:28.847Z','2026-09-26T05:29:29.998Z',1,'Vector Auditor completed a run.','claude-haiku-4.5',12845,3173,0.02296799999999999884);
INSERT INTO agent_runs VALUES('seed-run-vector-auditor-5','vector-auditor','2026-09-23T11:11:28.401Z','2026-09-23T11:11:30.320Z',1,'Vector Auditor completed a run.','claude-haiku-4.5',12354,1253,0.01489500000000000025);
INSERT INTO agent_runs VALUES('seed-run-vector-auditor-6','vector-auditor','2026-09-14T15:11:35.260Z','2026-09-14T15:11:38.383Z',0,'Vector Auditor run failed and was retried.','claude-haiku-4.5',10591,1202,0.01328099999999999941);
INSERT INTO agent_runs VALUES('seed-run-vector-auditor-7','vector-auditor','2026-09-15T04:20:55.769Z','2026-09-15T04:20:56.348Z',1,'Vector Auditor completed a run.','claude-haiku-4.5',3948,2148,0.01175000000000000002);
INSERT INTO agent_runs VALUES('seed-run-vector-auditor-8','vector-auditor','2026-09-18T09:33:29.994Z','2026-09-18T09:33:36.969Z',1,'Vector Auditor completed a run.','claude-haiku-4.5',13453,2661,0.02140600000000000142);
INSERT INTO agent_runs VALUES('seed-run-payments-pulse-0','payments-pulse','2026-09-26T02:08:29.070Z','2026-09-26T02:08:35.471Z',1,'Payments Pulse completed a run.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-payments-pulse-1','payments-pulse','2026-09-14T16:18:52.615Z','2026-09-14T16:18:55.876Z',1,'Payments Pulse completed a run.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-payments-pulse-2','payments-pulse','2026-09-16T14:47:49.290Z','2026-09-16T14:47:52.819Z',1,'Payments Pulse completed a run.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-payments-pulse-3','payments-pulse','2026-09-25T00:36:05.873Z','2026-09-25T00:36:07.839Z',0,'Payments Pulse run failed and was retried.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-payments-pulse-4','payments-pulse','2026-09-22T02:01:31.776Z','2026-09-22T02:01:37.977Z',1,'Payments Pulse completed a run.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-payments-pulse-5','payments-pulse','2026-09-10T11:32:00.579Z','2026-09-10T11:32:01.994Z',1,'Payments Pulse completed a run.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-payments-pulse-6','payments-pulse','2026-09-28T17:55:29.887Z','2026-09-28T17:55:30.413Z',1,'Payments Pulse completed a run.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-payments-pulse-7','payments-pulse','2026-09-12T07:20:29.379Z','2026-09-12T07:20:36.564Z',1,'Payments Pulse completed a run.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-payments-pulse-8','payments-pulse','2026-09-16T14:25:11.364Z','2026-09-16T14:25:17.721Z',1,'Payments Pulse completed a run.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-payments-pulse-9','payments-pulse','2026-09-27T02:42:08.695Z','2026-09-27T02:42:12.512Z',1,'Payments Pulse completed a run.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-payments-pulse-10','payments-pulse','2026-09-22T19:44:53.213Z','2026-09-22T19:44:59.005Z',1,'Payments Pulse completed a run.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-payments-pulse-11','payments-pulse','2026-09-12T20:01:09.825Z','2026-09-12T20:01:14.382Z',1,'Payments Pulse completed a run.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-payments-pulse-12','payments-pulse','2026-09-24T16:31:28.469Z','2026-09-24T16:31:35.187Z',1,'Payments Pulse completed a run.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-crm-pulse-0','crm-pulse','2026-09-26T15:33:10.997Z','2026-09-26T15:33:17.582Z',1,'Lead Pulse completed a run.','claude-haiku-4.5',3639,3796,0.01809499999999999998);
INSERT INTO agent_runs VALUES('seed-run-crm-pulse-1','crm-pulse','2026-09-11T04:58:50.095Z','2026-09-11T04:58:57.492Z',1,'Lead Pulse completed a run.','claude-haiku-4.5',2645,4097,0.01850399999999999962);
INSERT INTO agent_runs VALUES('seed-run-crm-pulse-2','crm-pulse','2026-09-11T12:47:24.669Z','2026-09-11T12:47:30.895Z',1,'Lead Pulse completed a run.','claude-haiku-4.5',12073,445,0.01143800000000000025);
INSERT INTO agent_runs VALUES('seed-run-crm-pulse-3','crm-pulse','2026-09-17T00:06:34.452Z','2026-09-17T00:06:38.766Z',1,'Lead Pulse completed a run.','claude-haiku-4.5',5766,967,0.008481000000000000691);
INSERT INTO agent_runs VALUES('seed-run-crm-pulse-4','crm-pulse','2026-09-10T12:18:29.804Z','2026-09-10T12:18:34.967Z',1,'Lead Pulse completed a run.','claude-haiku-4.5',6643,2975,0.01721400000000000013);
INSERT INTO agent_runs VALUES('seed-run-crm-pulse-5','crm-pulse','2026-09-15T16:47:44.983Z','2026-09-15T16:47:51.434Z',1,'Lead Pulse completed a run.','claude-haiku-4.5',11927,2776,0.02064600000000000115);
INSERT INTO agent_runs VALUES('seed-run-crm-pulse-6','crm-pulse','2026-09-27T16:39:14.259Z','2026-09-27T16:39:15.197Z',1,'Lead Pulse completed a run.','claude-haiku-4.5',7962,763,0.00942199999999999982);
INSERT INTO agent_runs VALUES('seed-run-crm-pulse-7','crm-pulse','2026-09-13T12:55:26.718Z','2026-09-13T12:55:33.643Z',1,'Lead Pulse completed a run.','claude-haiku-4.5',11660,912,0.01297599999999999969);
INSERT INTO agent_runs VALUES('seed-run-crm-pulse-8','crm-pulse','2026-09-16T20:08:55.972Z','2026-09-16T20:09:00.821Z',1,'Lead Pulse completed a run.','claude-haiku-4.5',14016,3888,0.02676500000000000059);
INSERT INTO agent_runs VALUES('seed-run-stack-monitor-0','stack-monitor','2026-09-12T07:37:07.450Z','2026-09-12T07:37:10.764Z',1,'Stack Monitor completed a run.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-stack-monitor-1','stack-monitor','2026-09-13T09:03:55.487Z','2026-09-13T09:03:55.994Z',1,'Stack Monitor completed a run.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-stack-monitor-2','stack-monitor','2026-09-18T09:32:48.203Z','2026-09-18T09:32:48.943Z',1,'Stack Monitor completed a run.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-stack-monitor-3','stack-monitor','2026-09-20T14:20:53.264Z','2026-09-20T14:20:54.163Z',1,'Stack Monitor completed a run.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-stack-monitor-4','stack-monitor','2026-09-14T05:29:55.527Z','2026-09-14T05:30:02.770Z',1,'Stack Monitor completed a run.',NULL,NULL,NULL,NULL);
INSERT INTO agent_runs VALUES('seed-run-client-roster-0','client-roster','2026-09-25T15:45:10.578Z','2026-09-25T15:45:14.682Z',1,'Client Roster completed a run.','claude-sonnet-5',7260,4135,0.08380500000000000448);
INSERT INTO agent_runs VALUES('seed-run-client-roster-1','client-roster','2026-09-28T09:29:07.280Z','2026-09-28T09:29:08.485Z',1,'Client Roster completed a run.','claude-sonnet-5',3786,1878,0.03952800000000000063);
INSERT INTO agent_runs VALUES('seed-run-client-roster-2','client-roster','2026-09-19T23:59:36.744Z','2026-09-19T23:59:39.509Z',1,'Client Roster completed a run.','claude-sonnet-5',4791,4159,0.07675800000000000678);
INSERT INTO agent_runs VALUES('seed-run-client-roster-3','client-roster','2026-09-23T08:11:31.876Z','2026-09-23T08:11:37.287Z',1,'Client Roster completed a run.','claude-sonnet-5',11268,3123,0.08064899999999999847);
INSERT INTO agent_runs VALUES('seed-run-client-roster-4','client-roster','2026-09-17T23:22:51.609Z','2026-09-17T23:22:54.223Z',0,'Client Roster run failed and was retried.','claude-sonnet-5',3115,2005,0.0394199999999999967);
INSERT INTO agent_runs VALUES('seed-run-client-roster-5','client-roster','2026-09-24T06:08:21.503Z','2026-09-24T06:08:27.126Z',1,'Client Roster completed a run.','claude-sonnet-5',13503,1692,0.06588900000000000312);
INSERT INTO agent_runs VALUES('seed-run-client-roster-6','client-roster','2026-09-10T07:11:07.025Z','2026-09-10T07:11:10.791Z',1,'Client Roster completed a run.','claude-sonnet-5',4119,1723,0.03820199999999999985);
INSERT INTO agent_runs VALUES('seed-run-client-roster-7','client-roster','2026-09-23T22:40:02.815Z','2026-09-23T22:40:03.547Z',1,'Client Roster completed a run.','claude-sonnet-5',2504,3557,0.0608669999999999975);
INSERT INTO agent_runs VALUES('seed-run-client-roster-8','client-roster','2026-09-20T01:35:59.254Z','2026-09-20T01:36:00.317Z',1,'Client Roster completed a run.','claude-sonnet-5',5296,2309,0.05052299999999999847);
INSERT INTO agent_runs VALUES('seed-run-client-roster-9','client-roster','2026-09-25T02:41:03.721Z','2026-09-25T02:41:04.838Z',1,'Client Roster completed a run.','claude-sonnet-5',11462,3998,0.0943559999999999955);
INSERT INTO agent_runs VALUES('seed-run-client-roster-10','client-roster','2026-09-16T08:26:47.281Z','2026-09-16T08:26:52.078Z',1,'Client Roster completed a run.','claude-sonnet-5',9982,1647,0.0546509999999999982);
INSERT INTO agent_runs VALUES('seed-run-client-roster-11','client-roster','2026-09-14T13:54:34.689Z','2026-09-14T13:54:35.197Z',1,'Client Roster completed a run.','claude-sonnet-5',7590,2484,0.06003000000000000002);
INSERT INTO agent_runs VALUES('seed-run-client-roster-12','client-roster','2026-09-10T16:20:13.154Z','2026-09-10T16:20:17.690Z',1,'Client Roster completed a run.','claude-sonnet-5',10026,3811,0.0872430000000000011);
INSERT INTO agent_runs VALUES('seed-run-client-onboarding-0','client-onboarding','2026-09-14T15:59:08.519Z','2026-09-14T15:59:15.231Z',0,'Onboarding Agent run failed and was retried.','claude-haiku-4.5',13192,3310,0.02379399999999999918);
INSERT INTO agent_runs VALUES('seed-run-client-onboarding-1','client-onboarding','2026-09-24T09:11:24.852Z','2026-09-24T09:11:29.904Z',1,'Onboarding Agent completed a run.','claude-haiku-4.5',7127,3799,0.02089799999999999991);
INSERT INTO agent_runs VALUES('seed-run-client-onboarding-2','client-onboarding','2026-09-29T08:46:19.058Z','2026-09-29T08:46:20.513Z',1,'Onboarding Agent completed a run.','claude-haiku-4.5',3502,1713,0.00965399999999999939);
INSERT INTO agent_runs VALUES('seed-run-client-onboarding-3','client-onboarding','2026-09-16T21:27:31.289Z','2026-09-16T21:27:34.251Z',1,'Onboarding Agent completed a run.','claude-haiku-4.5',10398,2091,0.01668199999999999892);
INSERT INTO agent_runs VALUES('seed-run-client-onboarding-4','client-onboarding','2026-09-15T07:50:31.258Z','2026-09-15T07:50:32.140Z',1,'Onboarding Agent completed a run.','claude-haiku-4.5',8896,908,0.01074899999999999988);
INSERT INTO agent_runs VALUES('seed-run-client-onboarding-5','client-onboarding','2026-09-28T01:52:47.978Z','2026-09-28T01:52:50.808Z',1,'Onboarding Agent completed a run.','claude-haiku-4.5',14145,1856,0.01873999999999999972);
INSERT INTO agent_runs VALUES('seed-run-client-onboarding-6','client-onboarding','2026-09-25T16:30:27.135Z','2026-09-25T16:30:32.907Z',1,'Onboarding Agent completed a run.','claude-haiku-4.5',13848,330,0.0123979999999999993);
INSERT INTO agent_runs VALUES('seed-run-client-onboarding-7','client-onboarding','2026-09-13T16:35:22.588Z','2026-09-13T16:35:24.626Z',1,'Onboarding Agent completed a run.','claude-haiku-4.5',4224,3939,0.01913499999999999924);
INSERT INTO agent_runs VALUES('seed-run-client-onboarding-8','client-onboarding','2026-09-15T09:45:18.453Z','2026-09-15T09:45:21.713Z',1,'Onboarding Agent completed a run.','claude-haiku-4.5',8687,1445,0.01273);
INSERT INTO agent_runs VALUES('seed-run-client-success-0','client-success','2026-09-25T22:17:17.224Z','2026-09-25T22:17:22.637Z',1,'Client Success completed a run.','claude-haiku-4.5',3539,2827,0.01413900000000000052);
INSERT INTO agent_runs VALUES('seed-run-client-success-1','client-success','2026-09-20T20:42:15.963Z','2026-09-20T20:42:17.235Z',1,'Client Success completed a run.','claude-haiku-4.5',2352,2584,0.0122179999999999997);
INSERT INTO agent_runs VALUES('seed-run-client-success-2','client-success','2026-09-19T10:13:05.805Z','2026-09-19T10:13:07.796Z',1,'Client Success completed a run.','claude-haiku-4.5',10942,3251,0.02175799999999999957);
INSERT INTO agent_runs VALUES('seed-run-client-success-3','client-success','2026-09-14T01:57:20.609Z','2026-09-14T01:57:23.193Z',0,'Client Success run failed and was retried.','claude-haiku-4.5',1634,3912,0.01695500000000000133);
INSERT INTO agent_runs VALUES('seed-run-client-success-4','client-success','2026-09-10T10:31:57.606Z','2026-09-10T10:32:01.761Z',1,'Client Success completed a run.','claude-haiku-4.5',8659,1408,0.01255900000000000071);
CREATE TABLE agent_messages (
  id TEXT PRIMARY KEY,
  agent_id TEXT NOT NULL,
  role TEXT NOT NULL,
  content TEXT NOT NULL DEFAULT '',
  tool_calls TEXT NOT NULL DEFAULT '[]',
  created_at TEXT NOT NULL
);
CREATE TABLE trading_snapshots (
  account_id TEXT NOT NULL DEFAULT 'individual',
  account_label TEXT NOT NULL DEFAULT 'Individual',
  captured_at TEXT NOT NULL,
  account_value_usd REAL NOT NULL,
  buying_power_usd REAL NOT NULL,
  cash_usd REAL NOT NULL,
  day_pnl_usd REAL NOT NULL,
  total_pnl_usd REAL NOT NULL,
  source TEXT NOT NULL,
  PRIMARY KEY (account_id, captured_at)
);
INSERT INTO trading_snapshots VALUES('agentic','Agentic','2026-08-13T11:00:00.000Z',1000.0,1000.0,1000.0,0.0,0.0,'seed');
INSERT INTO trading_snapshots VALUES('agentic','Agentic','2026-08-13T12:00:00.000Z',1004.700000000000045,604.7000000000000454,604.7000000000000454,4.700000000000000177,4.700000000000000177,'seed');
INSERT INTO trading_snapshots VALUES('agentic','Agentic','2026-08-13T13:00:00.000Z',1021.899999999999978,418.5,418.5,21.89999999999999857,21.89999999999999857,'seed');
INSERT INTO trading_snapshots VALUES('agentic','Agentic','2026-08-13T14:00:00.000Z',1016.399999999999978,418.5,418.5,16.39999999999999857,16.39999999999999857,'seed');
INSERT INTO trading_snapshots VALUES('individual','Individual','2026-08-13T15:00:00.000Z',10248.62999999999919,2960.119999999999891,2960.119999999999891,132.4000000000000056,248.6299999999999955,'seed');
INSERT INTO trading_snapshots VALUES('agentic','Agentic','2026-08-13T15:00:00.000Z',1043.200000000000045,418.5,418.5,11.80000000000000071,43.20000000000000285,'seed');
CREATE TABLE trading_positions (
  account_id TEXT NOT NULL DEFAULT 'individual',
  captured_at TEXT NOT NULL,
  symbol TEXT NOT NULL,
  quantity REAL NOT NULL,
  avg_cost_usd REAL NOT NULL,
  market_value_usd REAL NOT NULL,
  unrealized_pnl_usd REAL NOT NULL,
  PRIMARY KEY (account_id, captured_at, symbol)
);
INSERT INTO trading_positions VALUES('individual','2026-08-13T15:00:00.000Z','NVDA',4.0,902.1000000000000227,3812.59999999999991,204.1999999999999887);
INSERT INTO trading_positions VALUES('individual','2026-08-13T15:00:00.000Z','AAPL',8.0,214.3499999999999944,1760.40000000000009,45.60000000000000142);
INSERT INTO trading_positions VALUES('individual','2026-08-13T15:00:00.000Z','MSFT',3.0,428.0,1301.700000000000045,17.69999999999999929);
INSERT INTO trading_positions VALUES('individual','2026-08-13T15:00:00.000Z','VOO',5.0,82.90000000000000569,413.7900000000000204,-1.709999999999999965);
INSERT INTO trading_positions VALUES('agentic','2026-08-13T15:00:00.000Z','SPY',1.0,601.3999999999999773,624.7000000000000454,23.30000000000000071);
CREATE TABLE proposals (
  id TEXT PRIMARY KEY,
  client TEXT NOT NULL,
  brand TEXT NOT NULL,
  url TEXT NOT NULL,
  status TEXT NOT NULL,
  amount_usd REAL,
  notes TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL,
  origin TEXT NOT NULL DEFAULT 'seed',
  access_code TEXT NOT NULL DEFAULT ''
);
INSERT INTO proposals VALUES('vantage-nora','Nora Quinn','vantage','https://vantage-proposal-nora.example','sent',7500.0,'Northgate Storage · Founder OS build','2026-08-18T00:00:00.000Z','seed','fixture-code-1');
INSERT INTO proposals VALUES('vantage-morgan','Morgan Hale','vantage','https://vantage-proposal-morgan.example','sent',NULL,'','2026-08-12T00:00:00.000Z','seed','fixture-code-2');
INSERT INTO proposals VALUES('vantage-devon','Devon Price','vantage','https://vantage-proposal-devon.example','sent',NULL,'','2026-08-07T00:00:00.000Z','seed','fixture-code-3');
INSERT INTO proposals VALUES('vantage-reese','Reese Calder','vantage','https://vantage-proposal-reese.example','sent',NULL,'','2026-08-04T00:00:00.000Z','seed','fixture-code-4');
CREATE TABLE deliverable_decisions (
  id TEXT PRIMARY KEY,
  decision TEXT NOT NULL,
  decided_at TEXT NOT NULL,
  decided_revision TEXT NOT NULL DEFAULT '',
  note TEXT NOT NULL DEFAULT ''
);
CREATE TABLE brand_deals (
  id TEXT PRIMARY KEY,
  brand TEXT NOT NULL,
  status TEXT NOT NULL,
  tier TEXT,
  deal_value_usd REAL,
  budget_usd REAL,
  amount_agreed_usd REAL,
  suggested_rate_usd REAL,
  paid_in_full INTEGER NOT NULL DEFAULT 0,
  deadline TEXT,
  follow_up_date TEXT,
  contact_name TEXT,
  contact_email TEXT,
  main_channel TEXT,
  video_type TEXT,
  source TEXT,
  icp_fit TEXT,
  notion_url TEXT NOT NULL,
  last_edited TEXT NOT NULL,
  seeded INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE trading_orders (
  id TEXT PRIMARY KEY,
  account_id TEXT NOT NULL DEFAULT 'agentic',
  symbol TEXT NOT NULL,
  side TEXT NOT NULL,
  type TEXT NOT NULL,
  state TEXT NOT NULL,
  quantity REAL NOT NULL,
  filled_quantity REAL NOT NULL DEFAULT 0,
  dollar_amount_usd REAL,
  limit_price_usd REAL,
  placed_agent TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL
);
CREATE TABLE trading_analysis (
  id TEXT PRIMARY KEY,
  at TEXT NOT NULL,
  account_id TEXT NOT NULL DEFAULT 'agentic',
  agent TEXT NOT NULL,
  examined INTEGER NOT NULL DEFAULT 0,
  signals INTEGER NOT NULL DEFAULT 0,
  notes TEXT NOT NULL DEFAULT '',
  rows TEXT NOT NULL DEFAULT '[]'
);
CREATE TABLE trading_activity (
  id TEXT PRIMARY KEY,
  at TEXT NOT NULL,
  account_id TEXT NOT NULL DEFAULT 'individual',
  agent TEXT NOT NULL,
  action TEXT NOT NULL,
  symbol TEXT NOT NULL,
  quantity REAL NOT NULL,
  price_usd REAL NOT NULL,
  rationale TEXT NOT NULL DEFAULT '',
  status TEXT NOT NULL
);
INSERT INTO trading_activity VALUES('tr-seed-5','2026-08-13T14:58:00.000Z','agentic','Markets Agent','buy','SPY',1.0,601.3999999999999773,'Parking idle buying power in the index sleeve.','filled');
INSERT INTO trading_activity VALUES('tr-seed-4','2026-08-13T13:20:00.000Z','agentic','Markets Agent','sell','TSLA',2.0,240.8000000000000113,'Trimming into strength; thesis played out, rotating to cash.','filled');
INSERT INTO trading_activity VALUES('tr-seed-3','2026-08-12T18:05:00.000Z','individual','Alex (manual)','buy','AAPL',4.0,213.9000000000000056,'Dollar-cost tranche into the core holding.','filled');
INSERT INTO trading_activity VALUES('tr-seed-2','2026-08-12T15:41:00.000Z','agentic','Markets Agent','buy','VOO',5.0,83.01999999999999603,'Parking idle buying power in the index sleeve.','filled');
INSERT INTO trading_activity VALUES('tr-seed-1','2026-08-11T16:12:00.000Z','individual','Alex (manual)','buy','MSFT',3.0,428.0,'Initiating position per the approved watchlist.','filled');
CREATE TABLE trading_limits (
  id INTEGER PRIMARY KEY CHECK (id = 1),
  max_notional_per_trade_usd REAL NOT NULL,
  max_position_pct_of_sleeve REAL NOT NULL,
  max_risk_pct_per_trade REAL NOT NULL,
  max_concurrent_positions INTEGER NOT NULL,
  max_trades_per_day INTEGER NOT NULL,
  min_sleeve_value_usd REAL NOT NULL,
  max_deployed_capital_usd REAL NOT NULL,
  autopilot INTEGER NOT NULL DEFAULT 0,
  updated_at TEXT NOT NULL
);
CREATE TABLE usage_snapshots (
  id TEXT PRIMARY KEY,
  captured_at TEXT NOT NULL,
  payload TEXT NOT NULL
);
CREATE TABLE ollama_snapshots (
  id TEXT PRIMARY KEY,
  captured_at TEXT NOT NULL,
  payload TEXT NOT NULL
);
CREATE TABLE broadcasts (
  id TEXT PRIMARY KEY,
  message TEXT NOT NULL,
  created_at TEXT NOT NULL
);
CREATE TABLE agent_tasks (
  id TEXT PRIMARY KEY,
  agent_id TEXT NOT NULL,
  title TEXT NOT NULL,
  status TEXT NOT NULL,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
INSERT INTO agent_tasks VALUES('task-seed-1','comms-agent','Triage overnight inbound across 4 inboxes','open','2026-07-21T12:00:00.000Z','2026-07-21T12:00:00.000Z');
INSERT INTO agent_tasks VALUES('task-seed-2','social-agent','Draft 3 IG hooks for the Vantage launch','open','2026-07-21T12:00:00.000Z','2026-07-21T12:00:00.000Z');
INSERT INTO agent_tasks VALUES('task-seed-3','gmail-worker','Follow up on 6 unreplied warm leads','open','2026-07-21T12:00:00.000Z','2026-07-21T12:00:00.000Z');
INSERT INTO agent_tasks VALUES('task-seed-4','adsmith-creative','Generate 5 UGC variants for the new offer','open','2026-07-21T12:00:00.000Z','2026-07-21T12:00:00.000Z');
INSERT INTO agent_tasks VALUES('task-seed-5','postly-publisher','Schedule this week''s cross-platform posts','doing','2026-07-21T12:00:00.000Z','2026-07-21T12:00:00.000Z');
INSERT INTO agent_tasks VALUES('task-seed-6','comms-agent','Qualify 12 new DMs from the campaign','doing','2026-07-21T12:00:00.000Z','2026-07-21T12:00:00.000Z');
INSERT INTO agent_tasks VALUES('task-seed-7','reelkit-editor','Cut the sales-call highlight reel','doing','2026-07-21T12:00:00.000Z','2026-07-21T12:00:00.000Z');
INSERT INTO agent_tasks VALUES('task-seed-8','gmail-worker','Send the Vantage proposal follow-up','done','2026-07-21T12:00:00.000Z','2026-07-21T12:00:00.000Z');
INSERT INTO agent_tasks VALUES('task-seed-9','slack-worker','Post the Monday standup digest','done','2026-07-21T12:00:00.000Z','2026-07-21T12:00:00.000Z');
INSERT INTO agent_tasks VALUES('task-seed-10','social-agent','Publish the Tuesday carousel','done','2026-07-21T12:00:00.000Z','2026-07-21T12:00:00.000Z');
INSERT INTO agent_tasks VALUES('task-seed-11','postly-publisher','Sync follower counts across 6 platforms','done','2026-07-21T12:00:00.000Z','2026-07-21T12:00:00.000Z');
CREATE TABLE agent_crons (
  id TEXT PRIMARY KEY,
  agent_id TEXT NOT NULL,
  schedule TEXT NOT NULL,
  description TEXT NOT NULL,
  enabled INTEGER NOT NULL,
  created_at TEXT NOT NULL
);
INSERT INTO agent_crons VALUES('cron-comms-digest-0900','comms-digest','0 9 * * *','Morning comms report: 24h of email, WhatsApp and Slack, ranked by who needs a reply',1,'2026-08-18T00:00:00.000Z');
INSERT INTO agent_crons VALUES('cron-plaud-ingest-30m','sales-calls-data','*/30 * * * *','File every newly transcribed Plaud recording into G-Brain (summary + transcript) and its action items into OptimalEngine; no LLM, pure code',1,'2026-08-26T00:00:00.000Z');
INSERT INTO agent_crons VALUES('cron-stack-monitor-0700','stack-monitor','0 7 * * *','Local stack check: Paperclip, Hermes, G-Brain and the CLIs the OS shells out to',1,'2026-08-18T00:00:00.000Z');
INSERT INTO agent_crons VALUES('cron-payments-pulse-0800','payments-pulse','0 8 * * *','Payment processors reachable, plus Stripe balance and recent charges',1,'2026-08-18T00:00:00.000Z');
INSERT INTO agent_crons VALUES('cron-client-onboarding-0830','client-onboarding','30 8 * * *','Onboarding SOP readiness: the payment trigger and the Slack workspace it provisions',1,'2026-08-18T00:00:00.000Z');
INSERT INTO agent_crons VALUES('cron-crm-pulse-0900','crm-pulse','0 9 * * 1-5','Lead lane health: Typeform leads, calendar bookings, Fathom calls',1,'2026-08-18T00:00:00.000Z');
INSERT INTO agent_crons VALUES('cron-social-agent-1800','social-agent','0 18 * * *','Zernio publishing and Arcads ad generation, checked before the evening',1,'2026-08-18T00:00:00.000Z');
CREATE TABLE cron_runs (
  id TEXT PRIMARY KEY,
  cron_id TEXT NOT NULL,
  agent_id TEXT NOT NULL,
  started_at TEXT NOT NULL,
  finished_at TEXT,
  ok INTEGER NOT NULL,
  summary TEXT NOT NULL
);
CREATE TABLE digest_reads (
  key TEXT PRIMARY KEY,
  read_at TEXT NOT NULL
);
CREATE TABLE comms_digests (
  id TEXT PRIMARY KEY,
  generated_at TEXT NOT NULL,
  payload TEXT NOT NULL
);
CREATE TABLE plaud_ingests (
  file_id TEXT PRIMARY KEY,
  title TEXT NOT NULL,
  recorded_at TEXT NOT NULL,
  ingested_at TEXT NOT NULL,
  via TEXT NOT NULL,
  slug TEXT NOT NULL,
  claims INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE contact_tags (
  person TEXT NOT NULL,
  channel TEXT NOT NULL,
  tag TEXT NOT NULL,
  tier INTEGER NOT NULL,
  PRIMARY KEY (person, channel)
);
CREATE TABLE social_accounts (
  platform TEXT PRIMARY KEY,
  handle TEXT NOT NULL,
  url TEXT,
  "order" INTEGER NOT NULL
);
INSERT INTO social_accounts VALUES('instagram','@founderos.ai','https://instagram.com/founderos.ai',1);
INSERT INTO social_accounts VALUES('tiktok','@founderos.ai','https://tiktok.com/@founderos.ai',2);
INSERT INTO social_accounts VALUES('twitter','@Founderosai','https://x.com/Founderosai',3);
INSERT INTO social_accounts VALUES('youtube','@founderosai','https://youtube.com/@founderosai',4);
INSERT INTO social_accounts VALUES('linkedin','Alex',NULL,5);
CREATE TABLE social_snapshots (
  platform TEXT NOT NULL,
  captured_at TEXT NOT NULL,
  followers INTEGER NOT NULL,
  source TEXT NOT NULL,
  PRIMARY KEY (platform, captured_at)
);
INSERT INTO social_snapshots VALUES('instagram','2026-03-14',46083,'seed-dummy');
INSERT INTO social_snapshots VALUES('instagram','2026-03-15',46148,'seed-dummy');
INSERT INTO social_snapshots VALUES('instagram','2026-03-16',46186,'seed-dummy');
INSERT INTO social_snapshots VALUES('instagram','2026-03-17',46203,'seed-dummy');
INSERT INTO social_snapshots VALUES('instagram','2026-03-18',46220,'seed-dummy');
INSERT INTO social_snapshots VALUES('instagram','2026-03-19',46253,'seed-dummy');
INSERT INTO social_snapshots VALUES('instagram','2026-03-20',46314,'seed-dummy');
INSERT INTO social_snapshots VALUES('instagram','2026-03-21',46401,'seed-dummy');
INSERT INTO social_snapshots VALUES('instagram','2026-03-22',46500,'seed-dummy');
INSERT INTO social_snapshots VALUES('instagram','2026-03-23',46594,'seed-dummy');
INSERT INTO social_snapshots VALUES('instagram','2026-03-24',46668,'seed-dummy');
INSERT INTO social_snapshots VALUES('instagram','2026-03-25',46719,'seed-dummy');
INSERT INTO social_snapshots VALUES('instagram','2026-03-26',46755,'seed-dummy');
INSERT INTO social_snapshots VALUES('instagram','2026-03-27',46793,'seed-dummy');
INSERT INTO social_snapshots VALUES('instagram','2026-03-28',46851,'seed-dummy');
INSERT INTO social_snapshots VALUES('instagram','2026-03-29',46937,'seed-dummy');
INSERT INTO social_snapshots VALUES('instagram','2026-03-30',47048,'seed-dummy');
INSERT INTO social_snapshots VALUES('instagram','2026-03-31',47169,'seed-dummy');
INSERT INTO social_snapshots VALUES('instagram','2026-04-01',47282,'seed-dummy');
INSERT INTO social_snapshots VALUES('instagram','2026-04-02',47370,'seed-dummy');
INSERT INTO social_snapshots VALUES('instagram','2026-04-03',47430,'seed-dummy');
INSERT INTO social_snapshots VALUES('instagram','2026-04-04',47470,'seed-dummy');
INSERT INTO social_snapshots VALUES('instagram','2026-04-05',47508,'seed-dummy');
INSERT INTO social_snapshots VALUES('instagram','2026-04-06',47561,'seed-dummy');
INSERT INTO social_snapshots VALUES('instagram','2026-04-07',47639,'seed-dummy');
INSERT INTO social_snapshots VALUES('instagram','2026-04-08',47738,'seed-dummy');
INSERT INTO social_snapshots VALUES('instagram','2026-04-09',47846,'seed-dummy');
INSERT INTO social_snapshots VALUES('instagram','2026-04-10',47944,'seed-dummy');
INSERT INTO social_snapshots VALUES('instagram','2026-04-11',48018,'seed-dummy');
INSERT INTO social_snapshots VALUES('instagram','2026-04-12',48067,'seed-dummy');
INSERT INTO social_snapshots VALUES('instagram','2026-04-13',48101,'seed-dummy');
INSERT INTO social_snapshots VALUES('instagram','2026-04-14',48137,'seed-dummy');
INSERT INTO social_snapshots VALUES('instagram','2026-04-15',48193,'seed-dummy');
INSERT INTO social_snapshots VALUES('instagram','2026-04-16',48280,'seed-dummy');
INSERT INTO social_snapshots VALUES('instagram','2026-04-17',48393,'seed-dummy');
INSERT INTO social_snapshots VALUES('instagram','2026-04-18',48517,'seed-dummy');
INSERT INTO social_snapshots VALUES('instagram','2026-04-19',48636,'seed-dummy');
INSERT INTO social_snapshots VALUES('instagram','2026-04-20',48733,'seed-dummy');
INSERT INTO social_snapshots VALUES('instagram','2026-04-21',48806,'seed-dummy');
INSERT INTO social_snapshots VALUES('instagram','2026-04-22',48864,'seed-dummy');
INSERT INTO social_snapshots VALUES('instagram','2026-04-23',48923,'seed-dummy');
INSERT INTO social_snapshots VALUES('instagram','2026-04-24',48999,'seed-dummy');
INSERT INTO social_snapshots VALUES('instagram','2026-04-25',49102,'seed-dummy');
INSERT INTO social_snapshots VALUES('instagram','2026-04-26',49227,'seed-dummy');
INSERT INTO social_snapshots VALUES('instagram','2026-04-27',49357,'seed-dummy');
INSERT INTO social_snapshots VALUES('instagram','2026-04-28',49476,'seed-dummy');
INSERT INTO social_snapshots VALUES('instagram','2026-04-29',49569,'seed-dummy');
INSERT INTO social_snapshots VALUES('instagram','2026-04-30',49633,'seed-dummy');
INSERT INTO social_snapshots VALUES('instagram','2026-05-01',49679,'seed-dummy');
INSERT INTO social_snapshots VALUES('instagram','2026-05-02',49725,'seed-dummy');
INSERT INTO social_snapshots VALUES('instagram','2026-05-03',49788,'seed-dummy');
INSERT INTO social_snapshots VALUES('instagram','2026-05-04',49879,'seed-dummy');
INSERT INTO social_snapshots VALUES('instagram','2026-05-05',49992,'seed-dummy');
INSERT INTO social_snapshots VALUES('instagram','2026-05-06',50115,'seed-dummy');
INSERT INTO social_snapshots VALUES('instagram','2026-05-07',50230,'seed-dummy');
INSERT INTO social_snapshots VALUES('instagram','2026-05-08',50323,'seed-dummy');
INSERT INTO social_snapshots VALUES('instagram','2026-05-09',50394,'seed-dummy');
INSERT INTO social_snapshots VALUES('instagram','2026-05-10',50451,'seed-dummy');
INSERT INTO social_snapshots VALUES('instagram','2026-05-11',50513,'seed-dummy');
INSERT INTO social_snapshots VALUES('instagram','2026-05-12',50597,'seed-dummy');
INSERT INTO social_snapshots VALUES('instagram','2026-05-13',50711,'seed-dummy');
INSERT INTO social_snapshots VALUES('instagram','2026-05-14',50850,'seed-dummy');
INSERT INTO social_snapshots VALUES('instagram','2026-05-15',50997,'seed-dummy');
INSERT INTO social_snapshots VALUES('instagram','2026-05-16',51135,'seed-dummy');
INSERT INTO social_snapshots VALUES('instagram','2026-05-17',51248,'seed-dummy');
INSERT INTO social_snapshots VALUES('instagram','2026-05-18',51335,'seed-dummy');
INSERT INTO social_snapshots VALUES('instagram','2026-05-19',51404,'seed-dummy');
INSERT INTO social_snapshots VALUES('instagram','2026-05-20',51474,'seed-dummy');
INSERT INTO social_snapshots VALUES('instagram','2026-05-21',51561,'seed-dummy');
INSERT INTO social_snapshots VALUES('instagram','2026-05-22',51673,'seed-dummy');
INSERT INTO social_snapshots VALUES('instagram','2026-05-23',51805,'seed-dummy');
INSERT INTO social_snapshots VALUES('instagram','2026-05-24',51941,'seed-dummy');
INSERT INTO social_snapshots VALUES('instagram','2026-05-25',52065,'seed-dummy');
INSERT INTO social_snapshots VALUES('instagram','2026-05-26',52164,'seed-dummy');
INSERT INTO social_snapshots VALUES('instagram','2026-05-27',52237,'seed-dummy');
INSERT INTO social_snapshots VALUES('instagram','2026-05-28',52294,'seed-dummy');
INSERT INTO social_snapshots VALUES('instagram','2026-05-29',52356,'seed-dummy');
INSERT INTO social_snapshots VALUES('instagram','2026-05-30',52439,'seed-dummy');
INSERT INTO social_snapshots VALUES('instagram','2026-05-31',52551,'seed-dummy');
INSERT INTO social_snapshots VALUES('instagram','2026-06-01',52688,'seed-dummy');
INSERT INTO social_snapshots VALUES('instagram','2026-06-02',52835,'seed-dummy');
INSERT INTO social_snapshots VALUES('instagram','2026-06-03',52974,'seed-dummy');
INSERT INTO social_snapshots VALUES('instagram','2026-06-04',53091,'seed-dummy');
INSERT INTO social_snapshots VALUES('instagram','2026-06-05',53185,'seed-dummy');
INSERT INTO social_snapshots VALUES('instagram','2026-06-06',53267,'seed-dummy');
INSERT INTO social_snapshots VALUES('instagram','2026-06-07',53353,'seed-dummy');
INSERT INTO social_snapshots VALUES('instagram','2026-06-08',53460,'seed-dummy');
INSERT INTO social_snapshots VALUES('instagram','2026-06-09',53595,'seed-dummy');
INSERT INTO social_snapshots VALUES('instagram','2026-06-10',53750,'seed-dummy');
INSERT INTO social_snapshots VALUES('instagram','2026-06-11',53911,'seed-dummy');
INSERT INTO social_snapshots VALUES('instagram','2026-06-12',53970,'zernio-config');
INSERT INTO social_snapshots VALUES('tiktok','2026-03-14',8904,'seed-dummy');
INSERT INTO social_snapshots VALUES('tiktok','2026-03-15',8909,'seed-dummy');
INSERT INTO social_snapshots VALUES('tiktok','2026-03-16',8912,'seed-dummy');
INSERT INTO social_snapshots VALUES('tiktok','2026-03-17',8917,'seed-dummy');
INSERT INTO social_snapshots VALUES('tiktok','2026-03-18',8926,'seed-dummy');
INSERT INTO social_snapshots VALUES('tiktok','2026-03-19',8941,'seed-dummy');
INSERT INTO social_snapshots VALUES('tiktok','2026-03-20',8958,'seed-dummy');
INSERT INTO social_snapshots VALUES('tiktok','2026-03-21',8977,'seed-dummy');
INSERT INTO social_snapshots VALUES('tiktok','2026-03-22',8993,'seed-dummy');
INSERT INTO social_snapshots VALUES('tiktok','2026-03-23',9006,'seed-dummy');
INSERT INTO social_snapshots VALUES('tiktok','2026-03-24',9014,'seed-dummy');
INSERT INTO social_snapshots VALUES('tiktok','2026-03-25',9020,'seed-dummy');
INSERT INTO social_snapshots VALUES('tiktok','2026-03-26',9027,'seed-dummy');
INSERT INTO social_snapshots VALUES('tiktok','2026-03-27',9038,'seed-dummy');
INSERT INTO social_snapshots VALUES('tiktok','2026-03-28',9053,'seed-dummy');
INSERT INTO social_snapshots VALUES('tiktok','2026-03-29',9070,'seed-dummy');
INSERT INTO social_snapshots VALUES('tiktok','2026-03-30',9087,'seed-dummy');
INSERT INTO social_snapshots VALUES('tiktok','2026-03-31',9102,'seed-dummy');
INSERT INTO social_snapshots VALUES('tiktok','2026-04-01',9112,'seed-dummy');
INSERT INTO social_snapshots VALUES('tiktok','2026-04-02',9118,'seed-dummy');
INSERT INTO social_snapshots VALUES('tiktok','2026-04-03',9122,'seed-dummy');
INSERT INTO social_snapshots VALUES('tiktok','2026-04-04',9127,'seed-dummy');
INSERT INTO social_snapshots VALUES('tiktok','2026-04-05',9136,'seed-dummy');
INSERT INTO social_snapshots VALUES('tiktok','2026-04-06',9150,'seed-dummy');
INSERT INTO social_snapshots VALUES('tiktok','2026-04-07',9168,'seed-dummy');
INSERT INTO social_snapshots VALUES('tiktok','2026-04-08',9186,'seed-dummy');
INSERT INTO social_snapshots VALUES('tiktok','2026-04-09',9202,'seed-dummy');
INSERT INTO social_snapshots VALUES('tiktok','2026-04-10',9214,'seed-dummy');
INSERT INTO social_snapshots VALUES('tiktok','2026-04-11',9223,'seed-dummy');
INSERT INTO social_snapshots VALUES('tiktok','2026-04-12',9231,'seed-dummy');
INSERT INTO social_snapshots VALUES('tiktok','2026-04-13',9240,'seed-dummy');
INSERT INTO social_snapshots VALUES('tiktok','2026-04-14',9254,'seed-dummy');
INSERT INTO social_snapshots VALUES('tiktok','2026-04-15',9272,'seed-dummy');
INSERT INTO social_snapshots VALUES('tiktok','2026-04-16',9293,'seed-dummy');
INSERT INTO social_snapshots VALUES('tiktok','2026-04-17',9314,'seed-dummy');
INSERT INTO social_snapshots VALUES('tiktok','2026-04-18',9332,'seed-dummy');
INSERT INTO social_snapshots VALUES('tiktok','2026-04-19',9346,'seed-dummy');
INSERT INTO social_snapshots VALUES('tiktok','2026-04-20',9355,'seed-dummy');
INSERT INTO social_snapshots VALUES('tiktok','2026-04-21',9363,'seed-dummy');
INSERT INTO social_snapshots VALUES('tiktok','2026-04-22',9371,'seed-dummy');
INSERT INTO social_snapshots VALUES('tiktok','2026-04-23',9383,'seed-dummy');
INSERT INTO social_snapshots VALUES('tiktok','2026-04-24',9399,'seed-dummy');
INSERT INTO social_snapshots VALUES('tiktok','2026-04-25',9418,'seed-dummy');
INSERT INTO social_snapshots VALUES('tiktok','2026-04-26',9437,'seed-dummy');
INSERT INTO social_snapshots VALUES('tiktok','2026-04-27',9453,'seed-dummy');
INSERT INTO social_snapshots VALUES('tiktok','2026-04-28',9465,'seed-dummy');
INSERT INTO social_snapshots VALUES('tiktok','2026-04-29',9473,'seed-dummy');
INSERT INTO social_snapshots VALUES('tiktok','2026-04-30',9480,'seed-dummy');
INSERT INTO social_snapshots VALUES('tiktok','2026-05-01',9489,'seed-dummy');
INSERT INTO social_snapshots VALUES('tiktok','2026-05-02',9503,'seed-dummy');
INSERT INTO social_snapshots VALUES('tiktok','2026-05-03',9521,'seed-dummy');
INSERT INTO social_snapshots VALUES('tiktok','2026-05-04',9543,'seed-dummy');
INSERT INTO social_snapshots VALUES('tiktok','2026-05-05',9566,'seed-dummy');
INSERT INTO social_snapshots VALUES('tiktok','2026-05-06',9585,'seed-dummy');
INSERT INTO social_snapshots VALUES('tiktok','2026-05-07',9601,'seed-dummy');
INSERT INTO social_snapshots VALUES('tiktok','2026-05-08',9614,'seed-dummy');
INSERT INTO social_snapshots VALUES('tiktok','2026-05-09',9624,'seed-dummy');
INSERT INTO social_snapshots VALUES('tiktok','2026-05-10',9637,'seed-dummy');
INSERT INTO social_snapshots VALUES('tiktok','2026-05-11',9653,'seed-dummy');
INSERT INTO social_snapshots VALUES('tiktok','2026-05-12',9673,'seed-dummy');
INSERT INTO social_snapshots VALUES('tiktok','2026-05-13',9696,'seed-dummy');
INSERT INTO social_snapshots VALUES('tiktok','2026-05-14',9718,'seed-dummy');
INSERT INTO social_snapshots VALUES('tiktok','2026-05-15',9737,'seed-dummy');
INSERT INTO social_snapshots VALUES('tiktok','2026-05-16',9752,'seed-dummy');
INSERT INTO social_snapshots VALUES('tiktok','2026-05-17',9762,'seed-dummy');
INSERT INTO social_snapshots VALUES('tiktok','2026-05-18',9770,'seed-dummy');
INSERT INTO social_snapshots VALUES('tiktok','2026-05-19',9781,'seed-dummy');
INSERT INTO social_snapshots VALUES('tiktok','2026-05-20',9795,'seed-dummy');
INSERT INTO social_snapshots VALUES('tiktok','2026-05-21',9813,'seed-dummy');
INSERT INTO social_snapshots VALUES('tiktok','2026-05-22',9835,'seed-dummy');
INSERT INTO social_snapshots VALUES('tiktok','2026-05-23',9857,'seed-dummy');
INSERT INTO social_snapshots VALUES('tiktok','2026-05-24',9876,'seed-dummy');
INSERT INTO social_snapshots VALUES('tiktok','2026-05-25',9891,'seed-dummy');
INSERT INTO social_snapshots VALUES('tiktok','2026-05-26',9904,'seed-dummy');
INSERT INTO social_snapshots VALUES('tiktok','2026-05-27',9915,'seed-dummy');
INSERT INTO social_snapshots VALUES('tiktok','2026-05-28',9929,'seed-dummy');
INSERT INTO social_snapshots VALUES('tiktok','2026-05-29',9947,'seed-dummy');
INSERT INTO social_snapshots VALUES('tiktok','2026-05-30',9969,'seed-dummy');
INSERT INTO social_snapshots VALUES('tiktok','2026-05-31',9995,'seed-dummy');
INSERT INTO social_snapshots VALUES('tiktok','2026-06-01',10021,'seed-dummy');
INSERT INTO social_snapshots VALUES('tiktok','2026-06-02',10043,'seed-dummy');
INSERT INTO social_snapshots VALUES('tiktok','2026-06-03',10061,'seed-dummy');
INSERT INTO social_snapshots VALUES('tiktok','2026-06-04',10075,'seed-dummy');
INSERT INTO social_snapshots VALUES('tiktok','2026-06-05',10088,'seed-dummy');
INSERT INTO social_snapshots VALUES('tiktok','2026-06-06',10102,'seed-dummy');
INSERT INTO social_snapshots VALUES('tiktok','2026-06-07',10119,'seed-dummy');
INSERT INTO social_snapshots VALUES('tiktok','2026-06-08',10141,'seed-dummy');
INSERT INTO social_snapshots VALUES('tiktok','2026-06-09',10165,'seed-dummy');
INSERT INTO social_snapshots VALUES('tiktok','2026-06-10',10188,'seed-dummy');
INSERT INTO social_snapshots VALUES('tiktok','2026-06-11',10208,'seed-dummy');
INSERT INTO social_snapshots VALUES('tiktok','2026-06-12',10216,'zernio-config');
INSERT INTO social_snapshots VALUES('twitter','2026-03-14',3850,'seed-dummy');
INSERT INTO social_snapshots VALUES('twitter','2026-03-15',3851,'seed-dummy');
INSERT INTO social_snapshots VALUES('twitter','2026-03-16',3853,'seed-dummy');
INSERT INTO social_snapshots VALUES('twitter','2026-03-17',3857,'seed-dummy');
INSERT INTO social_snapshots VALUES('twitter','2026-03-18',3861,'seed-dummy');
INSERT INTO social_snapshots VALUES('twitter','2026-03-19',3866,'seed-dummy');
INSERT INTO social_snapshots VALUES('twitter','2026-03-20',3870,'seed-dummy');
INSERT INTO social_snapshots VALUES('twitter','2026-03-21',3873,'seed-dummy');
INSERT INTO social_snapshots VALUES('twitter','2026-03-22',3876,'seed-dummy');
INSERT INTO social_snapshots VALUES('twitter','2026-03-23',3877,'seed-dummy');
INSERT INTO social_snapshots VALUES('twitter','2026-03-24',3878,'seed-dummy');
INSERT INTO social_snapshots VALUES('twitter','2026-03-25',3879,'seed-dummy');
INSERT INTO social_snapshots VALUES('twitter','2026-03-26',3882,'seed-dummy');
INSERT INTO social_snapshots VALUES('twitter','2026-03-27',3886,'seed-dummy');
INSERT INTO social_snapshots VALUES('twitter','2026-03-28',3890,'seed-dummy');
INSERT INTO social_snapshots VALUES('twitter','2026-03-29',3894,'seed-dummy');
INSERT INTO social_snapshots VALUES('twitter','2026-03-30',3897,'seed-dummy');
INSERT INTO social_snapshots VALUES('twitter','2026-03-31',3899,'seed-dummy');
INSERT INTO social_snapshots VALUES('twitter','2026-04-01',3901,'seed-dummy');
INSERT INTO social_snapshots VALUES('twitter','2026-04-02',3902,'seed-dummy');
INSERT INTO social_snapshots VALUES('twitter','2026-04-03',3905,'seed-dummy');
INSERT INTO social_snapshots VALUES('twitter','2026-04-04',3908,'seed-dummy');
INSERT INTO social_snapshots VALUES('twitter','2026-04-05',3913,'seed-dummy');
INSERT INTO social_snapshots VALUES('twitter','2026-04-06',3918,'seed-dummy');
INSERT INTO social_snapshots VALUES('twitter','2026-04-07',3923,'seed-dummy');
INSERT INTO social_snapshots VALUES('twitter','2026-04-08',3928,'seed-dummy');
INSERT INTO social_snapshots VALUES('twitter','2026-04-09',3931,'seed-dummy');
INSERT INTO social_snapshots VALUES('twitter','2026-04-10',3933,'seed-dummy');
INSERT INTO social_snapshots VALUES('twitter','2026-04-11',3935,'seed-dummy');
INSERT INTO social_snapshots VALUES('twitter','2026-04-12',3937,'seed-dummy');
INSERT INTO social_snapshots VALUES('twitter','2026-04-13',3941,'seed-dummy');
INSERT INTO social_snapshots VALUES('twitter','2026-04-14',3946,'seed-dummy');
INSERT INTO social_snapshots VALUES('twitter','2026-04-15',3951,'seed-dummy');
INSERT INTO social_snapshots VALUES('twitter','2026-04-16',3955,'seed-dummy');
INSERT INTO social_snapshots VALUES('twitter','2026-04-17',3959,'seed-dummy');
INSERT INTO social_snapshots VALUES('twitter','2026-04-18',3961,'seed-dummy');
INSERT INTO social_snapshots VALUES('twitter','2026-04-19',3963,'seed-dummy');
INSERT INTO social_snapshots VALUES('twitter','2026-04-20',3965,'seed-dummy');
INSERT INTO social_snapshots VALUES('twitter','2026-04-21',3967,'seed-dummy');
INSERT INTO social_snapshots VALUES('twitter','2026-04-22',3970,'seed-dummy');
INSERT INTO social_snapshots VALUES('twitter','2026-04-23',3975,'seed-dummy');
INSERT INTO social_snapshots VALUES('twitter','2026-04-24',3980,'seed-dummy');
INSERT INTO social_snapshots VALUES('twitter','2026-04-25',3985,'seed-dummy');
INSERT INTO social_snapshots VALUES('twitter','2026-04-26',3990,'seed-dummy');
INSERT INTO social_snapshots VALUES('twitter','2026-04-27',3993,'seed-dummy');
INSERT INTO social_snapshots VALUES('twitter','2026-04-28',3995,'seed-dummy');
INSERT INTO social_snapshots VALUES('twitter','2026-04-29',3998,'seed-dummy');
INSERT INTO social_snapshots VALUES('twitter','2026-04-30',4001,'seed-dummy');
INSERT INTO social_snapshots VALUES('twitter','2026-05-01',4006,'seed-dummy');
INSERT INTO social_snapshots VALUES('twitter','2026-05-02',4011,'seed-dummy');
INSERT INTO social_snapshots VALUES('twitter','2026-05-03',4017,'seed-dummy');
INSERT INTO social_snapshots VALUES('twitter','2026-05-04',4023,'seed-dummy');
INSERT INTO social_snapshots VALUES('twitter','2026-05-05',4028,'seed-dummy');
INSERT INTO social_snapshots VALUES('twitter','2026-05-06',4031,'seed-dummy');
INSERT INTO social_snapshots VALUES('twitter','2026-05-07',4033,'seed-dummy');
INSERT INTO social_snapshots VALUES('twitter','2026-05-08',4036,'seed-dummy');
INSERT INTO social_snapshots VALUES('twitter','2026-05-09',4039,'seed-dummy');
INSERT INTO social_snapshots VALUES('twitter','2026-05-10',4043,'seed-dummy');
INSERT INTO social_snapshots VALUES('twitter','2026-05-11',4048,'seed-dummy');
INSERT INTO social_snapshots VALUES('twitter','2026-05-12',4053,'seed-dummy');
INSERT INTO social_snapshots VALUES('twitter','2026-05-13',4058,'seed-dummy');
INSERT INTO social_snapshots VALUES('twitter','2026-05-14',4062,'seed-dummy');
INSERT INTO social_snapshots VALUES('twitter','2026-05-15',4065,'seed-dummy');
INSERT INTO social_snapshots VALUES('twitter','2026-05-16',4068,'seed-dummy');
INSERT INTO social_snapshots VALUES('twitter','2026-05-17',4070,'seed-dummy');
INSERT INTO social_snapshots VALUES('twitter','2026-05-18',4074,'seed-dummy');
INSERT INTO social_snapshots VALUES('twitter','2026-05-19',4078,'seed-dummy');
INSERT INTO social_snapshots VALUES('twitter','2026-05-20',4084,'seed-dummy');
INSERT INTO social_snapshots VALUES('twitter','2026-05-21',4091,'seed-dummy');
INSERT INTO social_snapshots VALUES('twitter','2026-05-22',4097,'seed-dummy');
INSERT INTO social_snapshots VALUES('twitter','2026-05-23',4102,'seed-dummy');
INSERT INTO social_snapshots VALUES('twitter','2026-05-24',4106,'seed-dummy');
INSERT INTO social_snapshots VALUES('twitter','2026-05-25',4109,'seed-dummy');
INSERT INTO social_snapshots VALUES('twitter','2026-05-26',4113,'seed-dummy');
INSERT INTO social_snapshots VALUES('twitter','2026-05-27',4117,'seed-dummy');
INSERT INTO social_snapshots VALUES('twitter','2026-05-28',4122,'seed-dummy');
INSERT INTO social_snapshots VALUES('twitter','2026-05-29',4128,'seed-dummy');
INSERT INTO social_snapshots VALUES('twitter','2026-05-30',4134,'seed-dummy');
INSERT INTO social_snapshots VALUES('twitter','2026-05-31',4140,'seed-dummy');
INSERT INTO social_snapshots VALUES('twitter','2026-06-01',4145,'seed-dummy');
INSERT INTO social_snapshots VALUES('twitter','2026-06-02',4148,'seed-dummy');
INSERT INTO social_snapshots VALUES('twitter','2026-06-03',4151,'seed-dummy');
INSERT INTO social_snapshots VALUES('twitter','2026-06-04',4154,'seed-dummy');
INSERT INTO social_snapshots VALUES('twitter','2026-06-05',4157,'seed-dummy');
INSERT INTO social_snapshots VALUES('twitter','2026-06-06',4162,'seed-dummy');
INSERT INTO social_snapshots VALUES('twitter','2026-06-07',4168,'seed-dummy');
INSERT INTO social_snapshots VALUES('twitter','2026-06-08',4174,'seed-dummy');
INSERT INTO social_snapshots VALUES('twitter','2026-06-09',4180,'seed-dummy');
INSERT INTO social_snapshots VALUES('twitter','2026-06-10',4185,'seed-dummy');
INSERT INTO social_snapshots VALUES('twitter','2026-06-11',4189,'seed-dummy');
INSERT INTO social_snapshots VALUES('twitter','2026-06-12',4194,'zernio-config');
INSERT INTO social_snapshots VALUES('youtube','2026-03-14',760,'seed-dummy');
INSERT INTO social_snapshots VALUES('youtube','2026-03-15',763,'seed-dummy');
INSERT INTO social_snapshots VALUES('youtube','2026-03-16',768,'seed-dummy');
INSERT INTO social_snapshots VALUES('youtube','2026-03-17',774,'seed-dummy');
INSERT INTO social_snapshots VALUES('youtube','2026-03-18',781,'seed-dummy');
INSERT INTO social_snapshots VALUES('youtube','2026-03-19',787,'seed-dummy');
INSERT INTO social_snapshots VALUES('youtube','2026-03-20',791,'seed-dummy');
INSERT INTO social_snapshots VALUES('youtube','2026-03-21',793,'seed-dummy');
INSERT INTO social_snapshots VALUES('youtube','2026-03-22',794,'seed-dummy');
INSERT INTO social_snapshots VALUES('youtube','2026-03-23',796,'seed-dummy');
INSERT INTO social_snapshots VALUES('youtube','2026-03-24',800,'seed-dummy');
INSERT INTO social_snapshots VALUES('youtube','2026-03-25',805,'seed-dummy');
INSERT INTO social_snapshots VALUES('youtube','2026-03-26',813,'seed-dummy');
INSERT INTO social_snapshots VALUES('youtube','2026-03-27',821,'seed-dummy');
INSERT INTO social_snapshots VALUES('youtube','2026-03-28',828,'seed-dummy');
INSERT INTO social_snapshots VALUES('youtube','2026-03-29',834,'seed-dummy');
INSERT INTO social_snapshots VALUES('youtube','2026-03-30',838,'seed-dummy');
INSERT INTO social_snapshots VALUES('youtube','2026-03-31',841,'seed-dummy');
INSERT INTO social_snapshots VALUES('youtube','2026-04-01',844,'seed-dummy');
INSERT INTO social_snapshots VALUES('youtube','2026-04-02',849,'seed-dummy');
INSERT INTO social_snapshots VALUES('youtube','2026-04-03',856,'seed-dummy');
INSERT INTO social_snapshots VALUES('youtube','2026-04-04',864,'seed-dummy');
INSERT INTO social_snapshots VALUES('youtube','2026-04-05',873,'seed-dummy');
INSERT INTO social_snapshots VALUES('youtube','2026-04-06',880,'seed-dummy');
INSERT INTO social_snapshots VALUES('youtube','2026-04-07',885,'seed-dummy');
INSERT INTO social_snapshots VALUES('youtube','2026-04-08',888,'seed-dummy');
INSERT INTO social_snapshots VALUES('youtube','2026-04-09',890,'seed-dummy');
INSERT INTO social_snapshots VALUES('youtube','2026-04-10',893,'seed-dummy');
INSERT INTO social_snapshots VALUES('youtube','2026-04-11',897,'seed-dummy');
INSERT INTO social_snapshots VALUES('youtube','2026-04-12',903,'seed-dummy');
INSERT INTO social_snapshots VALUES('youtube','2026-04-13',910,'seed-dummy');
INSERT INTO social_snapshots VALUES('youtube','2026-04-14',918,'seed-dummy');
INSERT INTO social_snapshots VALUES('youtube','2026-04-15',925,'seed-dummy');
INSERT INTO social_snapshots VALUES('youtube','2026-04-16',931,'seed-dummy');
INSERT INTO social_snapshots VALUES('youtube','2026-04-17',934,'seed-dummy');
INSERT INTO social_snapshots VALUES('youtube','2026-04-18',937,'seed-dummy');
INSERT INTO social_snapshots VALUES('youtube','2026-04-19',941,'seed-dummy');
INSERT INTO social_snapshots VALUES('youtube','2026-04-20',947,'seed-dummy');
INSERT INTO social_snapshots VALUES('youtube','2026-04-21',954,'seed-dummy');
INSERT INTO social_snapshots VALUES('youtube','2026-04-22',964,'seed-dummy');
INSERT INTO social_snapshots VALUES('youtube','2026-04-23',973,'seed-dummy');
INSERT INTO social_snapshots VALUES('youtube','2026-04-24',982,'seed-dummy');
INSERT INTO social_snapshots VALUES('youtube','2026-04-25',988,'seed-dummy');
INSERT INTO social_snapshots VALUES('youtube','2026-04-26',993,'seed-dummy');
INSERT INTO social_snapshots VALUES('youtube','2026-04-27',997,'seed-dummy');
INSERT INTO social_snapshots VALUES('youtube','2026-04-28',1002,'seed-dummy');
INSERT INTO social_snapshots VALUES('youtube','2026-04-29',1007,'seed-dummy');
INSERT INTO social_snapshots VALUES('youtube','2026-04-30',1015,'seed-dummy');
INSERT INTO social_snapshots VALUES('youtube','2026-05-01',1023,'seed-dummy');
INSERT INTO social_snapshots VALUES('youtube','2026-05-02',1032,'seed-dummy');
INSERT INTO social_snapshots VALUES('youtube','2026-05-03',1040,'seed-dummy');
INSERT INTO social_snapshots VALUES('youtube','2026-05-04',1045,'seed-dummy');
INSERT INTO social_snapshots VALUES('youtube','2026-05-05',1049,'seed-dummy');
INSERT INTO social_snapshots VALUES('youtube','2026-05-06',1052,'seed-dummy');
INSERT INTO social_snapshots VALUES('youtube','2026-05-07',1056,'seed-dummy');
INSERT INTO social_snapshots VALUES('youtube','2026-05-08',1062,'seed-dummy');
INSERT INTO social_snapshots VALUES('youtube','2026-05-09',1069,'seed-dummy');
INSERT INTO social_snapshots VALUES('youtube','2026-05-10',1078,'seed-dummy');
INSERT INTO social_snapshots VALUES('youtube','2026-05-11',1088,'seed-dummy');
INSERT INTO social_snapshots VALUES('youtube','2026-05-12',1096,'seed-dummy');
INSERT INTO social_snapshots VALUES('youtube','2026-05-13',1104,'seed-dummy');
INSERT INTO social_snapshots VALUES('youtube','2026-05-14',1109,'seed-dummy');
INSERT INTO social_snapshots VALUES('youtube','2026-05-15',1114,'seed-dummy');
INSERT INTO social_snapshots VALUES('youtube','2026-05-16',1119,'seed-dummy');
INSERT INTO social_snapshots VALUES('youtube','2026-05-17',1127,'seed-dummy');
INSERT INTO social_snapshots VALUES('youtube','2026-05-18',1136,'seed-dummy');
INSERT INTO social_snapshots VALUES('youtube','2026-05-19',1146,'seed-dummy');
INSERT INTO social_snapshots VALUES('youtube','2026-05-20',1156,'seed-dummy');
INSERT INTO social_snapshots VALUES('youtube','2026-05-21',1166,'seed-dummy');
INSERT INTO social_snapshots VALUES('youtube','2026-05-22',1173,'seed-dummy');
INSERT INTO social_snapshots VALUES('youtube','2026-05-23',1178,'seed-dummy');
INSERT INTO social_snapshots VALUES('youtube','2026-05-24',1182,'seed-dummy');
INSERT INTO social_snapshots VALUES('youtube','2026-05-25',1187,'seed-dummy');
INSERT INTO social_snapshots VALUES('youtube','2026-05-26',1194,'seed-dummy');
INSERT INTO social_snapshots VALUES('youtube','2026-05-27',1202,'seed-dummy');
INSERT INTO social_snapshots VALUES('youtube','2026-05-28',1211,'seed-dummy');
INSERT INTO social_snapshots VALUES('youtube','2026-05-29',1221,'seed-dummy');
INSERT INTO social_snapshots VALUES('youtube','2026-05-30',1229,'seed-dummy');
INSERT INTO social_snapshots VALUES('youtube','2026-05-31',1236,'seed-dummy');
INSERT INTO social_snapshots VALUES('youtube','2026-06-01',1241,'seed-dummy');
INSERT INTO social_snapshots VALUES('youtube','2026-06-02',1246,'seed-dummy');
INSERT INTO social_snapshots VALUES('youtube','2026-06-03',1251,'seed-dummy');
INSERT INTO social_snapshots VALUES('youtube','2026-06-04',1259,'seed-dummy');
INSERT INTO social_snapshots VALUES('youtube','2026-06-05',1268,'seed-dummy');
INSERT INTO social_snapshots VALUES('youtube','2026-06-06',1279,'seed-dummy');
INSERT INTO social_snapshots VALUES('youtube','2026-06-07',1291,'seed-dummy');
INSERT INTO social_snapshots VALUES('youtube','2026-06-08',1301,'seed-dummy');
INSERT INTO social_snapshots VALUES('youtube','2026-06-09',1309,'seed-dummy');
INSERT INTO social_snapshots VALUES('youtube','2026-06-10',1316,'seed-dummy');
INSERT INTO social_snapshots VALUES('youtube','2026-06-11',1322,'seed-dummy');
INSERT INTO social_snapshots VALUES('youtube','2026-06-12',1330,'zernio-config');
INSERT INTO social_snapshots VALUES('linkedin','2026-03-14',1841,'seed-dummy');
INSERT INTO social_snapshots VALUES('linkedin','2026-03-15',1850,'seed-dummy');
INSERT INTO social_snapshots VALUES('linkedin','2026-03-16',1862,'seed-dummy');
INSERT INTO social_snapshots VALUES('linkedin','2026-03-17',1874,'seed-dummy');
INSERT INTO social_snapshots VALUES('linkedin','2026-03-18',1883,'seed-dummy');
INSERT INTO social_snapshots VALUES('linkedin','2026-03-19',1890,'seed-dummy');
INSERT INTO social_snapshots VALUES('linkedin','2026-03-20',1895,'seed-dummy');
INSERT INTO social_snapshots VALUES('linkedin','2026-03-21',1899,'seed-dummy');
INSERT INTO social_snapshots VALUES('linkedin','2026-03-22',1905,'seed-dummy');
INSERT INTO social_snapshots VALUES('linkedin','2026-03-23',1914,'seed-dummy');
INSERT INTO social_snapshots VALUES('linkedin','2026-03-24',1926,'seed-dummy');
INSERT INTO social_snapshots VALUES('linkedin','2026-03-25',1941,'seed-dummy');
INSERT INTO social_snapshots VALUES('linkedin','2026-03-26',1954,'seed-dummy');
INSERT INTO social_snapshots VALUES('linkedin','2026-03-27',1965,'seed-dummy');
INSERT INTO social_snapshots VALUES('linkedin','2026-03-28',1973,'seed-dummy');
INSERT INTO social_snapshots VALUES('linkedin','2026-03-29',1978,'seed-dummy');
INSERT INTO social_snapshots VALUES('linkedin','2026-03-30',1982,'seed-dummy');
INSERT INTO social_snapshots VALUES('linkedin','2026-03-31',1987,'seed-dummy');
INSERT INTO social_snapshots VALUES('linkedin','2026-04-01',1995,'seed-dummy');
INSERT INTO social_snapshots VALUES('linkedin','2026-04-02',2006,'seed-dummy');
INSERT INTO social_snapshots VALUES('linkedin','2026-04-03',2019,'seed-dummy');
INSERT INTO social_snapshots VALUES('linkedin','2026-04-04',2031,'seed-dummy');
INSERT INTO social_snapshots VALUES('linkedin','2026-04-05',2040,'seed-dummy');
INSERT INTO social_snapshots VALUES('linkedin','2026-04-06',2047,'seed-dummy');
INSERT INTO social_snapshots VALUES('linkedin','2026-04-07',2051,'seed-dummy');
INSERT INTO social_snapshots VALUES('linkedin','2026-04-08',2055,'seed-dummy');
INSERT INTO social_snapshots VALUES('linkedin','2026-04-09',2060,'seed-dummy');
INSERT INTO social_snapshots VALUES('linkedin','2026-04-10',2070,'seed-dummy');
INSERT INTO social_snapshots VALUES('linkedin','2026-04-11',2083,'seed-dummy');
INSERT INTO social_snapshots VALUES('linkedin','2026-04-12',2097,'seed-dummy');
INSERT INTO social_snapshots VALUES('linkedin','2026-04-13',2112,'seed-dummy');
INSERT INTO social_snapshots VALUES('linkedin','2026-04-14',2125,'seed-dummy');
INSERT INTO social_snapshots VALUES('linkedin','2026-04-15',2134,'seed-dummy');
INSERT INTO social_snapshots VALUES('linkedin','2026-04-16',2141,'seed-dummy');
INSERT INTO social_snapshots VALUES('linkedin','2026-04-17',2148,'seed-dummy');
INSERT INTO social_snapshots VALUES('linkedin','2026-04-18',2156,'seed-dummy');
INSERT INTO social_snapshots VALUES('linkedin','2026-04-19',2167,'seed-dummy');
INSERT INTO social_snapshots VALUES('linkedin','2026-04-20',2181,'seed-dummy');
INSERT INTO social_snapshots VALUES('linkedin','2026-04-21',2196,'seed-dummy');
INSERT INTO social_snapshots VALUES('linkedin','2026-04-22',2211,'seed-dummy');
INSERT INTO social_snapshots VALUES('linkedin','2026-04-23',2222,'seed-dummy');
INSERT INTO social_snapshots VALUES('linkedin','2026-04-24',2231,'seed-dummy');
INSERT INTO social_snapshots VALUES('linkedin','2026-04-25',2236,'seed-dummy');
INSERT INTO social_snapshots VALUES('linkedin','2026-04-26',2241,'seed-dummy');
INSERT INTO social_snapshots VALUES('linkedin','2026-04-27',2247,'seed-dummy');
INSERT INTO social_snapshots VALUES('linkedin','2026-04-28',2257,'seed-dummy');
INSERT INTO social_snapshots VALUES('linkedin','2026-04-29',2270,'seed-dummy');
INSERT INTO social_snapshots VALUES('linkedin','2026-04-30',2285,'seed-dummy');
INSERT INTO social_snapshots VALUES('linkedin','2026-05-01',2299,'seed-dummy');
INSERT INTO social_snapshots VALUES('linkedin','2026-05-02',2311,'seed-dummy');
INSERT INTO social_snapshots VALUES('linkedin','2026-05-03',2320,'seed-dummy');
INSERT INTO social_snapshots VALUES('linkedin','2026-05-04',2327,'seed-dummy');
INSERT INTO social_snapshots VALUES('linkedin','2026-05-05',2334,'seed-dummy');
INSERT INTO social_snapshots VALUES('linkedin','2026-05-06',2343,'seed-dummy');
INSERT INTO social_snapshots VALUES('linkedin','2026-05-07',2356,'seed-dummy');
INSERT INTO social_snapshots VALUES('linkedin','2026-05-08',2372,'seed-dummy');
INSERT INTO social_snapshots VALUES('linkedin','2026-05-09',2389,'seed-dummy');
INSERT INTO social_snapshots VALUES('linkedin','2026-05-10',2406,'seed-dummy');
INSERT INTO social_snapshots VALUES('linkedin','2026-05-11',2421,'seed-dummy');
INSERT INTO social_snapshots VALUES('linkedin','2026-05-12',2432,'seed-dummy');
INSERT INTO social_snapshots VALUES('linkedin','2026-05-13',2440,'seed-dummy');
INSERT INTO social_snapshots VALUES('linkedin','2026-05-14',2448,'seed-dummy');
INSERT INTO social_snapshots VALUES('linkedin','2026-05-15',2457,'seed-dummy');
INSERT INTO social_snapshots VALUES('linkedin','2026-05-16',2469,'seed-dummy');
INSERT INTO social_snapshots VALUES('linkedin','2026-05-17',2484,'seed-dummy');
INSERT INTO social_snapshots VALUES('linkedin','2026-05-18',2500,'seed-dummy');
INSERT INTO social_snapshots VALUES('linkedin','2026-05-19',2516,'seed-dummy');
INSERT INTO social_snapshots VALUES('linkedin','2026-05-20',2528,'seed-dummy');
INSERT INTO social_snapshots VALUES('linkedin','2026-05-21',2537,'seed-dummy');
INSERT INTO social_snapshots VALUES('linkedin','2026-05-22',2544,'seed-dummy');
INSERT INTO social_snapshots VALUES('linkedin','2026-05-23',2551,'seed-dummy');
INSERT INTO social_snapshots VALUES('linkedin','2026-05-24',2560,'seed-dummy');
INSERT INTO social_snapshots VALUES('linkedin','2026-05-25',2572,'seed-dummy');
INSERT INTO social_snapshots VALUES('linkedin','2026-05-26',2588,'seed-dummy');
INSERT INTO social_snapshots VALUES('linkedin','2026-05-27',2606,'seed-dummy');
INSERT INTO social_snapshots VALUES('linkedin','2026-05-28',2623,'seed-dummy');
INSERT INTO social_snapshots VALUES('linkedin','2026-05-29',2638,'seed-dummy');
INSERT INTO social_snapshots VALUES('linkedin','2026-05-30',2650,'seed-dummy');
INSERT INTO social_snapshots VALUES('linkedin','2026-05-31',2660,'seed-dummy');
INSERT INTO social_snapshots VALUES('linkedin','2026-06-01',2670,'seed-dummy');
INSERT INTO social_snapshots VALUES('linkedin','2026-06-02',2682,'seed-dummy');
INSERT INTO social_snapshots VALUES('linkedin','2026-06-03',2697,'seed-dummy');
INSERT INTO social_snapshots VALUES('linkedin','2026-06-04',2715,'seed-dummy');
INSERT INTO social_snapshots VALUES('linkedin','2026-06-05',2734,'seed-dummy');
INSERT INTO social_snapshots VALUES('linkedin','2026-06-06',2752,'seed-dummy');
INSERT INTO social_snapshots VALUES('linkedin','2026-06-07',2767,'seed-dummy');
INSERT INTO social_snapshots VALUES('linkedin','2026-06-08',2779,'seed-dummy');
INSERT INTO social_snapshots VALUES('linkedin','2026-06-09',2788,'seed-dummy');
INSERT INTO social_snapshots VALUES('linkedin','2026-06-10',2796,'seed-dummy');
INSERT INTO social_snapshots VALUES('linkedin','2026-06-11',2806,'seed-dummy');
INSERT INTO social_snapshots VALUES('linkedin','2026-06-12',2825,'seed-dummy');
CREATE TABLE broadcast_replies (
  id TEXT PRIMARY KEY,
  broadcast_id TEXT NOT NULL REFERENCES broadcasts(id),
  agent_id TEXT NOT NULL,
  ok INTEGER NOT NULL,
  reply TEXT NOT NULL DEFAULT '',
  finished_at TEXT NOT NULL
);
CREATE TABLE email_list_snapshots (
  captured_at TEXT PRIMARY KEY,
  subscribers INTEGER NOT NULL,
  source TEXT NOT NULL,
  publication_id TEXT NOT NULL DEFAULT '',
  metric TEXT NOT NULL DEFAULT '',
  quality TEXT NOT NULL DEFAULT 'ok'
);
INSERT INTO email_list_snapshots VALUES('2026-05-28',4812,'seed-beehiiv','','','ok');
INSERT INTO email_list_snapshots VALUES('2026-05-29',4812,'seed-beehiiv','','','ok');
INSERT INTO email_list_snapshots VALUES('2026-05-30',4812,'seed-beehiiv','','','ok');
INSERT INTO email_list_snapshots VALUES('2026-05-31',4812,'seed-beehiiv','','','ok');
INSERT INTO email_list_snapshots VALUES('2026-06-01',4812,'seed-beehiiv','','','ok');
INSERT INTO email_list_snapshots VALUES('2026-06-02',4812,'seed-beehiiv','','','ok');
INSERT INTO email_list_snapshots VALUES('2026-06-03',4812,'seed-beehiiv','','','ok');
INSERT INTO email_list_snapshots VALUES('2026-06-04',4812,'seed-beehiiv','','','ok');
INSERT INTO email_list_snapshots VALUES('2026-06-05',4812,'seed-beehiiv','','','ok');
INSERT INTO email_list_snapshots VALUES('2026-06-06',4812,'seed-beehiiv','','','ok');
INSERT INTO email_list_snapshots VALUES('2026-06-07',4812,'seed-beehiiv','','','ok');
INSERT INTO email_list_snapshots VALUES('2026-06-08',4812,'seed-beehiiv','','','ok');
INSERT INTO email_list_snapshots VALUES('2026-06-09',4812,'seed-beehiiv','','','ok');
INSERT INTO email_list_snapshots VALUES('2026-06-10',4812,'seed-beehiiv','','','ok');
INSERT INTO email_list_snapshots VALUES('2026-06-11',4812,'seed-beehiiv','','','ok');
INSERT INTO email_list_snapshots VALUES('2026-06-12',4813,'seed-beehiiv','','','ok');
CREATE TABLE email_list_sync_misses (
  attempted_at TEXT PRIMARY KEY,
  reason TEXT NOT NULL
);
CREATE TABLE metric_snapshots (
  metric_id TEXT NOT NULL,
  captured_at TEXT NOT NULL,
  value REAL NOT NULL,
  PRIMARY KEY (metric_id, captured_at)
);
CREATE TABLE social_dms (
  platform TEXT PRIMARY KEY,
  count INTEGER NOT NULL,
  updated_at TEXT NOT NULL
);
INSERT INTO social_dms VALUES('instagram',1240,'2026-06-12');
INSERT INTO social_dms VALUES('tiktok',386,'2026-06-12');
INSERT INTO social_dms VALUES('twitter',214,'2026-06-12');
INSERT INTO social_dms VALUES('youtube',58,'2026-06-12');
INSERT INTO social_dms VALUES('linkedin',92,'2026-06-12');
CREATE TABLE social_dm_snapshots (
  platform TEXT NOT NULL,
  captured_at TEXT NOT NULL,
  count INTEGER NOT NULL,
  source TEXT NOT NULL,
  PRIMARY KEY (platform, captured_at)
);
INSERT INTO social_dm_snapshots VALUES('instagram','2026-03-14',818,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('instagram','2026-03-15',824,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('instagram','2026-03-16',829,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('instagram','2026-03-17',833,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('instagram','2026-03-18',836,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('instagram','2026-03-19',838,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('instagram','2026-03-20',840,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('instagram','2026-03-21',843,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('instagram','2026-03-22',847,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('instagram','2026-03-23',852,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('instagram','2026-03-24',857,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('instagram','2026-03-25',862,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('instagram','2026-03-26',865,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('instagram','2026-03-27',867,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('instagram','2026-03-28',868,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('instagram','2026-03-29',870,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('instagram','2026-03-30',872,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('instagram','2026-03-31',876,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('instagram','2026-04-01',881,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('instagram','2026-04-02',887,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('instagram','2026-04-03',892,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('instagram','2026-04-04',897,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('instagram','2026-04-05',899,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('instagram','2026-04-06',902,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('instagram','2026-04-07',904,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('instagram','2026-04-08',908,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('instagram','2026-04-09',913,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('instagram','2026-04-10',920,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('instagram','2026-04-11',926,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('instagram','2026-04-12',932,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('instagram','2026-04-13',937,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('instagram','2026-04-14',940,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('instagram','2026-04-15',942,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('instagram','2026-04-16',944,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('instagram','2026-04-17',947,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('instagram','2026-04-18',952,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('instagram','2026-04-19',958,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('instagram','2026-04-20',964,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('instagram','2026-04-21',969,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('instagram','2026-04-22',973,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('instagram','2026-04-23',976,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('instagram','2026-04-24',978,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('instagram','2026-04-25',980,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('instagram','2026-04-26',984,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('instagram','2026-04-27',990,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('instagram','2026-04-28',996,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('instagram','2026-04-29',1003,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('instagram','2026-04-30',1010,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('instagram','2026-05-01',1015,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('instagram','2026-05-02',1019,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('instagram','2026-05-03',1022,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('instagram','2026-05-04',1026,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('instagram','2026-05-05',1031,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('instagram','2026-05-06',1036,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('instagram','2026-05-07',1043,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('instagram','2026-05-08',1050,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('instagram','2026-05-09',1056,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('instagram','2026-05-10',1061,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('instagram','2026-05-11',1064,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('instagram','2026-05-12',1067,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('instagram','2026-05-13',1070,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('instagram','2026-05-14',1074,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('instagram','2026-05-15',1079,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('instagram','2026-05-16',1086,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('instagram','2026-05-17',1093,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('instagram','2026-05-18',1099,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('instagram','2026-05-19',1104,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('instagram','2026-05-20',1108,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('instagram','2026-05-21',1112,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('instagram','2026-05-22',1116,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('instagram','2026-05-23',1121,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('instagram','2026-05-24',1128,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('instagram','2026-05-25',1136,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('instagram','2026-05-26',1144,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('instagram','2026-05-27',1151,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('instagram','2026-05-28',1157,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('instagram','2026-05-29',1161,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('instagram','2026-05-30',1165,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('instagram','2026-05-31',1169,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('instagram','2026-06-01',1174,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('instagram','2026-06-02',1180,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('instagram','2026-06-03',1188,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('instagram','2026-06-04',1195,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('instagram','2026-06-05',1201,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('instagram','2026-06-06',1207,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('instagram','2026-06-07',1211,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('instagram','2026-06-08',1214,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('instagram','2026-06-09',1218,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('instagram','2026-06-10',1223,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('instagram','2026-06-11',1230,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('instagram','2026-06-12',1240,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('tiktok','2026-03-14',212,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('tiktok','2026-03-15',213,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('tiktok','2026-03-16',215,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('tiktok','2026-03-17',215,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('tiktok','2026-03-18',216,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('tiktok','2026-03-19',216,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('tiktok','2026-03-20',217,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('tiktok','2026-03-21',219,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('tiktok','2026-03-22',221,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('tiktok','2026-03-23',223,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('tiktok','2026-03-24',225,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('tiktok','2026-03-25',226,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('tiktok','2026-03-26',227,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('tiktok','2026-03-27',228,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('tiktok','2026-03-28',229,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('tiktok','2026-03-29',230,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('tiktok','2026-03-30',232,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('tiktok','2026-03-31',235,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('tiktok','2026-04-01',238,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('tiktok','2026-04-02',240,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('tiktok','2026-04-03',242,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('tiktok','2026-04-04',243,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('tiktok','2026-04-05',244,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('tiktok','2026-04-06',245,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('tiktok','2026-04-07',246,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('tiktok','2026-04-08',248,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('tiktok','2026-04-09',251,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('tiktok','2026-04-10',253,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('tiktok','2026-04-11',255,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('tiktok','2026-04-12',256,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('tiktok','2026-04-13',257,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('tiktok','2026-04-14',258,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('tiktok','2026-04-15',259,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('tiktok','2026-04-16',260,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('tiktok','2026-04-17',263,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('tiktok','2026-04-18',265,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('tiktok','2026-04-19',268,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('tiktok','2026-04-20',270,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('tiktok','2026-04-21',272,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('tiktok','2026-04-22',273,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('tiktok','2026-04-23',274,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('tiktok','2026-04-24',276,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('tiktok','2026-04-25',278,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('tiktok','2026-04-26',281,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('tiktok','2026-04-27',284,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('tiktok','2026-04-28',286,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('tiktok','2026-04-29',289,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('tiktok','2026-04-30',291,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('tiktok','2026-05-01',292,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('tiktok','2026-05-02',293,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('tiktok','2026-05-03',294,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('tiktok','2026-05-04',296,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('tiktok','2026-05-05',298,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('tiktok','2026-05-06',301,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('tiktok','2026-05-07',304,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('tiktok','2026-05-08',306,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('tiktok','2026-05-09',307,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('tiktok','2026-05-10',309,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('tiktok','2026-05-11',310,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('tiktok','2026-05-12',311,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('tiktok','2026-05-13',314,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('tiktok','2026-05-14',316,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('tiktok','2026-05-15',320,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('tiktok','2026-05-16',323,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('tiktok','2026-05-17',325,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('tiktok','2026-05-18',328,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('tiktok','2026-05-19',329,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('tiktok','2026-05-20',331,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('tiktok','2026-05-21',333,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('tiktok','2026-05-22',335,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('tiktok','2026-05-23',338,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('tiktok','2026-05-24',341,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('tiktok','2026-05-25',344,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('tiktok','2026-05-26',347,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('tiktok','2026-05-27',348,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('tiktok','2026-05-28',350,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('tiktok','2026-05-29',351,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('tiktok','2026-05-30',353,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('tiktok','2026-05-31',355,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('tiktok','2026-06-01',358,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('tiktok','2026-06-02',361,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('tiktok','2026-06-03',364,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('tiktok','2026-06-04',367,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('tiktok','2026-06-05',369,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('tiktok','2026-06-06',370,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('tiktok','2026-06-07',372,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('tiktok','2026-06-08',374,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('tiktok','2026-06-09',377,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('tiktok','2026-06-10',380,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('tiktok','2026-06-11',384,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('tiktok','2026-06-12',386,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('twitter','2026-03-14',121,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('twitter','2026-03-15',121,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('twitter','2026-03-16',121,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('twitter','2026-03-17',121,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('twitter','2026-03-18',122,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('twitter','2026-03-19',123,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('twitter','2026-03-20',124,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('twitter','2026-03-21',125,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('twitter','2026-03-22',126,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('twitter','2026-03-23',127,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('twitter','2026-03-24',128,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('twitter','2026-03-25',129,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('twitter','2026-03-26',129,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('twitter','2026-03-27',130,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('twitter','2026-03-28',131,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('twitter','2026-03-29',132,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('twitter','2026-03-30',133,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('twitter','2026-03-31',134,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('twitter','2026-04-01',135,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('twitter','2026-04-02',136,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('twitter','2026-04-03',136,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('twitter','2026-04-04',137,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('twitter','2026-04-05',137,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('twitter','2026-04-06',138,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('twitter','2026-04-07',139,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('twitter','2026-04-08',140,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('twitter','2026-04-09',142,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('twitter','2026-04-10',143,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('twitter','2026-04-11',143,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('twitter','2026-04-12',144,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('twitter','2026-04-13',144,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('twitter','2026-04-14',145,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('twitter','2026-04-15',146,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('twitter','2026-04-16',148,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('twitter','2026-04-17',149,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('twitter','2026-04-18',151,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('twitter','2026-04-19',152,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('twitter','2026-04-20',153,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('twitter','2026-04-21',153,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('twitter','2026-04-22',154,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('twitter','2026-04-23',155,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('twitter','2026-04-24',156,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('twitter','2026-04-25',157,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('twitter','2026-04-26',158,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('twitter','2026-04-27',160,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('twitter','2026-04-28',161,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('twitter','2026-04-29',161,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('twitter','2026-04-30',162,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('twitter','2026-05-01',162,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('twitter','2026-05-02',163,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('twitter','2026-05-03',164,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('twitter','2026-05-04',166,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('twitter','2026-05-05',167,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('twitter','2026-05-06',169,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('twitter','2026-05-07',170,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('twitter','2026-05-08',171,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('twitter','2026-05-09',172,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('twitter','2026-05-10',173,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('twitter','2026-05-11',174,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('twitter','2026-05-12',175,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('twitter','2026-05-13',177,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('twitter','2026-05-14',178,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('twitter','2026-05-15',180,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('twitter','2026-05-16',181,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('twitter','2026-05-17',182,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('twitter','2026-05-18',183,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('twitter','2026-05-19',183,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('twitter','2026-05-20',184,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('twitter','2026-05-21',185,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('twitter','2026-05-22',187,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('twitter','2026-05-23',188,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('twitter','2026-05-24',190,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('twitter','2026-05-25',191,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('twitter','2026-05-26',192,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('twitter','2026-05-27',193,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('twitter','2026-05-28',193,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('twitter','2026-05-29',195,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('twitter','2026-05-30',196,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('twitter','2026-05-31',198,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('twitter','2026-06-01',200,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('twitter','2026-06-02',201,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('twitter','2026-06-03',203,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('twitter','2026-06-04',204,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('twitter','2026-06-05',205,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('twitter','2026-06-06',206,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('twitter','2026-06-07',207,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('twitter','2026-06-08',209,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('twitter','2026-06-09',210,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('twitter','2026-06-10',212,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('twitter','2026-06-11',214,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('twitter','2026-06-12',214,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('youtube','2026-03-14',26,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('youtube','2026-03-15',26,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('youtube','2026-03-16',26,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('youtube','2026-03-17',27,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('youtube','2026-03-18',27,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('youtube','2026-03-19',27,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('youtube','2026-03-20',28,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('youtube','2026-03-21',28,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('youtube','2026-03-22',28,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('youtube','2026-03-23',29,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('youtube','2026-03-24',29,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('youtube','2026-03-25',29,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('youtube','2026-03-26',29,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('youtube','2026-03-27',29,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('youtube','2026-03-28',30,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('youtube','2026-03-29',30,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('youtube','2026-03-30',30,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('youtube','2026-03-31',31,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('youtube','2026-04-01',31,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('youtube','2026-04-02',31,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('youtube','2026-04-03',31,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('youtube','2026-04-04',31,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('youtube','2026-04-05',32,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('youtube','2026-04-06',32,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('youtube','2026-04-07',33,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('youtube','2026-04-08',33,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('youtube','2026-04-09',33,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('youtube','2026-04-10',34,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('youtube','2026-04-11',34,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('youtube','2026-04-12',34,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('youtube','2026-04-13',34,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('youtube','2026-04-14',35,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('youtube','2026-04-15',35,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('youtube','2026-04-16',36,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('youtube','2026-04-17',36,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('youtube','2026-04-18',36,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('youtube','2026-04-19',37,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('youtube','2026-04-20',37,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('youtube','2026-04-21',37,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('youtube','2026-04-22',37,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('youtube','2026-04-23',38,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('youtube','2026-04-24',38,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('youtube','2026-04-25',39,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('youtube','2026-04-26',39,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('youtube','2026-04-27',39,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('youtube','2026-04-28',40,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('youtube','2026-04-29',40,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('youtube','2026-04-30',40,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('youtube','2026-05-01',40,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('youtube','2026-05-02',41,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('youtube','2026-05-03',41,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('youtube','2026-05-04',42,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('youtube','2026-05-05',42,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('youtube','2026-05-06',43,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('youtube','2026-05-07',43,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('youtube','2026-05-08',43,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('youtube','2026-05-09',44,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('youtube','2026-05-10',44,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('youtube','2026-05-11',44,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('youtube','2026-05-12',45,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('youtube','2026-05-13',45,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('youtube','2026-05-14',46,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('youtube','2026-05-15',46,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('youtube','2026-05-16',46,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('youtube','2026-05-17',47,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('youtube','2026-05-18',47,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('youtube','2026-05-19',47,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('youtube','2026-05-20',48,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('youtube','2026-05-21',48,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('youtube','2026-05-22',49,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('youtube','2026-05-23',49,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('youtube','2026-05-24',50,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('youtube','2026-05-25',50,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('youtube','2026-05-26',50,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('youtube','2026-05-27',51,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('youtube','2026-05-28',51,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('youtube','2026-05-29',52,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('youtube','2026-05-30',52,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('youtube','2026-05-31',53,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('youtube','2026-06-01',53,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('youtube','2026-06-02',54,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('youtube','2026-06-03',54,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('youtube','2026-06-04',54,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('youtube','2026-06-05',55,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('youtube','2026-06-06',55,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('youtube','2026-06-07',56,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('youtube','2026-06-08',56,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('youtube','2026-06-09',57,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('youtube','2026-06-10',57,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('youtube','2026-06-11',58,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('youtube','2026-06-12',58,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('linkedin','2026-03-14',44,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('linkedin','2026-03-15',44,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('linkedin','2026-03-16',45,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('linkedin','2026-03-17',45,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('linkedin','2026-03-18',46,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('linkedin','2026-03-19',46,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('linkedin','2026-03-20',47,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('linkedin','2026-03-21',47,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('linkedin','2026-03-22',47,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('linkedin','2026-03-23',47,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('linkedin','2026-03-24',47,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('linkedin','2026-03-25',48,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('linkedin','2026-03-26',48,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('linkedin','2026-03-27',49,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('linkedin','2026-03-28',50,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('linkedin','2026-03-29',50,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('linkedin','2026-03-30',51,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('linkedin','2026-03-31',51,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('linkedin','2026-04-01',51,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('linkedin','2026-04-02',51,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('linkedin','2026-04-03',52,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('linkedin','2026-04-04',53,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('linkedin','2026-04-05',53,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('linkedin','2026-04-06',54,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('linkedin','2026-04-07',55,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('linkedin','2026-04-08',55,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('linkedin','2026-04-09',55,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('linkedin','2026-04-10',55,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('linkedin','2026-04-11',56,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('linkedin','2026-04-12',56,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('linkedin','2026-04-13',57,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('linkedin','2026-04-14',57,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('linkedin','2026-04-15',58,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('linkedin','2026-04-16',58,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('linkedin','2026-04-17',59,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('linkedin','2026-04-18',59,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('linkedin','2026-04-19',59,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('linkedin','2026-04-20',60,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('linkedin','2026-04-21',60,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('linkedin','2026-04-22',61,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('linkedin','2026-04-23',62,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('linkedin','2026-04-24',63,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('linkedin','2026-04-25',63,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('linkedin','2026-04-26',64,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('linkedin','2026-04-27',64,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('linkedin','2026-04-28',64,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('linkedin','2026-04-29',65,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('linkedin','2026-04-30',65,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('linkedin','2026-05-01',66,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('linkedin','2026-05-02',67,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('linkedin','2026-05-03',68,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('linkedin','2026-05-04',68,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('linkedin','2026-05-05',69,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('linkedin','2026-05-06',69,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('linkedin','2026-05-07',69,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('linkedin','2026-05-08',69,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('linkedin','2026-05-09',70,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('linkedin','2026-05-10',71,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('linkedin','2026-05-11',72,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('linkedin','2026-05-12',72,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('linkedin','2026-05-13',73,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('linkedin','2026-05-14',73,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('linkedin','2026-05-15',74,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('linkedin','2026-05-16',74,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('linkedin','2026-05-17',75,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('linkedin','2026-05-18',75,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('linkedin','2026-05-19',76,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('linkedin','2026-05-20',77,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('linkedin','2026-05-21',78,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('linkedin','2026-05-22',79,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('linkedin','2026-05-23',79,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('linkedin','2026-05-24',80,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('linkedin','2026-05-25',80,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('linkedin','2026-05-26',81,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('linkedin','2026-05-27',81,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('linkedin','2026-05-28',82,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('linkedin','2026-05-29',83,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('linkedin','2026-05-30',84,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('linkedin','2026-05-31',84,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('linkedin','2026-06-01',85,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('linkedin','2026-06-02',85,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('linkedin','2026-06-03',85,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('linkedin','2026-06-04',86,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('linkedin','2026-06-05',87,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('linkedin','2026-06-06',88,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('linkedin','2026-06-07',89,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('linkedin','2026-06-08',89,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('linkedin','2026-06-09',90,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('linkedin','2026-06-10',91,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('linkedin','2026-06-11',91,'seed-dummy');
INSERT INTO social_dm_snapshots VALUES('linkedin','2026-06-12',92,'seed-dummy');
CREATE TABLE social_dm_messages (
  id TEXT PRIMARY KEY,
  platform TEXT NOT NULL,
  subscriber_id TEXT NOT NULL,
  name TEXT NOT NULL,
  handle TEXT,
  text TEXT NOT NULL,
  direction TEXT NOT NULL,
  tag TEXT,
  ts TEXT NOT NULL,
  source TEXT NOT NULL
);
INSERT INTO social_dm_messages VALUES('dm-ig-alex-0','instagram','ig-alex','Alex Rivera','alex.rivera','saw your reel on the 3-agent setup 🔥 do you actually work with agencies?','in',NULL,'2026-07-18T14:02:00.000Z','seed-dummy');
INSERT INTO social_dm_messages VALUES('dm-ig-alex-1','instagram','ig-alex','Alex Rivera','alex.rivera','appreciate it! yeah — agencies are exactly who Vantage is built for. what are you running right now?','out',NULL,'2026-07-18T14:09:00.000Z','seed-dummy');
INSERT INTO social_dm_messages VALUES('dm-ig-alex-2','instagram','ig-alex','Alex Rivera','alex.rivera','SMMA, ~12 clients, drowning in fulfillment tbh 😅','in',NULL,'2026-07-18T14:15:00.000Z','seed-dummy');
INSERT INTO social_dm_messages VALUES('dm-ig-jordan-3','instagram','ig-jordan','Jordan Blake','jordanbuilds','SCALE','in','SCALE','2026-07-18T12:41:00.000Z','seed-dummy');
INSERT INTO social_dm_messages VALUES('dm-ig-jordan-4','instagram','ig-jordan','Jordan Blake','jordanbuilds','boom 💥 here’s the free breakdown → thefounderos.com/scale. want me to show how it maps to your funnel?','out','SCALE','2026-07-18T12:41:20.000Z','seed-dummy');
INSERT INTO social_dm_messages VALUES('dm-ig-jordan-5','instagram','ig-jordan','Jordan Blake','jordanbuilds','yes pls','in',NULL,'2026-07-18T13:05:00.000Z','seed-dummy');
INSERT INTO social_dm_messages VALUES('dm-ig-priya-6','instagram','ig-priya','Priya N','priya.builds','replied to your story — I want OUT of retainer hell 😩','in',NULL,'2026-07-17T21:12:00.000Z','seed-dummy');
INSERT INTO social_dm_messages VALUES('dm-ig-priya-7','instagram','ig-priya','Priya N','priya.builds','lol felt. that’s the whole thesis. what’s your current model — retainers or projects?','out',NULL,'2026-07-17T21:30:00.000Z','seed-dummy');
INSERT INTO social_dm_messages VALUES('dm-ig-sam-8','instagram','ig-sam','Sam Ortiz','sam.ortiz.co','what does pricing look like for the done-for-you build?','in',NULL,'2026-07-18T15:48:00.000Z','seed-dummy');
CREATE TABLE social_posts (
  id TEXT PRIMARY KEY,
  caption TEXT NOT NULL,
  media_url TEXT,
  platforms TEXT NOT NULL,
  status TEXT NOT NULL,
  scheduled_for TEXT,
  created_at TEXT NOT NULL
);
INSERT INTO social_posts VALUES('post-seed-1','New Vantage case study — 3x pipeline in 60 days. Full breakdown dropping this week 🚀',NULL,'["instagram","tiktok","twitter"]','queued',NULL,'2026-06-12T18:00:00Z');
CREATE TABLE people (
  id TEXT PRIMARY KEY,
  department_id TEXT NOT NULL REFERENCES departments(id),
  name TEXT NOT NULL,
  role TEXT NOT NULL,
  tools TEXT NOT NULL DEFAULT '[]'
);
INSERT INTO people VALUES('person-drew','dept-sales','Drew Palmer','Closer','["fathom","typeform"]');
INSERT INTO people VALUES('person-nico','dept-sales','Nico','Setter','["typeform","manychat"]');
INSERT INTO people VALUES('person-maya','dept-sales','Maya','Setter','["typeform","manychat"]');
INSERT INTO people VALUES('person-sasha','dept-marketing-growth','Sasha','Head of Growth & Marketing','["zernio","manychat"]');
INSERT INTO people VALUES('person-jordan','dept-clients','Jordan Lee','Client Operations','["stripe","slack"]');
INSERT INTO people VALUES('person-rae','dept-clients','Rae Winters','Account Manager','["stripe","fathom"]');
CREATE TABLE sop_tasks (
  id TEXT PRIMARY KEY,
  department_id TEXT NOT NULL REFERENCES departments(id),
  title TEXT NOT NULL,
  summary TEXT NOT NULL DEFAULT '',
  steps TEXT NOT NULL DEFAULT '[]',
  assignee_kind TEXT NOT NULL,
  assignee_id TEXT NOT NULL
);
INSERT INTO sop_tasks VALUES('sop-conductor','dept-tech','Broadcast directives across the fleet','One message in, every agent briefed, replies collected.','["Receive the directive from the operator console","Resolve the target list: the whole fleet, or the pillar the directive names","Poll instance hosts (OpenClaw, Ollama, tmux) for availability before dispatch","Fan the message out to every target at once and stamp each send","Collect replies as they land and file the run to agent_runs","Report non-responders after sixty seconds so nothing fails silently"]','agent','conductor');
INSERT INTO sop_tasks VALUES('sop-data-agent','dept-tech','Answer questions from G-Brain','Hybrid search over the second brain, honest fallbacks.','["Parse the incoming question into a gbrain query","Run gbrain hybrid search (--no-expand) against Supabase","Fall back to local brain-store grep when the database is paused","Rank passages and keep only the ones that actually answer the question","Return cited passages with their source notes, never invented ones","Log unanswerable questions as gaps for the Markdown Auditor to fill"]','agent','data-agent');
INSERT INTO sop_tasks VALUES('sop-markdown-auditor','dept-tech','Audit brain-store markdown health','Keep the knowledge base clean and linkable.','["Walk every markdown file in clue-agent/brain-store","Flag broken wiki-links, orphan notes and stale frontmatter","Check generated org docs still match the live agents, SOPs and tools","Write the health report with per-folder scores","Queue fix-ups for the worst offenders and track them to done"]','agent','markdown-auditor');
INSERT INTO sop_tasks VALUES('sop-vector-auditor','dept-tech','Audit the vector index','Embeddings in Supabase must mirror brain-store.','["Ping the Supabase Second Brain project (free tier pauses on idle)","Wake the database and wait until it accepts queries before comparing","Compare pgvector chunk counts against brain-store files","Flag drift and paused-tier warnings on the /brain doctor card","Trigger bge-m3 re-embeds for drifted documents and verify counts after"]','agent','vector-auditor');
INSERT INTO sop_tasks VALUES('sop-stack-monitor','dept-tech','Watch the local stack','Honest status for every port, session and binary.','["Probe Paperclip :3100 and the Hermes gateway :8642","Check the brew binaries the agents shell out to (ffmpeg, pdftotext, whisper, gh) and the gbrain CLI","Record honest ConnectorStatus, never fake connected","Compare against the last sweep to catch flapping services","Alert the console when something that was up goes down"]','agent','stack-monitor');
INSERT INTO sop_tasks VALUES('sop-comms-digest','dept-comms','Run the 09:00 comms report','Every morning: 24h of email, WhatsApp and Slack, ranked by who needs a reply.','["Pull the trailing 24 hours from all four inboxes, WhatsApp and Slack (one guarded call each — a dead channel degrades the report, it never cancels it)","Load the ranking context: calendar titles for who he has calls with, the paying-customer roster (Stripe) for clients, contact tags for students and family","Rank every message: calls first, then clients and proposal replies, then students, family and cohort questions, then brand deals, then group chats, companies and software last","Collect the automated senders into an unsubscribe worklist, noisiest first","Store the report so /comms renders it instantly, and log the run against the schedule"]','agent','comms-digest');
INSERT INTO sop_tasks VALUES('sop-comms-agent','dept-comms','Compose the unified comms feed','Three channels, one timeline at /comms.','["Collect fresh output from the Gmail, WhatsApp and Slack workers","Dedupe and merge everything into one ordered timeline","Tag each entry with its contact tier","Bubble urgent and reply-needed items to the top of the feed","Publish the feed and report which channels are live"]','agent','comms-agent');
INSERT INTO sop_tasks VALUES('sop-gmail-worker','dept-comms','Triage the four Gmail inboxes','IMAP slots 1–4 read, classified, escalated.','["Connect the four configured IMAP inboxes on the sync cadence","Pull unread counts and every thread newer than the last sweep","Classify each thread: urgent, reply-needed, waiting-on-us, FYI","Draft suggested replies for reply-needed threads in Alex voice","Hand urgent threads to the escalation queue with a one-line summary","Surface anything from a client domain to the Clients pillar too"]','agent','gmail-worker');
INSERT INTO sop_tasks VALUES('sop-whatsapp-worker','dept-comms','Monitor WhatsApp chats','600+ chats read locally, LC + Vantage teams surfaced.','["Read the local ChatStorage.sqlite (read-only, nothing leaves the machine)","Surface new messages from the LC and Vantage team chats","Map senders to their contact tags","Flag messages that mention money, deadlines or blockers","Push tagged messages into the unified feed"]','agent','whatsapp-worker');
INSERT INTO sop_tasks VALUES('sop-slack-worker','dept-comms','Digest Slack channels','Joined channels summarized into the feed.','["List channels the bot has joined","Pull the latest messages per channel since the last sweep","Summarize each channel into a short digest","Call out direct mentions and unanswered questions separately","Push the digest into the unified feed"]','agent','slack-worker');
INSERT INTO sop_tasks VALUES('sop-social-agent','dept-marketing-growth','Run the daily content pipeline','Calendar → briefs → assets → publish queue.','["Pull today’s slots from the content calendar","Brief the creative workers (Arcads, Higgsfield, Remotion) with hooks and formats","Collect finished assets and check them against the brief","Reject anything off-brand with a one-line reason so the fix is fast","Queue approved posts for the Zernio publisher with per-platform captions","Log what shipped to the calendar so tomorrow’s brief starts warm"]','agent','social-agent');
INSERT INTO sop_tasks VALUES('sop-newsletter-agent','dept-marketing-growth','Draft the next newsletter issue','Aim the draft at what the list actually opened and clicked.','["Pull the Beehiiv send history and build the performance brief","Say plainly when the history is too thin to call a pattern","Write three subject lines and the issue against the skill file","Avoid repeating the angle of any recent issue in the brief","Hand the draft over unsent, and never state a metric that was not measured"]','agent','newsletter-agent');
INSERT INTO sop_tasks VALUES('sop-postly-publisher','dept-marketing-growth','Publish to six platforms','One queue out to every @founderos.ai surface.','["Take the next queued post from the pipeline","Adapt the caption per platform (IG, TikTok, X, YouTube, LinkedIn, Facebook)","Publish through the Zernio API","Record post ids and verify each went live","Retry failed platforms once, then flag them to the Social Agent"]','agent','postly-publisher');
INSERT INTO sop_tasks VALUES('sop-adsmith-creative','dept-marketing-growth','Generate UGC ad variants','Vantage ad angles rendered as UGC actors.','["Take the ad brief with hook, angle and offer","Generate actor variants across Veo / Sora / Kling","Cull the takes that break the brief before rendering finals","Render finals and name them by angle","Deliver the batch to creative review with a variant sheet"]','agent','adsmith-creative');
INSERT INTO sop_tasks VALUES('sop-reelkit-editor','dept-marketing-growth','Cut short-form edits','Raw footage to platform-ready crops.','["Transcribe the source clip locally with Whisper","Pick the hook and strongest segments from the transcript","Render through the Remotion pipeline with the right theme (LC / Vantage)","Check captions land on beat before exporting anything","Export platform crops and hand them to the pipeline"]','agent','reelkit-editor');
INSERT INTO sop_tasks VALUES('sop-renderly-creative','dept-marketing-growth','Produce AI visuals','Stills and motion from the creative brief.','["Read the creative brief and pick the matching Higgsfield model","Generate stills or motion to the spec in the brief","Cull to the strongest takes before spending on upscales","Upscale the picks to delivery resolution","Hand finals to the editor for assembly with the brief attached"]','agent','renderly-creative');
INSERT INTO sop_tasks VALUES('sop-dmflow-mcp','dept-marketing-growth','Automate DM funnels','Keyword triggers to booked conversations.','["Watch configured trigger keywords across platforms","Fire the matching ManyChat flow for each trigger","Tag subscribers by intent as they move through the flow","Hand hot leads to the Sales pillar with their conversation history","Report conversions back to the growth dashboard"]','agent','dmflow-mcp');
INSERT INTO sop_tasks VALUES('sop-syed','dept-marketing-growth','Set content strategy & approve drops','The human editorial gate on everything published.','["Review last cycle’s performance numbers from the dashboard","Set this week’s angles and slot them on the calendar","Approve or kill every queued asset before it publishes","Spot-check published posts landed exactly as approved","Debrief the crew on what worked and what died"]','person','person-syed');
INSERT INTO sop_tasks VALUES('sop-sales-agent','dept-sales','Keep the pipeline moving','Deals inspected daily, nothing stalls silently.','["Pull every new Typeform lead, booked call and Fathom call from the funnel each morning","Rank leads by stage and days since the last touch; anything past 7 days is stalled","Attach a concrete next action and owner to every stalled lead","Prepare payment links across PayKit, Stripe and FlexPay before calls","Brief Dylan with the top five leads and their objections before each call","Note each lead’s next step the same day it changes"]','agent','sales-agent');
INSERT INTO sop_tasks VALUES('sop-aa-lane','dept-sales','Run the Launchpad Cohort lane','Webinar registrants to closed LC deals.','["Track LC leads from webinar registration to booked call","Chase no-shows with the rebooking sequence within 24 hours","Log every booked and held call against the lead in the funnel","Reconcile LC payments against Stripe","Report lane revenue to the pipeline brief"]','agent','launchpad-cohort-sales');
INSERT INTO sop_tasks VALUES('sop-vantage-lane','dept-sales','Run the Vantage lane','Local-business inbound worked end to end.','["Qualify inbound Vantage leads against the ICP","Book qualified leads onto Dylan’s calendar with context attached","Log booked and held calls against the lead in the funnel","Reconcile payments across PayKit and Stripe","Report lane revenue to the pipeline brief"]','agent','vantage-sales');
INSERT INTO sop_tasks VALUES('sop-vantage-paykit','dept-sales','Reconcile the Vantage PayKit lane','PayKit customers matched to funnel leads.','["Pull month-to-date customers from PayKit","Match each payment to its funnel lead by email","Flag payments with no lead and closed leads with no payment","Chase every mismatch to a resolution, not just a flag","Post month-to-date totals to Finances"]','agent','vantage-paykit');
INSERT INTO sop_tasks VALUES('sop-sales-calls-data','dept-sales','Mine sales-call recordings','Every Fathom call and Plaud recording becomes sales intelligence.','["Ingest Fathom notes after each recorded call","Ingest Plaud transcripts + AI notes after each in-person meeting or site walk","Extract objections, commitments and next steps","File the extract into G-Brain against the lead","Tag calls where pricing or competitors came up","Feed recurring patterns into the pipeline brief"]','agent','sales-calls-data');
INSERT INTO sop_tasks VALUES('sop-crm-pulse','dept-sales','Keep the lead lane honest','Leads, booked calls and held calls the numbers can be trusted from.','["Check Typeform, the calendar and Fathom each answer","Flag leads with no email, which cannot be matched to a call or a payment","Flag booked calls that never show up as a held Fathom call","Nudge lane owners on leads gone stale","Snapshot lead and call counts for the dashboard"]','agent','crm-pulse');
INSERT INTO sop_tasks VALUES('sop-brand-deal-agent','dept-sales','Work the brand deal pipeline as Victor','Qualify, quote, chase and bump, without ever sending.','["Read the OS brand deal store and rank what needs answering today","Check the contact governor before touching any thread, and respect a refusal","Draft the reply, counter or bump as Victor, speaking about Alex in third person","Escalate anything below floor, equity shaped, or asking for a call","Leave every draft for Alex to send, and never claim one went out"]','agent','brand-deal-agent');
INSERT INTO sop_tasks VALUES('sop-dilan','dept-sales','Run discovery & close calls','The human on the phone from hello to signed.','["Review the pre-call brief and the lead’s last three touches","Run the discovery script and qualify hard on budget and timeline","Handle objections with the objection sheet, never improvise pricing","Present the matching offer and the financing option when it fits","Log the outcome, next step and payment link before the next call"]','person','person-dilan');
INSERT INTO sop_tasks VALUES('sop-nikola','dept-sales','Set qualified calls','The front of the pipeline: qualify, book, confirm.','["Work the new inbound DMs and form fills before anything older","Qualify on budget, timeline and decision power before offering a slot","Book the call straight onto Dylan’s calendar with the context attached","Confirm the booking same day and send the reminder the night before","Log every no-show and reschedule so nothing quietly falls out of the pipeline"]','person','person-nikola');
INSERT INTO sop_tasks VALUES('sop-mateja','dept-sales','Set qualified calls','The front of the pipeline: qualify, book, confirm.','["Work the new inbound DMs and form fills before anything older","Qualify on budget, timeline and decision power before offering a slot","Book the call straight onto Dylan’s calendar with the context attached","Confirm the booking same day and send the reminder the night before","Log every no-show and reschedule so nothing quietly falls out of the pipeline"]','person','person-mateja');
INSERT INTO sop_tasks VALUES('sop-paykit','dept-finance','Track PayKit income','Month-to-date, split by venture, refunds flagged.','["Pull month-to-date customers from the PayKit API","Split income by venture (LC vs Vantage)","Record the income snapshot for the Finances view","Flag refunds and disputes the day they land","Reconcile the running total against the month-end books"]','agent','paykit-sales');
INSERT INTO sop_tasks VALUES('sop-stripe','dept-finance','Track Stripe income','Balance and charges labeled Launchpad Cohort.','["Pull balance and recent charges from Stripe","Label income to Launchpad Cohort","Record the snapshot for the income chart","Flag anomalies against the trailing average","Note upcoming payouts so cash flow is never a surprise"]','agent','stripe-sales');
INSERT INTO sop_tasks VALUES('sop-processor-confirm','dept-finance','Confirm payments across processors','No deal marked paid without an API receipt.','["Receive the payment claim from a sales lane","Check the claimed processor’s API (Stripe / PayPal / Square / Whop / PayKit)","Confirm the charge or flag the mismatch loudly","Write the confirmation onto the deal record","Keep an audit trail of every confirmation for month-end close"]','agent','processor-confirmation');
INSERT INTO sop_tasks VALUES('sop-flexpay','dept-finance','Quote financing options','Payment plans attached to live offers.','["Take the deal size and buyer profile from the lane","Pull matching plan options from FlexPay","Attach terms to the offer before the call","Track which plans get accepted and which stall deals","Report acceptance rates so pricing keeps getting sharper"]','agent','flexpay-financing');
INSERT INTO sop_tasks VALUES('sop-payments-pulse','dept-finance','Watch processor health','Every processor pinged, status recorded honestly.','["Ping each processor registered in the registry","Record honest ConnectorStatus, never fake connected","Alert Finances when a processor goes down","Re-check failed processors on a tighter cadence until they recover","Keep the uptime history for the analytics view"]','agent','payments-pulse');
INSERT INTO sop_tasks VALUES('sop-client-roster','dept-clients','Keep the client roster live','One list of every client, always current.','["Pull paying customers from Stripe and PayKit every morning","Reconcile them against the funnel journeys and payment records","Mark each account active, at risk, or churned with a reason","Flag stale records and missing fields to the owning lane","Publish the roster to the Clients pillar and note the deltas"]','agent','client-roster');
INSERT INTO sop_tasks VALUES('sop-client-onboarding','dept-clients','Onboard new clients','Closed-won to kickoff without a dropped step.','["Trigger when a new client’s first payment settles","Verify payment landed with Processor Confirm before anything ships","Send the welcome pack and countersigned agreement within 24 hours","Create their Slack channel, invite the client team, pin the scope doc","Book the kickoff call inside 5 business days and confirm attendance","Collect access and assets (logins, brand kit, tracking) in one request","Hand to Client Success with full context notes and the risk flags"]','agent','client-onboarding');
INSERT INTO sop_tasks VALUES('sop-client-success','dept-clients','Service active clients','Cadence, deliverables and renewals on rails.','["Run the weekly check-in cadence per client, no skipped weeks","Track deliverables against the sold scope and flag slippage early","Log Fathom call notes back to the client record the same day","Score account health monthly: green, watch, or at risk with a reason","Raise renewals and upsell openings 30 days out to Rae and Sales"]','agent','client-success');
INSERT INTO sop_tasks VALUES('sop-garrett','dept-clients','Keep client delivery moving','The human chasing the work between the calls.','["Walk every active account each morning and flag anything stalled","Chase the assets and approvals clients still owe us to unblock delivery","Keep the client Slack channels answered inside the working day","Prep the agenda and last month’s numbers before each client call","Escalate anything at risk to Alex before the client has to ask"]','person','person-garrett');
INSERT INTO sop_tasks VALUES('sop-rae','dept-clients','Own the client relationships','The human accountable for every account.','["Run kickoff and quarterly business review calls","Resolve escalations the same day they land","Approve scope changes before work starts","Review account health scores with Client Success monthly","Sign off renewals and hand pricing changes to Sales"]','person','person-rae');
CREATE TABLE lead_magnets (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  offer TEXT NOT NULL DEFAULT '',
  url TEXT NOT NULL,
  status TEXT NOT NULL,
  captures TEXT NOT NULL,
  destination TEXT NOT NULL DEFAULT '',
  source TEXT NOT NULL DEFAULT '',
  launched_at TEXT NOT NULL,
  notes TEXT NOT NULL DEFAULT '',
  origin TEXT NOT NULL DEFAULT 'seed'
);
INSERT INTO lead_magnets VALUES('agent-stack','The Agent Stack','Every tool behind the multi-agent company, and what to use instead of each one','https://agent-stack.founderos.example','live','email','Beehiiv · newsletter + Cohort 2 waitlist segment','IG carousel · "One person. A company of agents." (comment AGENT)','2026-08-12','Newsletter signup plus a separate Cohort 2 waitlist form that stamps cohort=founderos-cohort-2. Repo is linked free and ungated. Custom domain stack.thefounderos.com is attached in Vercel but needs an A record (stack -> 76.76.21.21) at Namecheap before it resolves.','seed');
CREATE TABLE funnel_contacts (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  venture TEXT NOT NULL,
  status TEXT NOT NULL,
  product TEXT,
  amount_usd REAL,
  relationship TEXT NOT NULL DEFAULT 'warm',
  likelihood INTEGER NOT NULL DEFAULT 50,
  email TEXT,
  phone TEXT,
  person TEXT,
  company TEXT,
  role TEXT,
  linkedin TEXT,
  created_at TEXT NOT NULL
);
INSERT INTO funnel_contacts VALUES('fc-jake-moreau','Jake Moreau','launchpad-cohort','converted','Launchpad Cohort — mentorship (PIF)',6800.0,'hot',100,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-02');
INSERT INTO funnel_contacts VALUES('fc-priya-shah','Priya Shah','launchpad-cohort','converted','Launchpad Cohort — mentorship (3-pay)',2600.0,'warm',95,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-16');
INSERT INTO funnel_contacts VALUES('fc-danny-okafor','Danny Okafor','launchpad-cohort','converted','Launchpad Cohort — mentorship (PIF)',6800.0,'hot',100,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-23');
INSERT INTO funnel_contacts VALUES('fc-sofia-reyes','Sofia Reyes','launchpad-cohort','converted','Launchpad Cohort — mentorship (3-pay)',2600.0,'warm',95,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-30');
INSERT INTO funnel_contacts VALUES('fc-liam-carter','Liam Carter','launchpad-cohort','engaged',NULL,NULL,'cold',15,NULL,NULL,NULL,NULL,NULL,NULL,'2026-09-03');
INSERT INTO funnel_contacts VALUES('fc-marcus-webb','Marcus Webb','launchpad-cohort','nurtured',NULL,NULL,'warm',42,NULL,NULL,NULL,NULL,NULL,NULL,'2026-09-06');
INSERT INTO funnel_contacts VALUES('fc-tayla-nguyen','Tayla Nguyen','launchpad-cohort','opted_in',NULL,NULL,'hot',84,'tayla.nguyen@example.com','+15550100841',NULL,NULL,NULL,NULL,'2026-09-26');
INSERT INTO funnel_contacts VALUES('fc-remy-cole','Remy Cole','launchpad-cohort','engaged',NULL,NULL,'cold',25,NULL,NULL,NULL,NULL,NULL,NULL,'2026-07-08');
INSERT INTO funnel_contacts VALUES('fc-jordan-blake','Jordan Blake','launchpad-cohort','engaged',NULL,NULL,'cold',20,NULL,NULL,NULL,NULL,NULL,NULL,'2026-06-04');
INSERT INTO funnel_contacts VALUES('fc-ava-stone','Ava Stone — Northwind Legal','vantage','converted','Vantage — AI intake build (sprint)',12000.0,'hot',100,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-04');
INSERT INTO funnel_contacts VALUES('fc-omar-haddad','Omar Haddad — Pulse Fitness Group','vantage','converted','Vantage — AI ops retainer (monthly)',4500.0,'warm',95,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-13');
INSERT INTO funnel_contacts VALUES('fc-elena-brooks','Elena Brooks — Harbor Dental','vantage','converted','Vantage — AI intake build (sprint)',9500.0,'hot',100,NULL,NULL,NULL,NULL,NULL,NULL,'2026-08-30');
INSERT INTO funnel_contacts VALUES('fc-noah-fields','Noah Fields — Fields Roofing','vantage','opted_in',NULL,NULL,'warm',66,NULL,NULL,NULL,NULL,NULL,NULL,'2026-09-22');
INSERT INTO funnel_contacts VALUES('fc-grace-lin','Grace Lin — Lin & Co Accounting','vantage','opted_in',NULL,NULL,'warm',74,'grace@linandco.example.com','+15550100742','Grace Lin','Lin & Co Accounting','Managing Partner','https://linkedin.com/in/gracelin-example','2026-09-24');
CREATE TABLE funnel_touches (
  id TEXT PRIMARY KEY,
  contact_id TEXT NOT NULL REFERENCES funnel_contacts(id),
  seq INTEGER NOT NULL,
  stage TEXT NOT NULL,
  channel TEXT NOT NULL,
  label TEXT NOT NULL,
  source TEXT NOT NULL,
  at TEXT NOT NULL
);
INSERT INTO funnel_touches VALUES('fc-jake-moreau-t1','fc-jake-moreau',1,'first_touch','organic','IG reel: "3 AI offers that close themselves"','trakyo','2026-08-02');
INSERT INTO funnel_touches VALUES('fc-jake-moreau-t2','fc-jake-moreau',2,'engaged','dm','Replied to story CTA — "wants out of retainer hell"','manual','2026-08-04');
INSERT INTO funnel_touches VALUES('fc-jake-moreau-t3','fc-jake-moreau',3,'nurtured','email','Day-3 email: student case study (0→22k/mo)','manual','2026-08-07');
INSERT INTO funnel_touches VALUES('fc-jake-moreau-t4','fc-jake-moreau',4,'opted_in','call','Booked strategy call via Trakyo link','trakyo','2026-08-10');
INSERT INTO funnel_touches VALUES('fc-jake-moreau-t5','fc-jake-moreau',5,'converted','checkout','Paid in full — PayKit checkout','manual','2026-08-12');
INSERT INTO funnel_touches VALUES('fc-priya-shah-t1','fc-priya-shah',1,'first_touch','ads','Meta ad: "Agency owners — install AI in 30 days"','meta-ads','2026-08-16');
INSERT INTO funnel_touches VALUES('fc-priya-shah-t2','fc-priya-shah',2,'engaged','ads','Watched VSL to 80% — retarget pool','meta-ads','2026-08-16');
INSERT INTO funnel_touches VALUES('fc-priya-shah-t3','fc-priya-shah',3,'opted_in','webinar','Registered + attended WebinarJam training','manual','2026-08-19');
INSERT INTO funnel_touches VALUES('fc-priya-shah-t4','fc-priya-shah',4,'converted','checkout','First of 3 payments — PayKit','manual','2026-08-21');
INSERT INTO funnel_touches VALUES('fc-danny-okafor-t1','fc-danny-okafor',1,'first_touch','organic','TikTok: "day in the life running an AI agency"','trakyo','2026-08-23');
INSERT INTO funnel_touches VALUES('fc-danny-okafor-t2','fc-danny-okafor',2,'engaged','organic','Binged 6 reels, followed, saved lead magnet post','trakyo','2026-08-25');
INSERT INTO funnel_touches VALUES('fc-danny-okafor-t3','fc-danny-okafor',3,'nurtured','ads','Retargeting ad: student-wins carousel','meta-ads','2026-08-28');
INSERT INTO funnel_touches VALUES('fc-danny-okafor-t4','fc-danny-okafor',4,'opted_in','call','Booked call from link-in-bio (Trakyo attributed)','trakyo','2026-08-31');
INSERT INTO funnel_touches VALUES('fc-danny-okafor-t5','fc-danny-okafor',5,'converted','checkout','Paid in full — PayKit checkout','manual','2026-09-01');
INSERT INTO funnel_touches VALUES('fc-sofia-reyes-t1','fc-sofia-reyes',1,'first_touch','organic','YT long-form: "how I''d start an agency in 2026"','trakyo','2026-08-30');
INSERT INTO funnel_touches VALUES('fc-sofia-reyes-t2','fc-sofia-reyes',2,'engaged','email','Joined newsletter from YT description','manual','2026-08-31');
INSERT INTO funnel_touches VALUES('fc-sofia-reyes-t3','fc-sofia-reyes',3,'nurtured','email','Newsletter: pricing-psychology issue clicked','manual','2026-09-04');
INSERT INTO funnel_touches VALUES('fc-sofia-reyes-t4','fc-sofia-reyes',4,'opted_in','webinar','Attended WebinarJam training, stayed for offer','manual','2026-09-07');
INSERT INTO funnel_touches VALUES('fc-sofia-reyes-t5','fc-sofia-reyes',5,'converted','checkout','First of 3 payments — PayKit','manual','2026-09-08');
INSERT INTO funnel_touches VALUES('fc-liam-carter-t1','fc-liam-carter',1,'first_touch','ads','Meta ad: "stop selling hours" (cold traffic)','meta-ads','2026-09-03');
INSERT INTO funnel_touches VALUES('fc-liam-carter-t2','fc-liam-carter',2,'engaged','ads','Clicked through, watched VSL 45%','meta-ads','2026-09-03');
INSERT INTO funnel_touches VALUES('fc-liam-carter-t3','fc-liam-carter',3,'engaged','ads','Retarget click — opened application form, abandoned','meta-ads','2026-09-07');
INSERT INTO funnel_touches VALUES('fc-liam-carter-t4','fc-liam-carter',4,'engaged','email','Abandoned-form email opened, no reply yet','manual','2026-09-09');
INSERT INTO funnel_touches VALUES('fc-marcus-webb-t1','fc-marcus-webb',1,'first_touch','organic','IG carousel: "agency niches that print in 2026"','trakyo','2026-09-06');
INSERT INTO funnel_touches VALUES('fc-marcus-webb-t2','fc-marcus-webb',2,'engaged','dm','ManyChat keyword "SCALE" → DM flow','manual','2026-09-06');
INSERT INTO funnel_touches VALUES('fc-marcus-webb-t3','fc-marcus-webb',3,'nurtured','email','Lead magnet delivered, day-1 email opened','manual','2026-09-18');
INSERT INTO funnel_touches VALUES('fc-marcus-webb-t4','fc-marcus-webb',4,'nurtured','email','Newsletter: student-win breakdown clicked','manual','2026-09-20');
INSERT INTO funnel_touches VALUES('fc-tayla-nguyen-t1','fc-tayla-nguyen',1,'first_touch','organic','TikTok: "AI receptionist demo" went semi-viral','trakyo','2026-09-26');
INSERT INTO funnel_touches VALUES('fc-tayla-nguyen-t2','fc-tayla-nguyen',2,'engaged','organic','Profile visit → followed + commented','trakyo','2026-09-26');
INSERT INTO funnel_touches VALUES('fc-tayla-nguyen-t3','fc-tayla-nguyen',3,'nurtured','dm','DM convo — asked about payment plans','manual','2026-09-27');
INSERT INTO funnel_touches VALUES('fc-tayla-nguyen-t4','fc-tayla-nguyen',4,'opted_in','call','Call booked for next week (Trakyo attributed)','trakyo','2026-09-28');
INSERT INTO funnel_touches VALUES('fc-remy-cole-t1','fc-remy-cole',1,'first_touch','organic','IG reel: "fire your lead-gen agency"','trakyo','2026-07-08');
INSERT INTO funnel_touches VALUES('fc-remy-cole-t2','fc-remy-cole',2,'engaged','dm','Story-reply convo, asked for pricing','manual','2026-07-12');
INSERT INTO funnel_touches VALUES('fc-remy-cole-t3','fc-remy-cole',3,'engaged','email','Pricing breakdown sent, opened twice','manual','2026-07-18');
INSERT INTO funnel_touches VALUES('fc-remy-cole-t4','fc-remy-cole',4,'engaged','email','Follow-up: "circling back" — no reply since','manual','2026-07-22');
INSERT INTO funnel_touches VALUES('fc-jordan-blake-t1','fc-jordan-blake',1,'first_touch','ads','Meta ad: "quit your 9-5 with one client" (old campaign)','meta-ads','2026-06-04');
INSERT INTO funnel_touches VALUES('fc-jordan-blake-t2','fc-jordan-blake',2,'engaged','ads','Clicked through, watched VSL 30%','meta-ads','2026-06-04');
INSERT INTO funnel_touches VALUES('fc-jordan-blake-t3','fc-jordan-blake',3,'engaged','dm','One-word DM reply, then silence','manual','2026-06-10');
INSERT INTO funnel_touches VALUES('fc-jordan-blake-t4','fc-jordan-blake',4,'engaged','email','Re-engagement email bounced-opened, no click','manual','2026-06-18');
INSERT INTO funnel_touches VALUES('fc-ava-stone-t1','fc-ava-stone',1,'first_touch','organic','LinkedIn post: legal-intake automation teardown','trakyo','2026-08-04');
INSERT INTO funnel_touches VALUES('fc-ava-stone-t2','fc-ava-stone',2,'engaged','email','Replied to newsletter — "this is our exact bottleneck"','manual','2026-08-06');
INSERT INTO funnel_touches VALUES('fc-ava-stone-t3','fc-ava-stone',3,'opted_in','call','Discovery call booked via site (Trakyo attributed)','trakyo','2026-08-11');
INSERT INTO funnel_touches VALUES('fc-ava-stone-t4','fc-ava-stone',4,'nurtured','email','Proposal + Loom walkthrough sent, viewed 3×','manual','2026-08-14');
INSERT INTO funnel_touches VALUES('fc-ava-stone-t5','fc-ava-stone',5,'converted','checkout','Signed — 50% deposit via Stripe invoice','manual','2026-08-18');
INSERT INTO funnel_touches VALUES('fc-omar-haddad-t1','fc-omar-haddad',1,'first_touch','ads','Meta ad: "your gym''s front desk, automated"','meta-ads','2026-08-13');
INSERT INTO funnel_touches VALUES('fc-omar-haddad-t2','fc-omar-haddad',2,'engaged','ads','Case-study page dwell 4m — retarget pool','meta-ads','2026-08-14');
INSERT INTO funnel_touches VALUES('fc-omar-haddad-t3','fc-omar-haddad',3,'nurtured','email','ROI one-pager emailed after form fill','manual','2026-08-17');
INSERT INTO funnel_touches VALUES('fc-omar-haddad-t4','fc-omar-haddad',4,'opted_in','call','Demo call — 3 locations scoped','manual','2026-08-20');
INSERT INTO funnel_touches VALUES('fc-omar-haddad-t5','fc-omar-haddad',5,'converted','checkout','Retainer live — Stripe subscription','manual','2026-08-24');
INSERT INTO funnel_touches VALUES('fc-elena-brooks-t1','fc-elena-brooks',1,'first_touch','organic','IG reel: missed-call → booked-patient demo','trakyo','2026-08-30');
INSERT INTO funnel_touches VALUES('fc-elena-brooks-t2','fc-elena-brooks',2,'engaged','dm','DM: "does this work for dental?"','manual','2026-08-31');
INSERT INTO funnel_touches VALUES('fc-elena-brooks-t3','fc-elena-brooks',3,'opted_in','call','Discovery call via link-in-bio (Trakyo attributed)','trakyo','2026-09-03');
INSERT INTO funnel_touches VALUES('fc-elena-brooks-t4','fc-elena-brooks',4,'converted','checkout','Signed — deposit via Stripe invoice','manual','2026-09-07');
INSERT INTO funnel_touches VALUES('fc-noah-fields-t1','fc-noah-fields',1,'first_touch','ads','Meta ad: "book 20 estimates/mo on autopilot"','meta-ads','2026-09-22');
INSERT INTO funnel_touches VALUES('fc-noah-fields-t2','fc-noah-fields',2,'engaged','ads','Lead form opened, 60% VSL','meta-ads','2026-09-22');
INSERT INTO funnel_touches VALUES('fc-noah-fields-t3','fc-noah-fields',3,'nurtured','email','Follow-up sequence day 2 — case study clicked','manual','2026-09-25');
INSERT INTO funnel_touches VALUES('fc-noah-fields-t4','fc-noah-fields',4,'opted_in','call','Discovery call booked for Friday','manual','2026-09-28');
INSERT INTO funnel_touches VALUES('fc-grace-lin-t1','fc-grace-lin',1,'first_touch','organic','X thread: client-onboarding agent breakdown','trakyo','2026-09-24');
INSERT INTO funnel_touches VALUES('fc-grace-lin-t2','fc-grace-lin',2,'engaged','organic','Followed + bookmarked, visited site twice','trakyo','2026-09-25');
INSERT INTO funnel_touches VALUES('fc-grace-lin-t3','fc-grace-lin',3,'nurtured','email','Newsletter signup — welcome sequence started','manual','2026-09-27');
INSERT INTO funnel_touches VALUES('fc-grace-lin-t4','fc-grace-lin',4,'opted_in','call','Call request form submitted (Trakyo attributed)','trakyo','2026-09-29');
CREATE TABLE workflows (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  subtitle TEXT NOT NULL DEFAULT '',
  revenue_usd INTEGER NOT NULL DEFAULT 0,
  ord INTEGER NOT NULL DEFAULT 0,
  steps TEXT NOT NULL DEFAULT '[]'
);
INSERT INTO workflows VALUES('wf-vantage-sales','Vantage sales machine','Cold outbound to closed retainer.',120000,0,'[{"id":"wf-mer-1","title":"Run outbound campaigns","detail":"","branch":null,"ownerKind":"agent","owner":"Zernio Publisher","hoursPerWeek":6,"tools":["zernio","arcads"],"edgeLabel":"replies","leakUsd":null,"automation":{"title":"Always-on content + DM outreach","state":"live","recoveredUsd":4200}},{"id":"wf-mer-2","title":"Qualify replies","detail":"","branch":null,"ownerKind":"agent","owner":"Comms Agent","hoursPerWeek":9,"tools":["manychat","gmail"],"edgeLabel":"qualified","leakUsd":14000,"automation":{"title":"Auto-qualify + book","state":"suggested","recoveredUsd":9000}},{"id":"wf-mer-3","title":"Book demos","detail":"","branch":null,"ownerKind":"human","owner":"Alex · Founder","hoursPerWeek":4,"tools":["calendar","typeform"],"edgeLabel":"demo","leakUsd":null,"automation":null},{"id":"wf-mer-4","title":"Sales call","detail":"","branch":null,"ownerKind":"human","owner":"Alex · Founder","hoursPerWeek":10,"tools":["fathom"],"edgeLabel":"proposal","leakUsd":null,"automation":null},{"id":"wf-mer-5","title":"Proposal & follow-up","detail":"","branch":null,"ownerKind":"human","owner":"Alex · Founder","hoursPerWeek":5,"tools":["proposal-gen","gmail"],"edgeLabel":"won","leakUsd":6000,"automation":{"title":"Proposal follow-up sequence","state":"suggested","recoveredUsd":6000}},{"id":"wf-mer-6","title":"Onboard & deliver","detail":"","branch":null,"ownerKind":"agent","owner":"Onboarding Agent","hoursPerWeek":3,"tools":["stripe","slack"],"edgeLabel":null,"leakUsd":null,"automation":{"title":"Onboarding rails","state":"live","recoveredUsd":3000}}]');
INSERT INTO workflows VALUES('wf-lc-delivery','Launchpad Cohort delivery','Webinar lead to retained program member.',80000,1,'[{"id":"wf-lc-1","title":"Capture leads","detail":"","branch":null,"ownerKind":"agent","owner":"Typeform","hoursPerWeek":2,"tools":["typeform"],"edgeLabel":"applied","leakUsd":null,"automation":{"title":"Typeform leads into the funnel","state":"live","recoveredUsd":2500}},{"id":"wf-lc-2","title":"Nurture to a booked call","detail":"","branch":null,"ownerKind":"agent","owner":"ManyChat","hoursPerWeek":3,"tools":["manychat","calendar"],"edgeLabel":"booked","leakUsd":8000,"automation":{"title":"Nurture sequences","state":"live","recoveredUsd":5000}},{"id":"wf-lc-3","title":"Strategy call","detail":"","branch":null,"ownerKind":"human","owner":"Alex · Founder","hoursPerWeek":8,"tools":["fathom","calendar"],"edgeLabel":"closed","leakUsd":null,"automation":null},{"id":"wf-lc-4","title":"Deliver program","detail":"","branch":null,"ownerKind":"human","owner":"LC Team","hoursPerWeek":12,"tools":["skool"],"edgeLabel":"retained","leakUsd":5000,"automation":{"title":"Skool community ops","state":"suggested","recoveredUsd":4000}},{"id":"wf-lc-5","title":"Track attribution","detail":"","branch":null,"ownerKind":"agent","owner":"Trakyo","hoursPerWeek":1,"tools":["trakyo"],"edgeLabel":null,"leakUsd":null,"automation":{"title":"Revenue attribution","state":"suggested","recoveredUsd":0}}]');
CREATE TABLE skills (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  category TEXT NOT NULL,
  description TEXT NOT NULL DEFAULT '',
  owner_agent_id TEXT,
  status TEXT NOT NULL DEFAULT 'planned',
  tools TEXT NOT NULL DEFAULT '[]',
  markdown TEXT NOT NULL DEFAULT '',
  ord INTEGER NOT NULL DEFAULT 0
);
INSERT INTO skills VALUES('skill-outbound','Cold outbound sequencing','Sales','Multi-touch DM + content cadence that opens conversations at scale.','postly-publisher','live','["zernio","manychat"]',unistr('---\u000aname: cold-outbound-sequencing\u000adescription: Multi-touch DM + content cadence that opens conversations at scale.\u000acategory: Sales\u000astatus: live\u000a---\u000a\u000a# Cold outbound sequencing\u000a\u000aMulti-touch DM + content cadence that opens conversations at scale.\u000a\u000a## When to use\u000aReach for this when the sales flow needs to cold outbound sequencing. It runs on `zernio`, `manychat`.\u000a\u000a## Status\u000aLive in production. The owning agent runs this today.\u000a'),0);
INSERT INTO skills VALUES('skill-qualify','Reply qualification','Sales','Reads inbound replies, scores intent, and books the qualified ones.','comms-agent','live','["manychat","gmail"]',unistr('---\u000aname: reply-qualification\u000adescription: Reads inbound replies, scores intent, and books the qualified ones.\u000acategory: Sales\u000astatus: live\u000a---\u000a\u000a# Reply qualification\u000a\u000aReads inbound replies, scores intent, and books the qualified ones.\u000a\u000a## When to use\u000aReach for this when the sales flow needs to reply qualification. It runs on `manychat`, `gmail`.\u000a\u000a## Status\u000aLive in production. The owning agent runs this today.\u000a'),1);
INSERT INTO skills VALUES('skill-proposal','Proposal drafting','Sales','Turns a call transcript into a tailored, on-brand proposal.',NULL,'learning','["proposal-gen","fathom"]',unistr('---\u000aname: proposal-drafting\u000adescription: Turns a call transcript into a tailored, on-brand proposal.\u000acategory: Sales\u000astatus: learning\u000a---\u000a\u000a# Proposal drafting\u000a\u000aTurns a call transcript into a tailored, on-brand proposal.\u000a\u000a## When to use\u000aReach for this when the sales flow needs to proposal drafting. It runs on `proposal-gen`, `fathom`.\u000a\u000a## Status\u000aIn training. Runs with a human in the loop while it calibrates.\u000a'),2);
INSERT INTO skills VALUES('skill-hooks','Hook writing','Content','Short-form hooks and captions tuned to each platform.','social-agent','live','["zernio"]',unistr('---\u000aname: hook-writing\u000adescription: Short-form hooks and captions tuned to each platform.\u000acategory: Content\u000astatus: live\u000a---\u000a\u000a# Hook writing\u000a\u000aShort-form hooks and captions tuned to each platform.\u000a\u000a## When to use\u000aReach for this when the content flow needs to hook writing. It runs on `zernio`.\u000a\u000a## Status\u000aLive in production. The owning agent runs this today.\u000a'),3);
INSERT INTO skills VALUES('skill-ugc','UGC generation','Content','Generates ad-ready UGC variants (Veo / Sora / Kling).','adsmith-creative','live','["arcads"]',unistr('---\u000aname: ugc-generation\u000adescription: Generates ad-ready UGC variants (Veo / Sora / Kling).\u000acategory: Content\u000astatus: live\u000a---\u000a\u000a# UGC generation\u000a\u000aGenerates ad-ready UGC variants (Veo / Sora / Kling).\u000a\u000a## When to use\u000aReach for this when the content flow needs to ugc generation. It runs on `arcads`.\u000a\u000a## Status\u000aLive in production. The owning agent runs this today.\u000a'),4);
INSERT INTO skills VALUES('skill-edit','Video editing','Content','Cuts reels and highlight clips programmatically.','reelkit-editor','live','["remotion"]',unistr('---\u000aname: video-editing\u000adescription: Cuts reels and highlight clips programmatically.\u000acategory: Content\u000astatus: live\u000a---\u000a\u000a# Video editing\u000a\u000aCuts reels and highlight clips programmatically.\u000a\u000a## When to use\u000aReach for this when the content flow needs to video editing. It runs on `remotion`.\u000a\u000a## Status\u000aLive in production. The owning agent runs this today.\u000a'),5);
INSERT INTO skills VALUES('skill-schedule','Cross-post scheduling','Content','Queues and publishes across every connected platform.','postly-publisher','live','["zernio"]',unistr('---\u000aname: cross-post-scheduling\u000adescription: Queues and publishes across every connected platform.\u000acategory: Content\u000astatus: live\u000a---\u000a\u000a# Cross-post scheduling\u000a\u000aQueues and publishes across every connected platform.\u000a\u000a## When to use\u000aReach for this when the content flow needs to cross-post scheduling. It runs on `zernio`.\u000a\u000a## Status\u000aLive in production. The owning agent runs this today.\u000a'),6);
INSERT INTO skills VALUES('skill-triage','Inbox triage','Ops','Sorts the four inboxes into work / personal / misc and flags priority.','gmail-worker','live','["gmail"]',unistr('---\u000aname: inbox-triage\u000adescription: Sorts the four inboxes into work / personal / misc and flags priority.\u000acategory: Ops\u000astatus: live\u000a---\u000a\u000a# Inbox triage\u000a\u000aSorts the four inboxes into work / personal / misc and flags priority.\u000a\u000a## When to use\u000aReach for this when the ops flow needs to inbox triage. It runs on `gmail`.\u000a\u000a## Status\u000aLive in production. The owning agent runs this today.\u000a'),7);
INSERT INTO skills VALUES('skill-dm','DM management','Ops','Handles Instagram and WhatsApp DMs end to end.','comms-agent','live','["manychat","whatsapp"]',unistr('---\u000aname: dm-management\u000adescription: Handles Instagram and WhatsApp DMs end to end.\u000acategory: Ops\u000astatus: live\u000a---\u000a\u000a# DM management\u000a\u000aHandles Instagram and WhatsApp DMs end to end.\u000a\u000a## When to use\u000aReach for this when the ops flow needs to dm management. It runs on `manychat`, `whatsapp`.\u000a\u000a## Status\u000aLive in production. The owning agent runs this today.\u000a'),8);
INSERT INTO skills VALUES('skill-retrieval','Knowledge retrieval','Ops','Hybrid search over G-Brain so every agent shares one memory.','conductor','live','["gbrain"]',unistr('---\u000aname: knowledge-retrieval\u000adescription: Hybrid search over G-Brain so every agent shares one memory.\u000acategory: Ops\u000astatus: live\u000a---\u000a\u000a# Knowledge retrieval\u000a\u000aHybrid search over G-Brain so every agent shares one memory.\u000a\u000a## When to use\u000aReach for this when the ops flow needs to knowledge retrieval. It runs on `gbrain`.\u000a\u000a## Status\u000aLive in production. The owning agent runs this today.\u000a'),9);
INSERT INTO skills VALUES('skill-reconcile','Payment reconciliation','Ops','Matches processor payouts to clients across Stripe and PayKit.',NULL,'planned','["stripe","paykit"]',unistr('---\u000aname: payment-reconciliation\u000adescription: Matches processor payouts to clients across Stripe and PayKit.\u000acategory: Ops\u000astatus: planned\u000a---\u000a\u000a# Payment reconciliation\u000a\u000aMatches processor payouts to clients across Stripe and PayKit.\u000a\u000a## When to use\u000aReach for this when the ops flow needs to payment reconciliation. It runs on `stripe`, `paykit`.\u000a\u000a## Status\u000aPlanned. Scoped and queued, not yet wired.\u000a'),10);
INSERT INTO skills VALUES('skill-attribution','Revenue attribution','Ops','Ties content and calls to closed revenue via Trakyo.',NULL,'planned','["trakyo","ghl"]',unistr('---\u000aname: revenue-attribution\u000adescription: Ties content and calls to closed revenue via Trakyo.\u000acategory: Ops\u000astatus: planned\u000a---\u000a\u000a# Revenue attribution\u000a\u000aTies content and calls to closed revenue via Trakyo.\u000a\u000a## When to use\u000aReach for this when the ops flow needs to revenue attribution. It runs on `trakyo`, `ghl`.\u000a\u000a## Status\u000aPlanned. Scoped and queued, not yet wired.\u000a'),11);
CREATE TABLE slack_bridge_jobs (id TEXT PRIMARY KEY, payload TEXT NOT NULL, state TEXT NOT NULL);
CREATE TABLE slack_bridge_sessions (key TEXT PRIMARY KEY, payload TEXT NOT NULL);
CREATE INDEX idx_cron_runs_cron ON cron_runs (cron_id, started_at DESC);
CREATE INDEX idx_cron_runs_started ON cron_runs (started_at DESC);
CREATE INDEX idx_agent_runs_started ON agent_runs (started_at DESC);
CREATE INDEX idx_social_dm_messages_ts ON social_dm_messages (ts);
COMMIT;
